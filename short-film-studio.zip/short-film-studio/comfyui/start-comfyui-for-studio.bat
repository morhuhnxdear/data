@echo off
title ComfyUI for Short Film Studio (GPU)
cd /d "%~dp0"
if not exist "python_embeded\python.exe" (
  echo.
  echo  Put this file inside the ComfyUI_windows_portable folder,
  echo  next to run_nvidia_gpu.bat, then run it again.
  echo.
  pause
  exit /b 1
)
echo Starting ComfyUI for Short Film Studio on http://127.0.0.1:8188 ...
.\python_embeded\python.exe -s ComfyUI\main.py --windows-standalone-build --enable-cors-header "*"
pause
