@echo off
title ComfyUI for Short Film Studio (CPU - slow)
cd /d "%~dp0"
if not exist "python_embeded\python.exe" (
  echo.
  echo  Put this file inside the ComfyUI_windows_portable folder, then run it again.
  echo.
  pause
  exit /b 1
)
echo Starting ComfyUI on CPU (no graphics card). Each image can take 5-20 minutes.
.\python_embeded\python.exe -s ComfyUI\main.py --windows-standalone-build --cpu --enable-cors-header "*"
pause
