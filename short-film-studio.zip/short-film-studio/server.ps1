# Short Film Studio - tiny local web server (no install needed)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$listener = $null; $port = 0
foreach ($p in 8080..8090) {
  try { $l = New-Object System.Net.HttpListener; $l.Prefixes.Add("http://localhost:$p/"); $l.Start(); $listener = $l; $port = $p; break } catch { }
}
if (-not $listener) { Write-Host "No free port between 8080 and 8090. Close other servers and try again."; Read-Host "Press Enter to exit"; exit 1 }
$url = "http://localhost:$port/"
Write-Host ""
Write-Host "  Short Film Studio is running at $url"
Write-Host "  Keep this window open while you use the site. Close it to stop the server."
Write-Host ""
Start-Process $url
$mime = @{ '.html'='text/html; charset=utf-8'; '.js'='application/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8';
           '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.webp'='image/webp'; '.svg'='image/svg+xml';
           '.json'='application/json'; '.ico'='image/x-icon'; '.mp4'='video/mp4' }
while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext(); $res = $ctx.Response
    $path = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath).TrimStart('/')
    if ($path -eq '') { $path = 'index.html' }
    $full = [IO.Path]::GetFullPath((Join-Path $root $path))
    if ($full.StartsWith($root) -and (Test-Path -LiteralPath $full -PathType Leaf)) {
      $bytes = [IO.File]::ReadAllBytes($full); $ext = [IO.Path]::GetExtension($full).ToLower()
      $res.ContentType = $(if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' })
      $res.Headers.Add('Cache-Control', 'no-cache')
      $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes, 0, $bytes.Length)
      Write-Host ("  200  /" + $path)
    } else { $res.StatusCode = 404; Write-Host ("  404  /" + $path) }
    $res.Close()
  } catch { Write-Host ("  error: " + $_.Exception.Message) }
}
