@echo off
chcp 65001 >nul
REM ===== Purchasing KMUTT : ตั้งค่าเครื่องผู้ใช้ให้รู้จักชื่อ purchasingfibo.lan =====
REM รันบนเครื่องผู้ใช้แต่ละเครื่อง (คลิกขวา > Run as administrator)
REM ไม่ต้องใช้ไฟล์นี้ ถ้าฝ่ายไอทีเพิ่มชื่อในระบบ DNS ให้แล้ว
net session >nul 2>&1 || (echo ต้องคลิกขวาแล้วเลือก Run as administrator & pause & exit /b 1)

set HOSTS=%SystemRoot%\System32\drivers\etc\hosts
findstr /I /C:"purchasingfibo.lan" "%HOSTS%" >nul && (echo เครื่องนี้มีชื่อ purchasingfibo.lan อยู่แล้ว & pause & exit /b 0)
echo.>>"%HOSTS%"
echo 10.61.200.12   purchasingfibo.lan>>"%HOSTS%"
ipconfig /flushdns >nul
echo เพิ่มแล้ว เปิด http://purchasingfibo.lan ได้เลย
pause
