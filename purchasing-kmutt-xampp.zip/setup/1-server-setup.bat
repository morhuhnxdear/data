@echo off
chcp 65001 >nul
REM ===== Purchasing KMUTT : ตั้งค่าเครื่องเซิร์ฟเวอร์ XAMPP (10.61.200.12) =====
REM คลิกขวา > Run as administrator
net session >nul 2>&1 || (echo ต้องคลิกขวาแล้วเลือก Run as administrator & pause & exit /b 1)

set HOSTS=%SystemRoot%\System32\drivers\etc\hosts
findstr /I /C:"purchasingfibo.lan" "%HOSTS%" >nul || (
  echo.>>"%HOSTS%"
  echo 127.0.0.1   purchasingfibo.lan>>"%HOSTS%"
  echo เพิ่มชื่อ purchasingfibo.lan ในไฟล์ hosts ของเครื่องนี้แล้ว
)

netsh advfirewall firewall show rule name="Purchasing KMUTT HTTP" >nul 2>&1 || (
  netsh advfirewall firewall add rule name="Purchasing KMUTT HTTP" dir=in action=allow protocol=TCP localport=80 profile=domain,private >nul
  echo เปิด Firewall พอร์ต 80 สำหรับเครือข่ายภายในแล้ว
)
ipconfig /flushdns >nul
echo.
echo เสร็จแล้ว อย่าลืมเพิ่ม httpd-vhosts-purchasing.conf และ Restart Apache
pause
