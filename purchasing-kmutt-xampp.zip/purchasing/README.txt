Purchasing KMUTT — วิธีติดตั้งบน XAMPP
=========================================

ไฟล์ในโฟลเดอร์นี้
  index.html   หน้าระบบ (หน้าหลัก / กรอกเอกสาร / ตัวอย่างเอกสาร)
  api.php      ที่เก็บคลังตัวอย่างเอกสารกลาง
  config.php   ค่าการเชื่อมต่อฐานข้อมูล
  install.sql  สคริปต์สร้างฐานข้อมูล (ใช้เฉพาะเมื่อ api.php สร้างเองไม่ได้)

ขั้นตอน
1. คัดลอกทั้งโฟลเดอร์ purchasing ไปไว้ที่ C:\xampp\htdocs\purchasing
2. เปิด XAMPP Control Panel แล้ว Start ทั้ง Apache และ MySQL
3. เปิด http://localhost/purchasing/
   - หน้า "ตัวอย่างเอกสาร" ควรขึ้นว่า "คลังกลางบนเซิร์ฟเวอร์ของหน่วยงาน"
   - ฐานข้อมูล purchasing_kmutt และตาราง documents จะถูกสร้างให้อัตโนมัติครั้งแรก
   - ถ้าขึ้นว่า "เก็บในเบราว์เซอร์นี้เท่านั้น" แปลว่าเรียก api.php ไม่ได้
     ให้เปิด http://localhost/purchasing/api.php?action=ping ดูข้อความผิดพลาด
4. ตั้งชื่อ http://purchasingfibo.lan (เซิร์ฟเวอร์ IP 10.61.200.12) — ไฟล์อยู่ในโฟลเดอร์ setup
   ก. คัดลอกข้อความใน setup\httpd-vhosts-purchasing.conf ไปต่อท้าย
      C:\xampp\apache\conf\extra\httpd-vhosts.conf แล้ว Stop/Start Apache
   ข. บนเครื่องเซิร์ฟเวอร์ รัน setup\1-server-setup.bat (Run as administrator)
      เพิ่มชื่อในไฟล์ hosts และเปิด Firewall พอร์ต 80 ให้เครื่องในเครือข่ายภายใน
   ค. บนเครื่องผู้ใช้แต่ละเครื่อง รัน setup\2-client-setup.bat (Run as administrator)
      หรือขอฝ่ายไอทีเพิ่มระเบียน DNS: purchasingfibo.lan -> 10.61.200.12 แทน (ไม่ต้องรันทุกเครื่อง)
   ง. เครื่องเซิร์ฟเวอร์ต้องใช้ IP 10.61.200.12 คงที่เสมอ
   ถ้าต้องการชื่ออื่น ให้แทนคำว่า purchasingfibo.lan ในทั้ง 3 ไฟล์

ก่อนเปิดใช้งานจริง
- สร้างผู้ใช้ MySQL แยกสำหรับระบบนี้ (สิทธิ์เฉพาะฐาน purchasing_kmutt) แล้วแก้ user/pass ใน config.php
  ถ้าผู้ใช้นั้นไม่มีสิทธิ์ CREATE DATABASE ให้รัน install.sql ใน phpMyAdmin ก่อน
- ระบบนี้ไม่มีการล็อกอิน ทุกคนที่เข้าถึงหน้าเว็บได้จะดู บันทึก และลบเอกสารในคลังได้
  ควรเปิดให้เข้าได้เฉพาะเครือข่ายภายใน
- ปิดการเข้าถึง /dashboard และ /phpmyadmin จากเครื่องอื่น
- สำรองฐานข้อมูล purchasing_kmutt เป็นระยะ (Export ใน phpMyAdmin)

แนบแคตตาล็อกและร่างสเปค
- ไฟล์แคตตาล็อกที่แนบเก็บที่ C:\xampp\purchasing-data\uploads (สร้างให้อัตโนมัติ) ควรรวมไว้ในการสำรองข้อมูลด้วย
- ไฟล์ละไม่เกิน 20 MB: แก้ C:\xampp\php\php.ini ให้ upload_max_filesize = 20M และ post_max_size = 24M แล้ว Restart Apache
- ปุ่ม AI ("ให้ AI ช่วยเขียน" วัตถุประสงค์ และ "ร่างสเปคจากแคตตาล็อก") เปิดเมื่อใส่ API key ใน config.php
  * Gemini: ai_provider = 'gemini' และใส่ gemini_api_key (ขอที่ aistudio.google.com)
  * Claude: ai_provider = 'anthropic' และใส่ anthropic_api_key (ขอที่ console.anthropic.com)
  มีค่าใช้จ่ายตามการใช้งาน เซิร์ฟเวอร์ต้องออกอินเทอร์เน็ตได้ และต้องเปิด extension=curl กับ extension=fileinfo ใน php.ini
  ข้อมูลที่ส่งให้ AI (ชื่อรายการ สเปค เนื้อหาแคตตาล็อก) จะถูกประมวลผลนอกมหาวิทยาลัย
- การอ่านไฟล์ PDF ใช้ pdf.js จาก cdnjs.cloudflare.com เครื่องผู้ใช้จึงต้องออกอินเทอร์เน็ตได้ ถ้าไม่ได้ ให้แนบหน้าแคตตาล็อกเป็นรูปแทน

ไม่ใช้ MySQL ก็ได้: เปลี่ยน 'driver' ใน config.php เป็น 'sqlite'
(ต้องเปิด extension pdo_sqlite ใน php.ini และไฟล์ฐานข้อมูลจะอยู่ที่ C:\xampp\purchasing-data\)
