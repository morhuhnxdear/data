-- ใช้เมื่อผู้ใช้ MySQL ของระบบไม่มีสิทธิ์สร้างฐานข้อมูลเอง (api.php สร้างให้อัตโนมัติถ้ามีสิทธิ์)
CREATE DATABASE IF NOT EXISTS `purchasing_kmutt` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `purchasing_kmutt`;
CREATE TABLE IF NOT EXISTS documents (
  id VARCHAR(40) NOT NULL PRIMARY KEY,
  title VARCHAR(500) NOT NULL,
  type VARCHAR(20) NOT NULL,
  qty VARCHAR(50) NULL,
  unit VARCHAR(100) NULL,
  agency VARCHAR(500) NULL,
  errors INT NOT NULL DEFAULT 0,
  state MEDIUMTEXT NOT NULL,
  created_at VARCHAR(30) NOT NULL,
  updated_at VARCHAR(30) NOT NULL,
  INDEX idx_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
