<?php
// Purchasing KMUTT — API คลังตัวอย่างเอกสาร
// action: ping | list | save | delete | upload (แคตตาล็อก) | file | draft (ร่างสเปคด้วย Claude API)
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function out($data, int $code = 200): void { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }

$cfg = require __DIR__ . '/config.php';
try {
    if (($cfg['driver'] ?? 'mysql') === 'sqlite') {
        $dir = dirname($cfg['sqlite_path']);
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $pdo = new PDO('sqlite:' . $cfg['sqlite_path'], null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec('CREATE TABLE IF NOT EXISTS documents (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, type TEXT NOT NULL, qty TEXT, unit TEXT, agency TEXT,
            errors INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)');
    } else {
        $pdo = new PDO("mysql:host={$cfg['host']};port={$cfg['port']};charset=utf8mb4", $cfg['user'], $cfg['pass'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $db = preg_replace('/[^A-Za-z0-9_]/', '', $cfg['dbname']);
        try { $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"); } catch (Throwable $e) { /* ผู้ใช้ไม่มีสิทธิ์สร้างฐานข้อมูล ใช้ฐานที่มีอยู่ */ }
        $pdo->exec("USE `$db`");
        $pdo->exec('CREATE TABLE IF NOT EXISTS documents (
            id VARCHAR(40) NOT NULL PRIMARY KEY, title VARCHAR(500) NOT NULL, type VARCHAR(20) NOT NULL,
            qty VARCHAR(50) NULL, unit VARCHAR(100) NULL, agency VARCHAR(500) NULL,
            errors INT NOT NULL DEFAULT 0, state MEDIUMTEXT NOT NULL,
            created_at VARCHAR(30) NOT NULL, updated_at VARCHAR(30) NOT NULL, INDEX idx_updated (updated_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }
} catch (Throwable $e) {
    out(['ok' => false, 'error' => 'db_connect', 'message' => 'เชื่อมต่อฐานข้อมูลไม่ได้ ตรวจว่าเปิด MySQL ใน XAMPP แล้ว และค่าใน config.php ถูกต้อง'], 500);
}

$action = $_GET['action'] ?? '';
$body = function (int $max = 2_000_000): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > $max) out(['error' => 'too_large'], 413);
    $j = json_decode($raw, true);
    if (!is_array($j)) out(['error' => 'bad_json'], 400);
    return $j;
};
$cut = fn($v, int $n) => mb_substr(trim((string)($v ?? '')), 0, $n);

switch ($action) {
case 'ping':
    out(['ok' => true, 'ai' => trim((string)($cfg['anthropic_api_key'] ?? '')) !== '']);

case 'upload':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error' => 'method'], 405);
    $f = $_FILES['file'] ?? null;
    if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK) out(['error' => 'upload_failed'], 400);
    if ($f['size'] > 20 * 1048576) out(['error' => 'size'], 413);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'][$mime] ?? null;
    if (!$ext) out(['error' => 'type'], 415);
    $dir = rtrim($cfg['upload_dir'], '/\\');
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) out(['error' => 'storage'], 500);
    $fid = bin2hex(random_bytes(12)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . DIRECTORY_SEPARATOR . $fid)) out(['error' => 'storage'], 500);
    out(['ok' => true, 'id' => $fid]);

case 'file':
    $fid = (string)($_GET['id'] ?? '');
    if (!preg_match('/^[a-f0-9]{24}\.(pdf|jpg|png|webp|gif)$/', $fid)) out(['error' => 'bad_id'], 400);
    $path = rtrim($cfg['upload_dir'], '/\\') . DIRECTORY_SEPARATOR . $fid;
    if (!is_file($path)) out(['error' => 'not_found'], 404);
    $types = ['pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif'];
    header_remove('Cache-Control');
    header('Content-Type: ' . $types[pathinfo($fid, PATHINFO_EXTENSION)]);
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: inline');
    header('Cache-Control: private, max-age=86400');
    readfile($path); exit;

case 'draft':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error' => 'method'], 405);
    $key = trim((string)($cfg['anthropic_api_key'] ?? ''));
    if ($key === '') out(['error' => 'no_key'], 503);
    if (!function_exists('curl_init')) out(['error' => 'no_curl'], 500);
    $j = $body(16_000_000);
    $prompt = (string)($j['prompt'] ?? '');
    if ($prompt === '' || strlen($prompt) > 400_000) out(['error' => 'prompt_too_large'], 400);
    $content = [];
    foreach (array_slice((array)($j['images'] ?? []), 0, 6) as $im) {
        $mt = (string)($im['media_type'] ?? '');
        if (!in_array($mt, ['image/jpeg', 'image/png', 'image/webp', 'image/gif'], true)) continue;
        $content[] = ['type' => 'image', 'source' => ['type' => 'base64', 'media_type' => $mt, 'data' => (string)($im['data'] ?? '')]];
    }
    $content[] = ['type' => 'text', 'text' => $prompt];
    $req = json_encode(['model' => $cfg['anthropic_model'] ?? 'claude-sonnet-5-5', 'max_tokens' => 8000,
        'messages' => [['role' => 'user', 'content' => $content]]], JSON_UNESCAPED_UNICODE);
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $req, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 240,
        CURLOPT_HTTPHEADER => ['content-type: application/json', 'x-api-key: ' . $key, 'anthropic-version: 2023-06-01']]);
    if (!empty($cfg['https_proxy'])) curl_setopt($ch, CURLOPT_PROXY, $cfg['https_proxy']);
    $res = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); $cerr = curl_error($ch); curl_close($ch);
    if ($res === false) out(['error' => 'upstream_error', 'message' => $cerr], 502);
    $r = json_decode($res, true);
    if ($code === 429) out(['error' => 'rate_limited'], 429);
    if ($code >= 400 || !is_array($r)) out(['error' => 'upstream_error', 'message' => $r['error']['message'] ?? ('HTTP ' . $code)], 502);
    $text = '';
    foreach ($r['content'] ?? [] as $b) if (($b['type'] ?? '') === 'text') $text .= $b['text'];
    out(['ok' => true, 'text' => $text]);

case 'list':
    $rows = $pdo->query('SELECT id, title, type, qty, unit, agency, errors, state, updated_at FROM documents ORDER BY updated_at DESC LIMIT 1000')->fetchAll(PDO::FETCH_ASSOC);
    $docs = array_map(fn($r) => [
        'id' => $r['id'], 'title' => $r['title'], 'type' => $r['type'], 'qty' => $r['qty'] ?? '', 'unit' => $r['unit'] ?? '',
        'agency' => $r['agency'] ?? '', 'errors' => (int)$r['errors'], 'updatedAt' => $r['updated_at'],
        'state' => json_decode($r['state'], true),
    ], $rows);
    out(['ok' => true, 'docs' => $docs]);

case 'save':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error' => 'method'], 405);
    $j = $body();
    $type = $j['type'] ?? '';
    if (!in_array($type, ['material', 'equipment', 'service'], true)) out(['error' => 'bad_type'], 400);
    if (!isset($j['state']) || !is_array($j['state'])) out(['error' => 'bad_state'], 400);
    $id = (string)($j['id'] ?? '');
    if ($id !== '' && !preg_match('/^[A-Za-z0-9_-]{1,40}$/', $id)) out(['error' => 'bad_id'], 400);
    $now = gmdate('Y-m-d\TH:i:s\Z');
    $fields = [
        ':title' => $cut($j['title'] ?? '', 500) ?: 'ไม่มีชื่อ', ':type' => $type,
        ':qty' => $cut($j['qty'] ?? '', 50), ':unit' => $cut($j['unit'] ?? '', 100), ':agency' => $cut($j['agency'] ?? '', 500),
        ':errors' => max(0, (int)($j['errors'] ?? 0)),
        ':state' => json_encode($j['state'], JSON_UNESCAPED_UNICODE), ':now' => $now,
    ];
    $exists = false;
    if ($id !== '') { $st = $pdo->prepare('SELECT 1 FROM documents WHERE id = ?'); $st->execute([$id]); $exists = (bool)$st->fetchColumn(); }
    if ($exists) {
        $st = $pdo->prepare('UPDATE documents SET title=:title, type=:type, qty=:qty, unit=:unit, agency=:agency, errors=:errors, state=:state, updated_at=:now WHERE id=:id');
    } else {
        if ($id === '') $id = 'd' . bin2hex(random_bytes(8));
        $st = $pdo->prepare('INSERT INTO documents (id, title, type, qty, unit, agency, errors, state, created_at, updated_at) VALUES (:id, :title, :type, :qty, :unit, :agency, :errors, :state, :now, :now)');
    }
    $st->execute($fields + [':id' => $id]);
    out(['ok' => true, 'id' => $id, 'updatedAt' => $now]);

case 'delete':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error' => 'method'], 405);
    $j = $body();
    $id = (string)($j['id'] ?? '');
    if (!preg_match('/^[A-Za-z0-9_-]{1,40}$/', $id)) out(['error' => 'bad_id'], 400);
    $pdo->prepare('DELETE FROM documents WHERE id = ?')->execute([$id]);
    out(['ok' => true]);

default:
    out(['error' => 'unknown_action'], 400);
}
