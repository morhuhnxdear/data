<?php
// ตั้งค่าการเชื่อมต่อฐานข้อมูลของ Purchasing KMUTT
// ค่าเริ่มต้นตรงกับ XAMPP ที่ติดตั้งใหม่ (MySQL ผู้ใช้ root ไม่มีรหัสผ่าน)
// ถ้าเปิดใช้งานจริง ควรสร้างผู้ใช้ MySQL แยกสำหรับระบบนี้ แล้วแก้ค่าด้านล่าง
return [
    'driver' => 'mysql',            // 'mysql' หรือ 'sqlite'
    'host'   => '127.0.0.1',
    'port'   => 3306,
    'dbname' => 'purchasing_kmutt',
    'user'   => 'root',
    'pass'   => '',
    // ใช้เมื่อ driver = 'sqlite' เท่านั้น (ไฟล์ฐานข้อมูลควรอยู่นอก htdocs)
    'sqlite_path' => __DIR__ . '/../../purchasing-data/purchasing.sqlite',

    // ที่เก็บไฟล์แคตตาล็อกที่แนบ (อยู่นอก htdocs เพื่อไม่ให้เปิดตรงๆ ได้)
    'upload_dir' => __DIR__ . '/../../purchasing-data/uploads',

    // ร่างสเปคจากแคตตาล็อกด้วย Claude (ไม่บังคับ) — ใส่ API key จาก console.anthropic.com
    // เว้นว่างไว้ = ปิดปุ่ม "ร่างสเปคจากแคตตาล็อก" (ยังแนบแคตตาล็อกได้ตามปกติ)
    'anthropic_api_key' => '',
    'anthropic_model'   => 'claude-sonnet-5-5',
    // ถ้าเซิร์ฟเวอร์ออกอินเทอร์เน็ตผ่าน proxy ให้ใส่ เช่น 'http://proxy.kmutt.ac.th:8080'
    'https_proxy' => '',
];
