<?php
// ตั้งค่าการเชื่อมต่อฐานข้อมูลของ Purchasing KMUTT
// ค่าเริ่มต้นตรงกับ XAMPP ที่ติดตั้งใหม่ (MySQL ผู้ใช้ root ไม่มีรหัสผ่าน)
// ถ้าเปิดใช้งานจริง ควรสร้างผู้ใช้ MySQL แยกสำหรับระบบนี้ แล้วแก้ค่าด้านล่าง
return [
    'driver' => 'mysql',            // 'mysql' หรือ 'sqlite'
    'host'   => '127.0.0.1',
    'port'   => 3306,
    'dbname' => 'purchasing_kmutt',
    'user'   => 'root',
    'pass'   => '',
    // ใช้เมื่อ driver = 'sqlite' เท่านั้น (ไฟล์ฐานข้อมูลควรอยู่นอก htdocs)
    'sqlite_path' => __DIR__ . '/../../purchasing-data/purchasing.sqlite',
];
