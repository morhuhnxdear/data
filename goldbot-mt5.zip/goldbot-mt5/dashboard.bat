@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
py -3.12 -c "import sys" >nul 2>&1 && set "PY=py -3.12"
%PY% dashboard.py
pause
