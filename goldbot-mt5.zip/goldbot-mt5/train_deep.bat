@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONIOENCODING=utf-8"
set "PY=python"
py -3.12 -c "import sys" >nul 2>&1 && set "PY=py -3.12"
echo ฝึกลึก: บอทเรียนกับราคาย้อนหลัง 1 ปีซ้ำ 3 รอบ แล้วสอบกับ 60 วันล่าสุดที่ไม่เคยเห็น
echo ขั้นที่ 1/2: ดึงราคา XAUUSD แท่ง 1 นาทีย้อนหลัง 365 วันจาก MT5 (เปิด MT5 และล็อกอินไว้ก่อน)
%PY% export_history.py --days 365 --out data || goto :err
for %%f in (data\*_M1.csv) do set "CSV=%%f"
echo ขั้นที่ 2/2: ฝึก 3 รอบ + สอบ แล้วนำสูตรไปตั้งต้นระบบเทรดสด (ใช้เวลานานหลายชั่วโมง เปิดทิ้งไว้ได้)
%PY% backtest.py --csv "%CSV%" --deep 3 --exam-days 60 --out out_deep --seed-live data_live > out_deep_report.txt 2>&1
if errorlevel 1 goto :err
type out_deep_report.txt
echo.
echo เสร็จแล้ว ผลอยู่ใน out_deep_report.txt (ดูตารางผลสอบท้ายไฟล์) แล้วรัน start.bat เพื่อเริ่มเทรดบนบัญชี Demo
pause
exit /b 0
:err
type out_deep_report.txt 2>nul
echo เกิดข้อผิดพลาด ดูข้อความด้านบน
pause
