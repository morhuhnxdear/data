"""ทดสอบย้อนหลังระบบบอท 100 ตัวกับข้อมูลราคาแท่ง M1

ตัวอย่าง:
  python backtest.py --csv data/XAUUSD_M1.csv
  python backtest.py --csv data/XAUUSD_M1.csv --from 2025-01-01 --to 2025-06-30
  python backtest.py --synthetic 20          (ข้อมูลปลอม ไว้ลองว่าโปรแกรมทำงาน)
  python backtest.py --csv data/XAUUSD_M1.csv --compare   (เทียบเกณฑ์เดิม กับเกณฑ์กันฟลุ๊ค ข้อ 1-4 บนราคาชุดเดียวกัน)
"""
import argparse
import datetime as dt
import logging
import os
import sys


import pyenv_check  # ถ้าพิมพ์ python แล้วตัวนั้นไม่มีไลบรารี จะสลับไปใช้ Python ที่มีครบ หรือติดตั้งให้
pyenv_check.ensure(need_mt5=False)

from goldbots.arena import Arena, bar_day, money
from goldbots.config import load_config
from goldbots.data import load_csv, synthetic
from goldbots.logsetup import setup_logging
from goldbots.sim_executor import SimExecutor
from goldbots.storage import Storage


def main():
    ap = argparse.ArgumentParser(description="Backtest บอทเทรดทอง 100 ตัว")
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--csv", help="ไฟล์ราคาแท่ง M1")
    ap.add_argument("--synthetic", type=int, metavar="DAYS", help="ใช้ข้อมูลปลอมกี่วัน (ไว้ทดลองโปรแกรม)")
    ap.add_argument("--from", dest="date_from")
    ap.add_argument("--to", dest="date_to")
    ap.add_argument("--qualify-days", type=int, default=3, help="ใช้กี่วันแรกเป็นรอบคัดเลือก (ไม่นับผล)")
    ap.add_argument("--spread", type=float, help="บังคับใช้ spread คงที่ (ดอลลาร์)")
    ap.add_argument("--out", default="out_backtest")
    ap.add_argument("--seed", type=int)
    ap.add_argument("--no-atr", action="store_true", help="ปิด ATR ใช้ SL/TP ดอลลาร์คงที่แบบเดิม (ไว้เทียบผล)")
    ap.add_argument("--no-htf", action="store_true", help="ปิดตัวกรองเทรนด์ใหญ่ (ไว้เทียบผล)")
    ap.add_argument("--old-rules", action="store_true", help="ปิดเกณฑ์กันฟลุ๊ค ข้อ 1-4 (สอบหลายช่วง สถิติ ความทนทาน ต้นทุน) ไว้เทียบผล")
    ap.add_argument("--gate-study", action="store_true", help="วัดว่าเกณฑ์แต่ละข้อคัดบอทที่ทำกำไรในวันถัดไปได้จริงไหม (ไฟล์ gate_study.csv)")
    ap.add_argument("--compare", action="store_true", help="รัน 2 รอบบนราคาชุดเดียวกัน: เกณฑ์เดิม vs เกณฑ์กันฟลุ๊ค แล้วสรุปเทียบกัน")
    ap.add_argument("--seed-live", metavar="DIR", help="หลัง backtest เสร็จ นำสูตรที่บอทและอาจารย์เรียนจากราคาจริงไปตั้งต้นให้ระบบเทรดสด "
                                                     "(เช่น data_live) สถานะเดิมจะถูกสำรองไว้ก่อน")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.no_atr:
        cfg["indicators"]["atr_stops"] = False
    if args.no_htf:
        cfg["indicators"]["htf_filter"] = False
    if args.old_rules:
        cfg.setdefault("exam", {})["enabled"] = False
    m = cfg["market"]
    if args.csv:
        bars = load_csv(args.csv, m["point"], m["default_spread"])
    elif args.synthetic:
        bars = synthetic(args.synthetic + args.qualify_days, spread=m["default_spread"])
        print("⚠ ใช้ข้อมูลปลอม ผลลัพธ์ไม่มีความหมายต่อการลงทุน ใช้แค่ทดสอบว่าโปรแกรมทำงาน")
    else:
        ap.error("ต้องระบุ --csv หรือ --synthetic")
    if args.spread is not None:
        bars = [b._replace(spread=args.spread) for b in bars]
    if args.date_from:
        f = dt.date.fromisoformat(args.date_from)
        bars = [b for b in bars if bar_day(b.time) >= f]
    if args.date_to:
        t = dt.date.fromisoformat(args.date_to)
        bars = [b for b in bars if bar_day(b.time) <= t]
    if len(bars) < 1000:
        sys.exit("ข้อมูลน้อยเกินไป ต้องมีอย่างน้อย 1,000 แท่ง")

    days = sorted({bar_day(b.time) for b in bars})
    if len(days) <= args.qualify_days:
        sys.exit("จำนวนวันในข้อมูลน้อยกว่ารอบคัดเลือก")
    cut = days[args.qualify_days]
    qual = [b for b in bars if bar_day(b.time) < cut]
    test = [b for b in bars if bar_day(b.time) >= cut]

    print(f"ข้อมูล {len(bars):,} แท่ง ({days[0]} ถึง {days[-1]})  รอบคัดเลือก {args.qualify_days} วัน  ทดสอบ {len(days) - args.qualify_days} วัน")
    if args.compare:
        import copy
        res = []
        for label, on in (("เกณฑ์เดิม", False), ("เกณฑ์กันฟลุ๊ค ข้อ 1-4", True)):
            c = copy.deepcopy(cfg)
            c.setdefault("exam", {})["enabled"] = on
            out = os.path.join(args.out, "new_rules" if on else "old_rules")
            print(f"\n▶ รอบ{label} (ผลอยู่ที่ {out})")
            arena, storage = run(c, qual, test, out, args.seed, study=on)
            res.append((label, summary(arena, storage)))
        compare_report(res, f"{days[0]} ถึง {days[-1]}")
        return
    arena, storage = run(cfg, qual, test, args.out, args.seed, study=args.gate_study)
    report(arena, storage, cfg)
    if args.seed_live:
        seed_live(arena, args.seed_live, args.out, f"{days[0]} ถึง {days[-1]}")


class GateStudy:
    """วัดว่าเกณฑ์ไหนคัดบอทที่ "เก่งจริง" ได้: ทุกต้นวัน ดูว่าบอทแต่ละตัวผ่านเกณฑ์อะไรบ้าง แล้ววัดกำไรไม้ฝึกของบอทตัวนั้น
    ในวันถัดไป (อนาคตที่เกณฑ์ยังไม่เห็น) เกณฑ์ที่ดีต้องคัดบอทที่วันถัดไปทำกำไรได้มากกว่าบอททั่วไป"""
    GROUPS = [("all", "บอททุกตัว"), ("old", "ผ่านเกณฑ์เดิม (ชนะ%/PF/กำไรสะสม)"), ("stat", "ผ่านเกณฑ์สถิติ (ข้อ 2)"),
              ("exam", "ผ่านการสอบหลายช่วง + ทนทาน (ข้อ 1+3)"), ("stat_exam", "ผ่านทั้งข้อ 2 และ 1+3"),
              ("new", "ผ่านเกณฑ์ใหม่ทั้งหมด (เดิม + ข้อ 1-3)")]

    def __init__(self, arena):
        self.a = arena
        self.snap = None
        self.acc = {k: [0, 0, 0.0, 0, 0] for k, _ in self.GROUPS}   # [บอท-วัน, ไม้, กำไร, วันที่กำไร, วันที่ขาดทุน]
        self.rows = []

    def _old_ok(self, b):
        a = self.a
        wr = b.recent_wr()
        return (b.jailed is None and len(b.recent) >= a.T["min_trades"] and wr is not None
                and wr * 100 > a.T["min_win_rate"] and a.profit_ok(b) and (not a.T["require_profit"] or b.total > 0))

    def checkpoint(self, day):
        a = self.a
        if self.snap:
            for b in a.bots:
                s0 = self.snap.get(b.id)
                if s0 is None or b.generation != s0["gen"]:
                    continue
                dn, dp = b.trades - s0["n"], b.total - s0["pnl"]
                for k in s0["groups"]:
                    r = self.acc[k]
                    r[0] += 1
                    r[1] += dn
                    r[2] += dp
                    r[3] += dp > 0
                    r[4] += dp < 0
                self.rows.append([str(day), b.id + 1, int("old" in s0["groups"]), int("stat" in s0["groups"]),
                                  int("exam" in s0["groups"]), dn, round(dp, 2)])
        keep = dict(a.exam_stats)
        self.snap = {}
        for b in a.bots:
            if b.jailed is not None:
                continue
            g = ["all"]
            old = self._old_ok(b)
            st = a.stat_ok(b)
            ex = False
            if len(b.hist_pnl) >= 10:
                keep_exam = b.exam
                a.exam_ok(b, force=True)
                ex = bool(b.exam and b.exam.get("streak", 0) > 0)   # ผ่านการสอบรอบนี้ (ไม่นับเงื่อนไขผ่านติดกัน)
                b.exam = keep_exam                                   # ไม่ให้การวัดผลไปเร่งการสอบจริง
            if old:
                g.append("old")
            if st:
                g.append("stat")
            if ex:
                g.append("exam")
            if st and ex:
                g.append("stat_exam")
            if old and st and ex:
                g.append("new")
            self.snap[b.id] = {"n": b.trades, "pnl": b.total, "gen": b.generation, "groups": g}
        a.exam_stats.update(keep)

    def report(self, folder):
        import csv
        with open(os.path.join(folder, "gate_study.csv"), "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["day", "bot", "pass_old", "pass_stat", "pass_exam", "next_day_trades", "next_day_pnl"])
            w.writerows(self.rows)
        print("\n================ เกณฑ์ไหนคัดบอทเก่งจริงได้ (วัดจากผลวันถัดไปที่เกณฑ์ยังไม่เห็น) ================")
        print(f"{'กลุ่ม':<42}{'บอท-วัน':>9}{'กำไรเฉลี่ย/บอท/วัน':>20}{'กำไรเฉลี่ย/ไม้':>16}{'วันกำไร:ขาดทุน':>16}")
        out = {}
        for k, lab in self.GROUPS:
            n, t, p, up, dn = self.acc[k]
            out[k] = {"n": n, "pnl_day": p / n if n else None, "pnl_trade": p / t if t else None, "up": up, "down": dn}
            if not n:
                print(f"{lab:<42}{0:>9}{'ไม่มีบอทผ่าน':>20}")
                continue
            print(f"{lab:<42}{n:>9}{money(p / n):>20}{(money(p / t) if t else '-'):>16}{f'{up}:{dn}':>16}")
        return out


def run(cfg, qual, test, out, seed, study=False):
    if os.path.isdir(out):
        for fn in ("trades.csv", "days.csv", "strategies.json", "bots.csv", "signals.csv"):
            p = os.path.join(out, fn)
            if os.path.exists(p):
                os.remove(p)
    log = setup_logging(os.path.join(out, "backtest.log"), console_level=logging.WARNING)
    storage = Storage(out)
    arena = Arena(cfg, log=log, storage=storage, seed=seed)
    arena.qualify(qual)
    arena.ex = SimExecutor()
    gs = GateStudy(arena) if study else None
    last = None
    n = len(test)
    for i, bar in enumerate(test):
        if gs is not None:
            d = bar_day(bar.time)
            if d != last:
                gs.checkpoint(d)
                last = d
        arena.step(bar)
        if i % 20000 == 0 and i:
            print(f"  ... {i * 100 // n}%  ทีมสะสม {money(arena.team_total)}", flush=True)
    arena.close_all_live("จบการทดสอบ")
    arena.end_day()
    if gs is not None:
        gs.checkpoint(last)
        arena.gate_study = gs.report(out)
    return arena, storage


def summary(arena, storage):
    """ตัวเลขสรุปของรอบหนึ่ง ไว้เทียบกัน"""
    import csv
    hist = arena.history
    eq = peak = dd = 0.0
    for h in hist:
        eq += h["team_pnl"]
        peak = max(peak, eq)
        dd = min(dd, eq - peak)
    live = []
    try:
        with open(storage.p_trades, encoding="utf-8-sig") as f:
            live = [float(r["pnl"]) for r in csv.DictReader(f) if r["live"] == "1"]
    except FileNotFoundError:
        pass
    half = len(hist) // 2
    wins = [x for x in live if x > 0]
    loss = [-x for x in live if x < 0]
    st = arena.exam_stats
    return {"days": len(hist), "team": arena.team_total, "dd": dd,
            "h1": sum(h["team_pnl"] for h in hist[:half]), "h2": sum(h["team_pnl"] for h in hist[half:]),
            "up": sum(1 for h in hist if h["team_pnl"] > 0), "down": sum(1 for h in hist if h["team_pnl"] < 0),
            "idle": sum(1 for h in hist if h["team_pnl"] == 0),
            "n": len(live), "wr": len(wins) / len(live) if live else None,
            "exp": sum(live) / len(live) if live else None,
            "pf": sum(wins) / sum(loss) if loss else None,
            "worst": min((h["team_pnl"] for h in hist), default=0.0),
            "bots_live": sum(1 for b in arena.bots if b.live_trades),
            "paper": sum(b.total for b in arena.bots), "paper_n": sum(b.trades for b in arena.bots),
            "exam": dict(st), "wf": arena.teachers.wf_rejected, "rob": arena.teachers.robust_rejected,
            "slip": arena.slip}


def compare_report(res, period):
    (la, a), (lb, b) = res
    f = lambda v: "-" if v is None else money(v)
    pc = lambda v: "-" if v is None else f"{v * 100:.1f}%"
    rows = [("กำไรทีมเงินจริง (จำลอง) รวม", f(a["team"]), f(b["team"])),
            ("  ครึ่งแรกของช่วง", f(a["h1"]), f(b["h1"])),
            ("  ครึ่งหลังของช่วง", f(a["h2"]), f(b["h2"])),
            ("ขาดทุนสะสมจากจุดสูงสุด (max drawdown)", f(a["dd"]), f(b["dd"])),
            ("วันที่แย่ที่สุด", f(a["worst"]), f(b["worst"])),
            ("วันกำไร / ขาดทุน / ไม่ได้เทรด", f"{a['up']} / {a['down']} / {a['idle']}", f"{b['up']} / {b['down']} / {b['idle']}"),
            ("ไม้เงินจริงทั้งหมด", str(a["n"]), str(b["n"])),
            ("อัตราชนะไม้เงินจริง", pc(a["wr"]), pc(b["wr"])),
            ("กำไรเฉลี่ยต่อไม้เงินจริง", f(a["exp"]), f(b["exp"])),
            ("profit factor ไม้เงินจริง", "-" if a["pf"] is None else f"{a['pf']:.2f}", "-" if b["pf"] is None else f"{b['pf']:.2f}"),
            ("บอทที่เคยได้เทรดเงินจริง", f"{a['bots_live']} ตัว", f"{b['bots_live']} ตัว"),
            ("ไม้ฝึกทั้งหมด (ทุกบอท)", f"{a['paper_n']:,}", f"{b['paper_n']:,}"),
            ("slippage ที่คิดต่อครั้ง", f"${a['slip']:.2f}", f"${b['slip']:.2f}")]
    print(f"\n================ เทียบผล: {la} vs {lb} ({period}) ================")
    w = max(len(r[0]) for r in rows) + 2
    print(f"{'':<{w}}{la:>22}{lb:>26}")
    for r in rows:
        print(f"{r[0]:<{w}}{r[1]:>22}{r[2]:>26}")
    e = b["exam"]
    if not e["taken"]:
        print("\nการสอบก่อนขึ้นทีม: ไม่มีบอทผ่านด่านก่อนหน้า (ชนะ%/PF และเกณฑ์สถิติ ข้อ 2) จึงยังไม่มีใครถึงขั้นสอบ")
    else:
      print(f"\nการสอบก่อนขึ้นทีม (รอบ{lb}): สอบ {e['taken']:,} ครั้ง ผ่าน {e['passed']:,} | ตกเพราะไม้น้อย {e['fail_trades']:,}"
            f" | ตกเพราะกำไรไม่สม่ำเสมอหลายช่วง {e['fail_seg']:,} | ตกเพราะขยับสูตรแล้วพัง {e['fail_robust']:,}")
    print(f"สูตรใหม่ของอาจารย์ที่ถูกปัด: สอบกับราคาที่ไม่เคยเห็นแล้วแย่กว่า {b['wf']:,} สูตร | ขยับค่าแล้วพัง {b['rob']:,} สูตร")
    print("หมายเหตุ: ไม้ฝึกในรอบเกณฑ์ใหม่หัก slippage ด้วย จึงดูขาดทุนมากกว่า (ใกล้ของจริงกว่า)")
    print("ผล backtest ไม่รับประกันผลในอนาคต ใช้ดูว่าเกณฑ์ไหนกันความเสียหายได้ดีกว่าบนราคาจริงชุดเดียวกัน")


def seed_live(arena, folder, bt_out, period):
    """นำสูตรที่เรียนจากราคาย้อนหลังไปตั้งต้นให้ระบบเทรดสด: เก็บสูตร ผลไม้ล่าสุด อาจารย์ หัวแถว และเส้นการเรียนรู้
    แต่ล้างตัวเลขเงิน/ทีม/การแข่งขันของ backtest (เป็นเงินจำลอง)"""
    import json
    import shutil
    import time
    st = arena.to_state()
    for b in st["bots"]:
        b.update(live=False, pos=None, jailed=None, paused=False, today=0.0, live_today=0.0, live_total=0.0,
                 live_trades=0, live_wins=0, today_trades=0, today_wins=0, consec_losses=0)
    st.update(team_today=0.0, team_total=0.0, days_hit=0, days_done=0, target_hit=False, halted=False,
              manual_halt=False, history=[], day=None)
    for k in ("contest", "guards", "news", "signals", "dash"):
        st.pop(k, None)
    st["seeded_from"] = {"period": period, "at": time.strftime("%Y-%m-%d %H:%M")}
    os.makedirs(folder, exist_ok=True)
    p = os.path.join(folder, "state.json")
    if os.path.exists(p):
        bk = os.path.join(folder, time.strftime("state.backup-%Y%m%d-%H%M%S.json"))
        shutil.copy2(p, bk)
        print(f"สำรองสถานะเดิมไว้ที่ {bk}")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False)
    # สูตรที่เซฟไว้ระหว่าง backtest (ชนะถึงเกณฑ์) เพิ่มเข้าคลังของระบบเทรดสด ให้หัวแถวและอาจารย์ใช้ต่อ
    src = os.path.join(bt_out, "strategies.json")
    if os.path.exists(src):
        dst = os.path.join(folder, "strategies.json")
        old = json.load(open(dst, encoding="utf-8")) if os.path.exists(dst) else []
        new = json.load(open(src, encoding="utf-8"))
        with open(dst, "w", encoding="utf-8") as f:
            json.dump(old + new, f, ensure_ascii=False, indent=1)
    print(f"ตั้งต้นระบบเทรดสดแล้ว ({folder}) บอทและอาจารย์เริ่มจากสูตรที่เรียนจากราคาช่วง {period}")
    print("รัน python run_live.py ได้เลย (ไม่ต้องใส่ --reset)")


def report(arena, storage, cfg):
    T = cfg["team"]
    hist = arena.history
    print("\n================ สรุปผล Backtest ================")
    ind = cfg["indicators"]
    X = arena.X
    if X["on"]:
        e = arena.exam_stats
        print(f"เกณฑ์กันฟลุ๊ค: เปิด | slippage ${arena.slip:.2f}/ครั้ง | สถิติ {X['stat_n']} ไม้ ค่า t ≥ {X['t_min']:g}"
              f" | สอบ {e['taken']:,} ครั้ง ผ่าน {e['passed']:,} | อาจารย์ปัดสูตร (ข้อสอบ {arena.teachers.wf_rejected:,}"
              f" / ความทนทาน {arena.teachers.robust_rejected:,})")
    else:
        print("เกณฑ์กันฟลุ๊ค: ปิด (ใช้เกณฑ์เดิม)")
    print(f"Indicator: ATR ตั้ง SL/TP {'เปิด' if ind['atr_stops'] else 'ปิด'} | ตัวกรองเทรนด์ใหญ่ {'เปิด' if ind['htf_filter'] else 'ปิด'}")
    print(f"ขนาดออเดอร์ {cfg['bots']['lot']} ล็อต  เกณฑ์ชนะเกิน {T['min_win_rate']}% ใน {T['recent_window']} ไม้ล่าสุด"
          f"  เป้า {money(T['daily_target'])}/วัน  เพดานขาดทุน {money(-T['max_daily_loss'])}/วัน")
    if hist:
        eq, peak, dd = 0.0, 0.0, 0.0
        for h in hist:
            eq += h["team_pnl"]
            peak = max(peak, eq)
            dd = min(dd, eq - peak)
        traded = [h for h in hist if h["live_bots"] != "-" or h["team_pnl"] != 0]
        print(f"จำนวนวัน {len(hist)}  ถึงเป้า {arena.days_hit} วัน ({arena.days_hit * 100 / len(hist):.0f}%)"
              f"  วันที่ทีมว่าง/ไม่ได้เทรด {len(hist) - len(traded)} วัน")
        print(f"กำไรทีมรวม {money(arena.team_total)}  เฉลี่ย/วัน {money(arena.team_total / len(hist))}")
        print(f"วันที่ดีที่สุด {money(max(h['team_pnl'] for h in hist))}  วันที่แย่ที่สุด {money(min(h['team_pnl'] for h in hist))}"
              f"  ขาดทุนสะสมจากจุดสูงสุด (max drawdown) {money(dd)}")
    live_w = [b for b in arena.bots if b.live_trades]
    tw = sum(b.live_wins for b in live_w)
    tt = sum(b.live_trades for b in live_w)
    if tt:
        print(f"ไม้เงินจริงทั้งหมด {tt} ไม้  ชนะ {tw * 100 / tt:.1f}%")
    try:
        import csv
        wins, losses = [], []
        with open(storage.p_trades, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                if r["live"] == "1":
                    (wins if float(r["pnl"]) > 0 else losses).append(float(r["pnl"]))
        if wins and losses:
            aw, al = sum(wins) / len(wins), -sum(losses) / len(losses)
            print(f"กำไรเฉลี่ยต่อไม้ที่ชนะ {money(aw)}  ขาดทุนเฉลี่ยต่อไม้ที่แพ้ {money(-al)}  อัตราส่วน {aw / al:.2f} : 1")
            print(f"  (ชนะ {len(wins)} ไม้ได้รวม {money(sum(wins))} / แพ้ {len(losses)} ไม้เสียรวม {money(sum(losses))})")
    except FileNotFoundError:
        pass
    st = arena.sig_stats
    if st["n"]:
        print(f"\nจุดแนะนำเข้าซื้อขาย (สูตรทีม) {st['n']} จุด: ถึง TP {st['tp']} | โดน SL {st['sl']} | หมดเวลา {st['timeout']}"
              f"  ได้กำไร {st['wins'] * 100 / st['n']:.0f}%  รวม {money(st['pnl'])} ต่อ 0.01 ล็อต (เฉลี่ย {money(st['pnl'] / st['n'])} ต่อจุด)")
        if st["buy_n"]:
            print(f"  จุดซื้อ {st['buy_n']} จุด ได้กำไร {st['buy_wins'] * 100 / st['buy_n']:.0f}%", end="")
        if st["sell_n"]:
            print(f"  | จุดขาย {st['sell_n']} จุด ได้กำไร {st['sell_wins'] * 100 / st['sell_n']:.0f}%", end="")
        print()
    print("\nบอท            ไม้ทั้งหมด  ชนะสะสม  ชนะล่าสุด   กำไรสะสม   ไม้เงินจริง  ชนะเงินจริง  กำไรเงินจริง")
    rows = []
    for b in sorted(arena.bots, key=lambda x: x.live_total, reverse=True):
        wr = b.recent_wr()
        row = {"bot": b.id + 1, "name": b.name, "trades": b.trades,
               "win_rate": round(b.wins * 100 / b.trades, 1) if b.trades else 0,
               "recent_win_rate": round(wr * 100, 1) if wr is not None else 0, "total": round(b.total, 2),
               "live_trades": b.live_trades,
               "live_win_rate": round(b.live_wins * 100 / b.live_trades, 1) if b.live_trades else 0,
               "live_total": round(b.live_total, 2), "violations": b.violations}
        rows.append(row)
        print(f"{b.id + 1:02d} {b.name:<9} {b.trades:>8}  {row['win_rate']:>6.1f}%  {row['recent_win_rate']:>7.1f}%"
              f"  {money(b.total):>10}  {b.live_trades:>9}  {row['live_win_rate']:>9.1f}%  {money(b.live_total):>11}")
    import csv
    with open(os.path.join(storage.folder, "bots.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"\nไฟล์ผลลัพธ์อยู่ในโฟลเดอร์ {storage.folder}/ : days.csv (รายวัน), trades.csv (ทุกไม้), signals.csv (จุดแนะนำ), bots.csv, strategies.json")
    print("ข้อควรจำ: ผล backtest ไม่รับประกันผลในอนาคต ต้องทดสอบกับบัญชีทดลองต่ออย่างน้อย 1-3 เดือน")


if __name__ == "__main__":
    main()
