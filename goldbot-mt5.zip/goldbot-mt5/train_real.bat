@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
py -3.12 -c "import sys" >nul 2>&1 && set "PY=py -3.12"
echo ขั้นที่ 1/2: ดึงราคา XAUUSD แท่ง 1 นาทีย้อนหลัง 365 วันจาก MT5 (เปิด MT5 และล็อกอินไว้ก่อน)
%PY% export_history.py --days 365 --out data || goto :err
for %%f in (data\*_M1.csv) do set "CSV=%%f"
echo ขั้นที่ 2/2: ให้บอทและอาจารย์เรียนจากราคาจริง แล้วนำสูตรไปตั้งต้นระบบเทรดสด (ใช้เวลาประมาณ 20-40 นาที)
%PY% backtest.py --csv "%CSV%" --out out_backtest --seed-live data_live || goto :err
echo เสร็จแล้ว ดูผล backtest ในโฟลเดอร์ out_backtest แล้วรัน start.bat เพื่อเริ่มเทรดบนบัญชี Demo
pause
exit /b 0
:err
echo เกิดข้อผิดพลาด ดูข้อความด้านบน
pause
