"""ดึงราคาทองแท่ง M1 ย้อนหลังจาก MT5 มาเก็บเป็น CSV สำหรับ backtest (ต้องรันบน Windows ที่เปิด MT5 อยู่)

ตัวอย่าง:  python export_history.py --days 365
"""
import argparse
import csv
import datetime as dt
import os
import sys

from goldbots.config import load_config


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--days", type=int, default=365)
    ap.add_argument("--out", default="data")
    args = ap.parse_args()
    cfg = load_config(args.config)
    try:
        import MetaTrader5 as mt5
    except ImportError:
        sys.exit("ยังไม่ได้ติดตั้ง MetaTrader5: pip install MetaTrader5")
    kw = {"path": cfg["account"]["terminal_path"]} if cfg["account"]["terminal_path"] else {}
    if not mt5.initialize(**kw):
        sys.exit(f"เชื่อมต่อ MT5 ไม่ได้: {mt5.last_error()}")
    sym = cfg["market"]["symbol"]
    mt5.symbol_select(sym, True)
    info = mt5.symbol_info(sym)
    if info is None:
        sys.exit(f"ไม่พบสัญลักษณ์ {sym}")
    to = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=1)
    fr = to - dt.timedelta(days=args.days + 1)
    rows = []
    # ดึงทีละ 30 วัน ป้องกันข้อจำกัดจำนวนแท่ง
    cur = fr
    while cur < to:
        nxt = min(cur + dt.timedelta(days=30), to)
        r = mt5.copy_rates_range(sym, mt5.TIMEFRAME_M1, cur, nxt)
        if r is not None:
            rows.extend(r.tolist())
        cur = nxt
    mt5.shutdown()
    if not rows:
        sys.exit("ไม่ได้ข้อมูลเลย ลองเปิดกราฟ XAUUSD M1 ใน MT5 แล้วเลื่อนย้อนหลังให้โหลดข้อมูลก่อน "
                 "และตั้ง Tools > Options > Charts > Max bars in chart เป็น Unlimited")
    seen, uniq = set(), []
    for x in rows:
        if x[0] not in seen:
            seen.add(x[0])
            uniq.append(x)
    uniq.sort(key=lambda x: x[0])
    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, f"{sym}_M1.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["time", "open", "high", "low", "close", "tick_volume", "spread", "real_volume"])
        w.writerows(uniq)
    d0 = dt.datetime.fromtimestamp(uniq[0][0], dt.timezone.utc)
    d1 = dt.datetime.fromtimestamp(uniq[-1][0], dt.timezone.utc)
    print(f"บันทึก {len(uniq):,} แท่ง ({d0:%Y-%m-%d} ถึง {d1:%Y-%m-%d}) ไว้ที่ {path}")
    if (d1 - d0).days < args.days * 0.8:
        print("⚠ ได้ข้อมูลน้อยกว่าที่ขอ โบรกเกอร์อาจเก็บข้อมูล M1 ย้อนหลังได้จำกัด")


if __name__ == "__main__":
    main()
