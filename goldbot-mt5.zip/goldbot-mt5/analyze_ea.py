"""เรียนรู้จาก EA ตัวอื่น: อ่านรายงาน MT5 ของ EA แล้ว
  1) ตรวจพฤติกรรมเสี่ยง (เบิ้ลไม้ / วางไม้ซ้อน / ล็อกไม้ / ไม่มี SL)
  2) ดูว่า EA เข้าไม้ตอนไหน (ตามเทรนด์ไหม ช่วงตลาดไหน RSI เท่าไร)
  3) หาสูตรของระบบเราที่เข้าไม้ใกล้เคียง EA ที่สุด (ลอกเฉพาะจังหวะเข้า-ออก ไม่ลอกการเบิ้ลไม้/ล็อกไม้)
  4) ทดสอบสูตรที่ได้กับราคาช่วงเดียวกัน (หักต้นทุนจริง) แล้วบันทึกลง ea_recipes.json
     อาจารย์ชาร์ลีจะนำไปลองเทรดและต้องผ่านด่านกันฟลุ๊คเหมือนสูตรอื่น ก่อนสอนบอท

ตัวอย่าง:
  python analyze_ea.py --report ReportTester.xlsx --prices data/XAUUSD_M1.csv --name "Cheetah Lock"
  python analyze_ea.py --report ReportHistory.html                 (ตรวจความเสี่ยงอย่างเดียว)
วิธีได้ไฟล์รายงาน: MT5 → Strategy Tester → รันจบ → คลิกขวาแท็บ Backtest → Report → Open XML (หรือ HTML)
ราคา M1 ช่วงเดียวกัน: python export_history.py --days 365 --out data
"""
import argparse
import bisect
import json
import os
import random
import statistics
import sys
import time

import pyenv_check  # ถ้าพิมพ์ python แล้วตัวนั้นไม่มีไลบรารี จะสลับไปใช้ Python ที่มีครบ หรือติดตั้งให้
pyenv_check.ensure(need_mt5=False)

from goldbots.bots import GENE, IND, TF, configure, fix_genome, gene_default, min_bars
from goldbots.config import load_config
from goldbots.data import load_csv
from goldbots.eacheck import FLAG_TH, parse_positions, risk_check
from goldbots.fastsig import Window, scores_and_stops
from goldbots.indicators import Series
from goldbots.teachers import shadow_test_fast

ENTRY_KEYS = ["wT", "wM", "wB", "fast", "slow", "rsiN", "rsiLo", "rsiHi", "brkN", "thr", "htfN", "htfW",
              "sA", "sE", "sU", "vH"]


def money(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def main():
    ap = argparse.ArgumentParser(description="เรียนรู้จาก EA ตัวอื่นผ่านรายงาน MT5")
    ap.add_argument("--report", required=True, help="ไฟล์รายงาน MT5 (.xlsx / .html)")
    ap.add_argument("--prices", help="ไฟล์ราคา M1 ช่วงเดียวกับรายงาน (จาก export_history.py) ถ้าไม่ใส่ จะตรวจความเสี่ยงอย่างเดียว")
    ap.add_argument("--name", help="ชื่อ EA (ใช้ตั้งชื่อสูตร)")
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--out", default="ea_recipes.json")
    ap.add_argument("--tries", type=int, default=2000, help="จำนวนสูตรที่ลองค้นหา (มากขึ้น = ใกล้ขึ้นแต่นานขึ้น)")
    ap.add_argument("--seed", type=int, default=1)
    args = ap.parse_args()
    name = args.name or os.path.splitext(os.path.basename(args.report))[0]
    lines = []

    def say(s=""):
        print(s, flush=True)
        lines.append(s)

    ps, how = parse_positions(args.report)
    rc = risk_check(ps)
    say(f"================ EA: {name} ================")
    say(f"อ่านจาก {how}  ช่วง {_d(ps[0]['open'])} ถึง {_d(ps[-1]['close'])}")
    say(f"ผลของ EA: {rc['trades']} ไม้ ชนะ {rc['win_rate'] * 100:.1f}%  กำไรสุทธิ {money(rc['net'])}"
        f"  PF {rc['pf']:.2f}" if rc["pf"] else f"ผลของ EA: {rc['trades']} ไม้ กำไรสุทธิ {money(rc['net'])}")
    say(f"  ชนะเฉลี่ย {money(rc['avg_win'])}  แพ้เฉลี่ย {money(rc['avg_loss'])}  แพ้หนักสุด {money(rc['worst'])}"
        f"  แพ้ติดกันสูงสุด {rc['max_consec_losses']} ไม้")
    say(f"  ขาดทุนสะสมจากจุดสูงสุด (นับไม้ที่ปิดแล้ว) {money(rc['max_dd_closed'])}  ถือไม้นานสุด {rc['hold_max_min'] / 60:.1f} ชม."
        f"  (ค่ากลาง {rc['hold_median_min']:.0f} นาที)")
    say("\n---- ตรวจพฤติกรรมเสี่ยง ----")
    if rc["flags"]:
        for k, msg in rc["flags"]:
            say(f"  ⚠ {msg}")
    else:
        say("  ไม่พบการเบิ้ลไม้ วางไม้ซ้อน หรือล็อกไม้")
    for n in rc["notes"]:
        say(f"  หมายเหตุ: {n}")
    risky = {k for k, _ in rc["flags"]} & {"martingale", "grid", "lock", "no_sl"}
    if risky:
        say("  → ระบบเราจะไม่ลอกการบริหารไม้แบบนี้ (ขัดกับกฎทุกไม้ต้องมี SL และเพดานขาดทุนต่อวัน)"
            " จะลองเรียนเฉพาะจังหวะเข้าไม้เท่านั้น")

    if not args.prices:
        say("\n(ไม่ได้ใส่ --prices จึงยังไม่วิเคราะห์จังหวะเข้าไม้ ใส่ไฟล์ราคา M1 ช่วงเดียวกันเพื่อสร้างสูตร)")
        _save_txt(lines, name)
        return

    cfg = load_config(args.config)
    configure(cfg)
    m = cfg["market"]
    bars = load_csv(args.prices, m["point"], m["default_spread"])
    t0, t1 = ps[0]["open"] - 4 * 86400, ps[-1]["close"] + 3600
    bars = [b for b in bars if t0 <= b.time <= t1]
    if len(bars) < min_bars() + 1000:
        sys.exit("ไฟล์ราคาไม่ครอบคลุมช่วงเวลาของรายงาน (ต้องเป็นราคา M1 ช่วงเดียวกัน และเวลาเซิร์ฟเวอร์เดียวกัน)")
    s = Series()
    for b in bars:
        s.push(b.close, b.high, b.low, b.time)
    W = Window(s, bars, 0)
    times = [b.time for b in bars]
    tf = TF()
    gate = (W.gate & (W.L >= min_bars())).tolist()
    gidx = [k for k, g in enumerate(gate) if g]

    # ---- จังหวะเข้าของ EA ตรงกับแท่ง TF ไหน ----
    lab = {}
    used = 0
    for p in ps:
        j = bisect.bisect_right(times, p["open"] - 60) - 1          # แท่งล่าสุดที่ปิดแล้วก่อน EA เข้า
        if j < 0:
            continue
        gi = bisect.bisect_left(gidx, j)
        for cand in (gi - 1, gi):                                    # แท่ง TF ที่ใกล้ที่สุด (ก่อนหรือหลัง)
            if 0 <= cand < len(gidx) and abs(gidx[cand] - j) <= tf:
                lab.setdefault(gidx[cand], p["dir"])
                used += 1
                break
    if len(lab) < 10:
        sys.exit("จับคู่จังหวะเข้าของ EA กับราคาได้น้อยเกินไป (ตรวจว่าไฟล์ราคาเป็นช่วงเดียวกันและเวลาเซิร์ฟเวอร์เดียวกัน)")
    say(f"\n---- จังหวะเข้าไม้ของ EA (กรอบเวลา {tf} นาที) ----")
    _describe(say, W, lab, ps)

    # ---- หาสูตรที่เข้าไม้ใกล้ EA ที่สุด ----
    rng = random.Random(args.seed)
    # จุดที่ EA ถือไม้อยู่ (และไม่ได้เข้าไม้ใหม่) ไม่นับ เพราะ EA ไม่ได้ "ว่าง" ให้ตัดสินใจ
    spans = sorted((p["open"], p["close"]) for p in ps)
    busy = set()
    si = 0
    active = []
    for k in gidx:
        tk = times[k] + 60
        while si < len(spans) and spans[si][0] <= tk:
            active.append(spans[si])
            si += 1
        active = [x for x in active if x[1] > tk]
        if active and k not in lab:
            busy.add(k)
    gidx_set = [k for k in gidx if k not in busy]

    def score_genome(g):
        sc, _, _ = scores_and_stops(g, W)
        tp = fp = 0
        for k in gidx_set:
            v = sc[k]
            if abs(v) >= g["thr"]:
                d = 1 if v > 0 else -1
                if lab.get(k) == d:
                    tp += 1
                else:
                    fp += 1
        fn = len(lab) - tp
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
        return f1, prec, rec

    base = {k: gene_default(k) for k in GENE}
    base.update(be=2.0, trl=0.0)
    best = None
    t_start = time.time()
    say(f"\n---- ค้นหาสูตรที่เข้าไม้ใกล้ EA ที่สุด (ลอง {args.tries} สูตร) ----")
    n_rand = args.tries // 4
    for i in range(args.tries):
        if i < n_rand or best is None:
            g = dict(base)
            for k in ENTRY_KEYS:
                lo, hi = GENE[k]
                g[k] = rng.uniform(lo, hi)
        else:                                       # ขยับจากสูตรที่ดีที่สุดทีละน้อย
            g = dict(best[1])
            step = 0.12 if i < args.tries * 3 // 4 else 0.04
            for k in rng.sample(ENTRY_KEYS, rng.choice((1, 2, 3))):
                lo, hi = GENE[k]
                g[k] += rng.gauss(0, step) * (hi - lo)
        fix_genome(g)
        r = score_genome(g)
        if best is None or r[0] > best[0][0]:
            best = (r, g)
        if (i + 1) % 100 == 0:
            print(f"  ... {i + 1}/{args.tries}  ใกล้ที่สุดตอนนี้ F1 {best[0][0]:.2f}", flush=True)
    (f1, prec, rec), g = best
    say(f"  สูตรที่ใกล้ที่สุด: เข้าไม้ตรงจังหวะ EA {rec * 100:.0f}% ของไม้ของ EA, ไม้ที่สูตรเข้าแล้วตรงกับ EA {prec * 100:.0f}%"
        f"  (F1 {f1:.2f}, ใช้เวลา {time.time() - t_start:.0f} วินาที)")
    if f1 < 0.15:
        say("  → ใกล้กันน้อยมาก EA ตัวนี้อาจใช้ข้อมูลที่ระบบเราไม่มี (เช่น ข่าว เวลาเฉพาะ หรือแพทเทิร์นแท่งเทียน) สูตรที่ได้อาจไม่เหมือน EA จริง")

    # ---- ระยะ SL/TP จากไม้จริงของ EA (หน่วย ATR ของแท่ง TF) ----
    atr = W.atr_s
    sl_m, tp_m = [], []
    for p in ps:
        j = bisect.bisect_right(times, p["open"] - 60) - 1
        if j < 0 or atr[j] <= 0 or p.get("entry") is None:
            continue
        if p.get("sl"):
            sl_m.append(abs(p["entry"] - p["sl"]) / atr[j])
        elif p["profit"] < 0 and p.get("exit"):
            sl_m.append(abs(p["exit"] - p["entry"]) / atr[j])
        if p.get("tp"):
            tp_m.append(abs(p["tp"] - p["entry"]) / atr[j])
        elif p["profit"] > 0 and p.get("exit"):
            tp_m.append(abs(p["exit"] - p["entry"]) / atr[j])
    note = []
    if sl_m:
        v = statistics.median(sl_m)
        g["slA"] = v
        if v > GENE["slA"][1]:
            note.append(f"EA ยอมขาดทุนลึกกว่าที่ระบบเราอนุญาต ({v:.1f} เท่า ATR) ใช้ SL สูงสุดของระบบเราแทน")
    if tp_m:
        g["tpA"] = statistics.median(tp_m)
    fix_genome(g)
    say(f"  ระยะตัดขาดทุน {g['slA']:.2f} × ATR  ระยะทำกำไร {g['tpA']:.2f} × ATR (จากไม้จริงของ EA)")
    for n in note:
        say(f"  หมายเหตุ: {n}")

    # ---- ทดสอบสูตรที่ได้ กับราคาช่วงเดียวกัน (ไม้ละ 0.01 ล็อต หักต้นทุน) ----
    X = cfg.get("exam", {})
    slip = float(X.get("slippage", 0.05)) if X.get("enabled", True) else 0.0
    r = shadow_test_fast(g, W, 0.01, m["contract_size"], m.get("commission_per_lot", 0.0),
                         cfg["supervisor"]["max_hold_bars"], slip, 3)
    ea_norm = sum(p["profit"] * 0.01 / p["volume"] for p in ps if p.get("volume"))
    say("\n---- เทียบผล (ปรับเป็นไม้ละ 0.01 ล็อตทั้งคู่) ----")
    say(f"  EA จริง: {rc['trades']} ไม้  {money(ea_norm)}")
    say(f"  สูตรที่ลอกจังหวะ (มี SL ทุกไม้ ไม่เบิ้ล ไม่ล็อก): {r['trades']} ไม้ ชนะ "
        f"{(r['wr'] or 0) * 100:.0f}%  {money(r['pnl'])}  แบ่ง 3 ช่วง: " + " / ".join(money(x) for x in r["seg"]))
    if risky and ea_norm > 0 >= r["pnl"]:
        say("  → กำไรของ EA น่าจะมาจากการบริหารไม้ (เบิ้ล/ซ้อน/ล็อก) มากกว่าจังหวะเข้า เมื่อใส่ SL ทุกไม้แล้วไม่เหลือกำไร")

    # ---- บันทึกให้อาจารย์ชาร์ลีนำไปลอง ----
    rec_doc = {"name": f"EA {name}", "source": os.path.basename(args.report), "created": time.strftime("%Y-%m-%d %H:%M"),
               "tf": tf, "params": {k: round(float(g[k]), 4) for k in GENE},
               "match": {"f1": round(f1, 3), "precision": round(prec, 3), "recall": round(rec, 3)},
               "ea": {"trades": rc["trades"], "net": round(rc["net"], 2), "net_001": round(ea_norm, 2),
                      "win_rate": round(rc["win_rate"], 3), "flags": [k for k, _ in rc["flags"]]},
               "clone": {"trades": r["trades"], "pnl": round(r["pnl"], 2), "seg": [round(x, 2) for x in r["seg"]]}}
    docs = []
    if os.path.exists(args.out):
        try:
            docs = json.load(open(args.out, encoding="utf-8")).get("recipes", [])
        except (OSError, ValueError):
            docs = []
    docs = [d for d in docs if d.get("name") != rec_doc["name"]] + [rec_doc]
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"recipes": docs}, f, ensure_ascii=False, indent=1)
    say(f"\nบันทึกสูตร \"{rec_doc['name']}\" ลง {args.out} แล้ว")
    say("ระบบเทรด (run_live.py / backtest.py) จะให้อาจารย์ชาร์ลีนำสูตรนี้ไปทดสอบย้อนหลัง ข้อสอบที่ไม่เคยเห็น ความทนทาน"
        " และลองเทรดแบบไม่ใช้เงิน ถ้าผ่านถึงจะนำไปสอนบอท (ถ้าไม่ผ่าน สูตรนี้จะไม่ถูกใช้)")
    _save_txt(lines, name)


def _d(t):
    import datetime as dt
    return dt.datetime.fromtimestamp(t, dt.timezone.utc).strftime("%Y-%m-%d %H:%M") if t else "?"


def _describe(say, W, lab, ps):
    """สรุปลักษณะจังหวะเข้าของ EA เทียบกับตัวชี้วัดพื้นฐาน"""
    import numpy as np
    tf = W.tf
    ks = sorted(lab)
    fast, slow = W.sma(20 * tf), W.sma(50 * tf)
    rsi = W.rsi(14 * tf)
    hi, lo = W.hilo(20 * tf)
    n = len(ks)
    with_tr = sum(1 for k in ks if (fast[k] - slow[k]) * lab[k] > 0)
    rsi_lo = sum(1 for k in ks if rsi[k] < 35)
    rsi_hi = sum(1 for k in ks if rsi[k] > 65)
    brk = sum(1 for k in ks if (lab[k] > 0 and W.p[k] > hi[k]) or (lab[k] < 0 and W.p[k] < lo[k]))
    buy = sum(1 for k in ks if lab[k] > 0)
    ses = {0: 0, 1: 0, 2: 0}
    for k in ks:
        ses[int(W.ses[k])] += 1
    hv = sum(1 for k in ks if W.hv[k])
    say(f"  ซื้อ {buy} / ขาย {n - buy} ไม้")
    say(f"  เข้าตามเทรนด์ (เส้น 20 กับ 50 แท่ง) {with_tr * 100 // n}%  สวนเทรนด์ {100 - with_tr * 100 // n}%")
    say(f"  RSI ต่ำกว่า 35 ตอนเข้า {rsi_lo * 100 // n}%  สูงกว่า 65 {rsi_hi * 100 // n}%  เข้าตอนราคาทะลุกรอบ 20 แท่ง {brk * 100 // n}%")
    say(f"  ช่วงตลาด: เอเชีย {ses[0] * 100 // n}%  ยุโรป {ses[1] * 100 // n}%  สหรัฐ {ses[2] * 100 // n}%"
        f"  ตอนตลาดผันผวนแรง {hv * 100 // n}%")


def _save_txt(lines, name):
    fn = f"ea_report_{''.join(c if c.isalnum() else '_' for c in name)}.txt"
    with open(fn, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"(สรุปเก็บไว้ที่ {fn})")


if __name__ == "__main__":
    main()
