"""ครูสอนสูตร 5 คน: ไม่เทรด แต่ทดสอบสูตรกับราคาย้อนหลังเพื่อหาสูตรที่ดีที่สุดในวิชาของตัวเอง
แล้วนำไปสอนบอททุกตัวที่เทรด (ทั้งทีมเทรดจริงและกลุ่มเรียนรู้) เฉพาะเมื่อทดสอบแล้วว่าช่วยให้บอทตัวนั้นดีขึ้นจริง"""
from .bots import GENE, fix_genome, signal_at

# ชื่อ วิชา ค่าที่สอน และตัวอย่างคำแนะนำ (ใช้แสดงในหน้าจอ)
TEACHERS = [
    ("ครูตะวัน", "ตามเทรนด์", ["wT", "fast", "slow"]),
    ("ครูจันทร์", "เทรดสวนกลับ (RSI)", ["wM", "rsiN", "rsiLo", "rsiHi"]),
    ("ครูฟ้า", "เบรกเอาต์", ["wB", "brkN"]),
    ("ครูดิน", "จุดทำกำไร/ตัดขาดทุน", ["sl", "tp"]),
    ("ครูลม", "จังหวะเข้าเทรด", ["thr"]),
]
MIN_L = 72  # ต้องมีราคาย้อนหลังอย่างน้อยเท่านี้ถึงคำนวณสัญญาณได้


def shadow_test(g, s, bars, L0, lot, contract, comm, max_hold):
    """ทดสอบสูตร g กับแท่งราคา bars (ไม่ส่งออเดอร์จริง) แบบเดียวกับที่บอทเทรดจริง
    bars[k] คือแท่งที่มีราคาปิดสะสมถึง L0 + k + 1 แท่ง"""
    pos = None
    pnl = peak = dd = 0.0
    trades = wins = 0
    thr = g["thr"]
    for k, bar in enumerate(bars):
        if pos is not None:
            d, entry, sl, tp, k0 = pos
            ex = None
            if d > 0:
                if bar.low <= sl:
                    ex = sl
                elif bar.high >= tp:
                    ex = tp
            else:
                if bar.high + bar.spread >= sl:
                    ex = sl
                elif bar.low + bar.spread <= tp:
                    ex = tp
            if ex is None and k - k0 >= max_hold:
                ex = bar.close if d > 0 else bar.close + bar.spread
            if ex is None:
                continue
            p = (ex - entry) * d * contract * lot - comm * lot
            pnl += p
            trades += 1
            wins += p > 0
            peak = max(peak, pnl)
            dd = max(dd, peak - pnl)
            pos = None
        L = L0 + k + 1
        if L < MIN_L:
            continue
        score = signal_at(g, s, L)[3]
        if abs(score) >= thr:
            d = 1 if score > 0 else -1
            entry = bar.close + bar.spread if d > 0 else bar.close
            pos = (d, entry, entry - d * g["sl"], entry + d * g["tp"], k)
    return {"pnl": pnl, "dd": dd, "trades": trades, "wins": wins,
            "wr": wins / trades if trades else None}


def grade(r, goal):
    """คะแนนของผลทดสอบ: กำไร หักความเสี่ยง (ขาดทุนสะสมจากจุดสูงสุด) และให้โบนัสเมื่ออัตราชนะถึงเกณฑ์"""
    if r["trades"] < 5:           # ไม้น้อยเกินไป เชื่อผลไม่ได้
        return r["pnl"] - 0.5 * r["dd"] - (5 - r["trades"]) * 2.0
    bonus = 0.2 * abs(r["pnl"]) if r["wr"] is not None and r["wr"] > goal else 0.0
    return r["pnl"] - 0.5 * r["dd"] + bonus


class Teacher:
    def __init__(self, i, name, subject, keys):
        self.id = i
        self.name = name
        self.subject = subject
        self.keys = keys
        self.lesson = None       # สูตรที่ดีที่สุดที่ครูหาได้ (ครบทุกค่า แต่สอนเฉพาะค่าในวิชาตัวเอง)
        self.result = None       # ผลทดสอบล่าสุดของสูตรนั้น
        self.score = None
        self.studies = 0
        self.improved = 0
        self.taught = 0
        self.last_improve = None

    def to_dict(self):
        return {"id": self.id, "name": self.name, "subject": self.subject, "keys": self.keys,
                "lesson": self.lesson, "result": self.result, "score": self.score, "studies": self.studies,
                "improved": self.improved, "taught": self.taught, "last_improve": self.last_improve}

    def load_dict(self, d):
        for k in ("lesson", "result", "score", "studies", "improved", "taught", "last_improve"):
            if k in d:
                setattr(self, k, d[k])
        if self.lesson:
            self.lesson = fix_genome({k: float(self.lesson.get(k, (lo + hi) / 2)) for k, (lo, hi) in GENE.items()})


class TeacherRoom:
    def __init__(self, arena):
        self.a = arena
        cfg = arena.cfg.get("teachers", {})
        self.enabled = cfg.get("enabled", True)
        self.window = int(cfg.get("window_bars", 600))
        self.study_every = int(cfg.get("study_every", 60))
        self.class_every = int(cfg.get("class_every", 180))
        self.min_gain = float(cfg.get("min_gain", 1.0))
        self.teachers = [Teacher(i, n, s, k) for i, (n, s, k) in enumerate(TEACHERS)]
        self.lessons = []        # [ลำดับ, ครู, บอท, ผลที่ดีขึ้น] ล่าสุด สำหรับแดชบอร์ด
        self.seq = 0

    # ---------- เครื่องมือ ----------
    def _window(self):
        a = self.a
        bars = list(a.bars)[-self.window:]
        L0 = len(a.s.c) - len(bars)
        return bars, L0

    def _test(self, g, bars, L0):
        a = self.a
        return shadow_test(g, a.s, bars, L0, a.B["lot"], a.contract, a.comm, a.SV["max_hold_bars"])

    def _goal(self):
        return self.a.T["min_win_rate"] / 100

    def best(self):
        c = [t for t in self.teachers if t.lesson is not None and t.score is not None]
        return max(c, key=lambda t: t.score) if c else None

    # ---------- ครูศึกษาสูตร ----------
    def study(self):
        if not self.enabled:
            return
        bars, L0 = self._window()
        if len(bars) < self.window // 2:
            return
        a, rng, goal = self.a, self.a.rng, self._goal()
        top = sorted([b for b in a.bots if b.jailed is None], key=a.rank_score, reverse=True)[:4]
        for t in self.teachers:
            t.studies += 1
            if not top:
                continue
            # ส่วนที่ไม่ใช่วิชาของครู ใช้สูตรของบอทที่ทำผลงานดีที่สุดตอนนี้ ครูเปลี่ยนเฉพาะค่าในวิชาตัวเอง
            base = dict(top[0].g)
            mine = {k: (t.lesson or top[0].g)[k] for k in t.keys}

            def with_keys(vals):
                g = dict(base)
                g.update(vals)
                return fix_genome(g)
            cands = [("เดิม", with_keys(mine))]
            for b in top:                     # ดูว่าบอทที่ทำผลงานดีตั้งค่าในวิชานี้ไว้อย่างไร
                cands.append((b.tag, with_keys({k: b.g[k] for k in t.keys})))
            for _ in range(6):                # คิดค่าใหม่เองในวิชาของตัวเอง
                cands.append(("ทดลองเอง", with_keys({k: mine[k] + rng.gauss(0, 0.12) * (GENE[k][1] - GENE[k][0])
                                                      for k in t.keys})))
            best = None
            for src, g in cands:
                r = self._test(g, bars, L0)
                sc = grade(r, goal)
                if best is None or sc > best[0]:
                    best = (sc, src, g, r)
            sc, src, g, r = best
            changed = t.lesson is None or any(abs(g[k] - t.lesson[k]) > 1e-9 for k in t.keys)
            if changed:
                if t.lesson is not None and src != "เดิม":
                    t.improved += 1
                    t.last_improve = a.bar_i
                    a.log("study", f"{t.name} (วิชา{t.subject}) พบสูตรที่ดีขึ้นจาก{src}: ทดสอบ {len(bars)} นาทีล่าสุด "
                                   f"กำไร {fmt(r['pnl'])} ชนะ {pct(r['wr'])} ({r['trades']} ไม้)")
                t.lesson = dict(g)
            t.result = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}
            t.score = sc

    # ---------- คาบเรียน: ครูเดินไปสอนบอททุกตัวที่เทรด ----------
    def teach_class(self, why="คาบเรียนตามรอบ"):
        if not self.enabled:
            return 0
        bars, L0 = self._window()
        ready = [t for t in self.teachers if t.lesson]
        if len(bars) < self.window // 2 or not ready:
            return 0
        a, goal, n = self.a, self._goal(), 0
        for b in a.bots:
            if b.jailed is not None:
                continue
            base = grade(self._test(b.g, bars, L0), goal)
            best = None
            for t in ready:
                g = dict(b.g)
                for k in t.keys:
                    g[k] = t.lesson[k]
                gain = grade(self._test(g, bars, L0), goal) - base
                if best is None or gain > best[0]:
                    best = (gain, t)
            if best is None or best[0] < self.min_gain:
                continue
            gain, t = best
            # บอทที่เทรดจริงอยู่แล้วปรับเบาๆ ตัวที่ยังไม่ผ่านเกณฑ์ปรับมากกว่า
            rate = 0.2 if b.live else 0.35 if a.eligible(b) else 0.6
            for k in t.keys:
                b.g[k] += (t.lesson[k] - b.g[k]) * rate
            fix_genome(b.g)
            b.taught += 1
            b.last_teacher = t.id
            t.taught += 1
            n += 1
            self.seq += 1
            self.lessons.append([self.seq, t.id, b.id, round(gain, 2)])
            self.lessons = self.lessons[-60:]
            a.log("teach", f"{t.name} สอนวิชา{t.subject}ให้ {b.tag} (ทดสอบย้อนหลังแล้วดีขึ้น {fmt(gain)})")
        if n:
            a.log("teach", f"{why}: ครูสอนบอทไป {n} ตัว")
        return n

    def jail_lesson(self, b, rate=0.02):
        """บอทในเขตห้ามเทรดเรียนสูตรเต็มจากครูที่ผลงานดีที่สุด"""
        t = self.a.teachers.teachers[b.jailed["teacher"]] if b.jailed.get("teacher") is not None else None
        if t and t.lesson:
            for k in GENE:
                b.g[k] += (t.lesson[k] - b.g[k]) * rate

    def to_state(self):
        return {"teachers": [t.to_dict() for t in self.teachers], "lessons": self.lessons, "seq": self.seq}

    def load_state(self, st):
        for d in st.get("teachers", []):
            if 0 <= d.get("id", -1) < len(self.teachers):
                self.teachers[d["id"]].load_dict(d)
        self.lessons = st.get("lessons", [])
        self.seq = st.get("seq", 0)


def fmt(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def pct(v):
    return "-" if v is None else f"{v * 100:.0f}%"
