"""ครูสอนสูตร 15 คน (5 คนเป็นครูค้นสูตรจากเว็บ): ไม่ใช้เงินจริง แต่หาสูตรที่ดีที่สุดในวิชาของตัวเอง 2 ขั้น
1) ทดสอบสูตรกับราคาย้อนหลัง เพื่อคัดผู้ท้าชิง
2) ลองเทรดผู้ท้าชิงบนราคาจริงแบบไม่ใช้เงิน เทียบกับสูตรที่สอนอยู่ ตัวที่ชนะจึงได้เป็นสูตรสอน
แล้วนำไปสอนบอททุกตัวที่เทรด เฉพาะเมื่อทดสอบแล้วว่าช่วยให้บอทตัวนั้นดีขึ้นจริง
ผู้ใช้สั่งให้ครูเดินสอนทันที หรือกลับห้องครูไปคิดสูตรใหม่ได้"""
from .bots import GENE, IND, fix_genome, signal_at, stops
from .fastsig import Window, scores_and_stops

# ชื่อ วิชา ค่าที่สอน (SL / TP / ALL ถูกแปลงตาม indicator ที่เปิดใช้) และช่วงราคาที่ใช้ทดสอบ (นาที, None = ค่าใน config)
TEACHERS = [
    ("ครูวอร์เรน", "ตามเทรนด์", ["wT", "fast", "slow"], None),
    ("ครูอีลอน", "เทรดสวนกลับ (RSI)", ["wM", "rsiN", "rsiLo", "rsiHi"], None),
    ("ครูเจฟฟ์", "เบรกเอาต์", ["wB", "brkN"], None),
    ("ครูบิล", "จุดตัดขาดทุน", ["SL"], None),
    ("ครูเบอร์นาร์ด", "จังหวะเข้าเทรด", ["thr"], None),
    ("ครูมาร์ค", "เทรนด์ใหญ่", ["htfN", "htfW"], None),
    ("ครูแลร์รี่", "จุดทำกำไร", ["TP"], None),
    ("ครูเจนเซ่น", "ผสมสัญญาณ (น้ำหนัก 3 แบบ)", ["wT", "wM", "wB"], None),
    ("ครูจอร์จ", "สูตรครบชุด: ตลาดช่วงสั้น", ["ALL"], 180),
    ("ครูเรย์", "สูตรครบชุด: มองยาว 1 วัน", ["ALL"], 1440),
    # ครูนักค้นคว้า: เริ่มจากสูตรที่รวบรวมจากเว็บ (web_recipes.json) แล้วปรับเป็นสูตรของตัวเอง
    ("ครูนิว", "ค้นเว็บ: เส้นค่าเฉลี่ยตัดกัน", ["WEB:ma"], None),
    ("ครูเบลล์", "ค้นเว็บ: RSI กลับตัว", ["WEB:rsi"], None),
    ("ครูปอนด์", "ค้นเว็บ: เบรกเอาต์ Donchian/Turtle", ["WEB:breakout"], None),
    ("ครูมิ้นท์", "ค้นเว็บ: ตามเทรนด์ใหญ่ + รอย่อ", ["WEB:pullback"], None),
    ("ครูเจ", "ค้นเว็บ: บริหารความเสี่ยงด้วย ATR", ["WEB:risk"], None),
]


def load_web_recipes():
    """อ่านคลังสูตรจากเว็บ (web_recipes.json ในโฟลเดอร์โปรแกรม) คืน {กลุ่ม: {"label", "recipes"}}"""
    import json
    import os
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for p in (os.path.join(os.getcwd(), "web_recipes.json"), os.path.join(here, "web_recipes.json")):
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as f:
                    fam = json.load(f).get("families", {})
            except (OSError, ValueError):
                continue
            out = {}
            for k, v in fam.items():
                rs = []
                for r in v.get("recipes", []):
                    prm = {pk: float(pv) for pk, pv in (r.get("params") or {}).items() if pk in GENE}
                    if prm and r.get("name"):
                        rs.append(dict(r, params=prm))
                if rs:
                    out[k] = {"label": v.get("label", k), "recipes": rs}
            return out
    return {}
MIN_L = 72  # ต้องมีราคาย้อนหลังอย่างน้อยเท่านี้ถึงคำนวณสัญญาณได้


def shadow_test(g, s, bars, L0, lot, contract, comm, max_hold):
    """ทดสอบสูตร g กับแท่งราคา bars (ไม่ส่งออเดอร์จริง) แบบเดียวกับที่บอทเทรดจริง
    bars[k] คือแท่งที่มีราคาปิดสะสมถึง L0 + k + 1 แท่ง"""
    pos = None
    pnl = peak = dd = 0.0
    trades = wins = 0
    thr = g["thr"]
    for k, bar in enumerate(bars):
        if pos is not None:
            d, entry, sl, tp, k0 = pos
            ex = None
            if d > 0:
                if bar.low <= sl:
                    ex = sl
                elif bar.high >= tp:
                    ex = tp
            else:
                if bar.high + bar.spread >= sl:
                    ex = sl
                elif bar.low + bar.spread <= tp:
                    ex = tp
            if ex is None and k - k0 >= max_hold:
                ex = bar.close if d > 0 else bar.close + bar.spread
            if ex is None:
                continue
            p = (ex - entry) * d * contract * lot - comm * lot
            pnl += p
            trades += 1
            wins += p > 0
            peak = max(peak, pnl)
            dd = max(dd, peak - pnl)
            pos = None
        L = L0 + k + 1
        if L < MIN_L:
            continue
        score = signal_at(g, s, L)[3]
        if abs(score) >= thr:
            d = 1 if score > 0 else -1
            entry = bar.close + bar.spread if d > 0 else bar.close
            sl_d, tp_d = stops(g, s, L)
            pos = (d, entry, entry - d * sl_d, entry + d * tp_d, k)
    return {"pnl": pnl, "dd": dd, "trades": trades, "wins": wins,
            "wr": wins / trades if trades else None}


def shadow_test_fast(g, W, lot, contract, comm, max_hold):
    """เหมือน shadow_test ทุกประการ แต่คำนวณสัญญาณทั้งช่วงด้วย numpy ก่อน (เร็วกว่ามาก)"""
    score, sld, tpd = scores_and_stops(g, W)
    score, sld, tpd = score.tolist(), sld.tolist(), tpd.tolist()
    Ls = W.L.tolist()
    thr = g["thr"]
    pos = None
    pnl = peak = dd = 0.0
    trades = wins = 0
    for k, bar in enumerate(W.bars):
        if pos is not None:
            d, entry, sl, tp, k0 = pos
            ex = None
            if d > 0:
                if bar.low <= sl:
                    ex = sl
                elif bar.high >= tp:
                    ex = tp
            else:
                if bar.high + bar.spread >= sl:
                    ex = sl
                elif bar.low + bar.spread <= tp:
                    ex = tp
            if ex is None and k - k0 >= max_hold:
                ex = bar.close if d > 0 else bar.close + bar.spread
            if ex is None:
                continue
            p = (ex - entry) * d * contract * lot - comm * lot
            pnl += p
            trades += 1
            wins += p > 0
            peak = max(peak, pnl)
            dd = max(dd, peak - pnl)
            pos = None
        if Ls[k] < MIN_L:
            continue
        sc = score[k]
        if abs(sc) >= thr:
            d = 1 if sc > 0 else -1
            entry = bar.close + bar.spread if d > 0 else bar.close
            pos = (d, entry, entry - d * sld[k], entry + d * tpd[k], k)
    return {"pnl": pnl, "dd": dd, "trades": trades, "wins": wins,
            "wr": wins / trades if trades else None}


def grade(r, goal):
    """คะแนนของผลทดสอบ: กำไร หักความเสี่ยง (ขาดทุนสะสมจากจุดสูงสุด) และให้โบนัสเมื่ออัตราชนะถึงเกณฑ์"""
    if r["trades"] < 5:           # ไม้น้อยเกินไป เชื่อผลไม่ได้
        return r["pnl"] - 0.5 * r["dd"] - (5 - r["trades"]) * 2.0
    bonus = 0.2 * abs(r["pnl"]) if r["wr"] is not None and r["wr"] > goal else 0.0
    return r["pnl"] - 0.5 * r["dd"] + bonus


class Slot:
    """สูตรหนึ่งสูตรที่ครูกำลังลองเทรด (บนราคาจริง แต่ไม่ใช้เงินจริง)"""

    def __init__(self, g, src, bar_i):
        self.g = dict(g)
        self.src = src
        self.since = bar_i
        self.pos = None          # (dir, entry, sl, tp, bar ที่เปิด)
        self.trades = self.wins = 0
        self.pnl = self.peak = self.dd = 0.0

    def result(self):
        return {"pnl": self.pnl, "dd": self.dd, "trades": self.trades, "wins": self.wins,
                "wr": self.wins / self.trades if self.trades else None}

    def to_dict(self):
        return {"g": self.g, "src": self.src, "since": self.since, "pos": self.pos, "trades": self.trades,
                "wins": self.wins, "pnl": round(self.pnl, 2), "peak": self.peak, "dd": round(self.dd, 2)}

    @classmethod
    def from_dict(cls, d, bar_i):
        sl = cls(fix_genome({k: float(d["g"].get(k, (lo + hi) / 2)) for k, (lo, hi) in GENE.items()}),
                 d.get("src", "?"), bar_i)
        for k in ("trades", "wins", "pnl", "peak", "dd"):
            setattr(sl, k, d.get(k, 0))
        sl.pos = tuple(d["pos"][:4]) + (bar_i,) if d.get("pos") else None
        return sl


class Teacher:
    def __init__(self, i, name, subject, keys):
        self.id = i
        self.name = name
        self.subject = subject
        self.keys = keys
        self.lesson = None       # สูตรที่ครูใช้สอน (ผ่านการลองเทรดแล้ว) ครบทุกค่า แต่สอนเฉพาะค่าในวิชาตัวเอง
        self.result = None       # ผลทดสอบย้อนหลังล่าสุดของสูตรที่สอน
        self.score = None
        self.mode = "ready"      # ready = พร้อมเดินสอน, thinking = อยู่ห้องครู คิดและลองเทรดสูตรใหม่
        self.think_until = 0
        self.slots = []          # slots[0] = สูตรที่สอนอยู่, ที่เหลือ = สูตรที่กำลังลองเทรดเพื่อแข่ง
        self.studies = 0
        self.improved = 0
        self.taught = 0
        self.last_improve = None
        self.web = None          # กลุ่มสูตรจากเว็บ (เฉพาะครูนักค้นคว้า)
        self.recipes = []
        self.web_results = {}    # ผลทดสอบล่าสุดของแต่ละสูตรจากเว็บ
        self.origin = None       # สูตรจากเว็บที่เป็นต้นแบบของสูตรที่สอนอยู่
        self.version = 0         # สูตรของตัวเองเวอร์ชันที่เท่าไร
        self.lesson_name = None

    def to_dict(self):
        return {"id": self.id, "name": self.name, "subject": self.subject, "keys": self.keys,
                "web": self.web, "origin": self.origin, "version": self.version, "lesson_name": self.lesson_name,
                "web_results": self.web_results,
                "recipes": [{k: r.get(k, "") for k in ("name", "rule", "source", "url", "adapt")} for r in self.recipes],
                "lesson": self.lesson, "result": self.result, "score": self.score, "mode": self.mode,
                "think_until": self.think_until, "slots": [x.to_dict() for x in self.slots],
                "studies": self.studies, "improved": self.improved, "taught": self.taught,
                "last_improve": self.last_improve}

    def load_dict(self, d, bar_i):
        for k in ("lesson", "result", "score", "studies", "improved", "taught", "last_improve", "mode",
                  "origin", "version", "lesson_name", "web_results"):
            if k in d:
                setattr(self, k, d[k])
        if self.lesson:
            self.lesson = fix_genome({k: float(self.lesson.get(k, (lo + hi) / 2)) for k, (lo, hi) in GENE.items()})
        self.think_until = bar_i + max(0, d.get("think_until", 0) - d.get("_bar_i", bar_i)) if self.mode == "thinking" else 0
        self.slots = [Slot.from_dict(x, bar_i) for x in d.get("slots", [])]


class TeacherRoom:
    def __init__(self, arena):
        self.a = arena
        cfg = arena.cfg.get("teachers", {})
        self.enabled = cfg.get("enabled", True)
        self.window = int(cfg.get("window_bars", 600))
        self.study_every = int(cfg.get("study_every", 60))
        self.class_every = int(cfg.get("class_every", 180))
        self.min_gain = float(cfg.get("min_gain", 1.0))
        self.trial_slots = int(cfg.get("practice_slots", 2))        # สูตรที่ลองเทรดพร้อมกันต่อครู (ไม่รวมสูตรที่สอน)
        self.min_trial = int(cfg.get("min_practice_trades", 6))     # ต้องลองเทรดอย่างน้อยกี่ไม้ถึงตัดสินได้
        self.max_trial = int(cfg.get("max_practice_trades", 20))    # ลองเทรดครบกี่ไม้แล้วยังแพ้ ก็ทิ้งสูตรนั้น
        self.think_bars = int(cfg.get("think_bars", 180))           # คิดสูตรใหม่นานสุดกี่นาที แล้วกลับไปพร้อมสอนเอง
        sl_k, tp_k = ("slA", "tpA") if IND["atr_stops"] else ("sl", "tp")
        all_k = [k for k in GENE if k != "lr" and k not in (("sl", "tp") if IND["atr_stops"] else ("slA", "tpA"))
                 and (IND["htf_filter"] or k not in ("htfN", "htfW"))]
        self.web = load_web_recipes()
        self.teachers = []
        for i, (n, sj, ks, win) in enumerate(TEACHERS):
            keys = []
            fam = ks[0][4:] if ks and ks[0].startswith("WEB:") else None
            if fam:
                for r in self.web.get(fam, {}).get("recipes", []):
                    for k in r["params"]:
                        k = {"slA": sl_k, "tpA": tp_k}.get(k, k)
                        if k not in keys and k in all_k:
                            keys.append(k)
            for k in ks:
                if not k.startswith("WEB:"):
                    keys += {"SL": [sl_k], "TP": [tp_k], "ALL": all_k}.get(k, [k])
            t = Teacher(i, n, sj + (" (ATR)" if ks in (["SL"], ["TP"]) and IND["atr_stops"] else ""), keys)
            t.window = int(win or self.window)
            t.whole = ks == ["ALL"]
            if fam:
                t.web = fam
                t.recipes = self.web.get(fam, {}).get("recipes", [])
                if not t.recipes:
                    t.subject += " (ไม่พบไฟล์ web_recipes.json)"
            if ks == ["htfN", "htfW"] and not IND["htf_filter"]:
                t.subject += " (ปิดอยู่ใน config)"
            self.teachers.append(t)
        self.max_window = max(t.window for t in self.teachers)
        self.lessons = []        # [ลำดับ, ครู, บอท, ผลที่ดีขึ้น] ล่าสุด สำหรับแดชบอร์ด
        self.seq = 0

    # ---------- เครื่องมือ ----------
    def _window(self, n=None):
        a = self.a
        bars = list(a.bars)[-(n or self.window):]
        L0 = len(a.s.c) - len(bars)
        return bars, L0

    def _test(self, g, W):
        a = self.a
        return shadow_test_fast(g, W, a.B["lot"], a.contract, a.comm, a.SV["max_hold_bars"])

    def _goal(self):
        return self.a.T["min_win_rate"] / 100

    def best(self):
        c = [t for t in self.teachers if t.lesson is not None and t.score is not None]
        return max(c, key=lambda t: t.score) if c else None

    def pick(self, who):
        """who = 1-5 หรือ 0 = ครูทุกคน"""
        return self.teachers if who == 0 else [self.teachers[who - 1]]

    # ---------- ครูลองเทรด (ทุกแท่ง บนราคาจริง ไม่ใช้เงินจริง) ----------
    def on_bar(self, bar):
        if not self.enabled:
            return
        a = self.a
        L = len(a.s.c)
        lot, contract, comm, hold = a.B["lot"], a.contract, a.comm, a.SV["max_hold_bars"]
        for t in self.teachers:
            for si, sl in enumerate(t.slots):
                if sl.pos is not None:
                    d, entry, stop, tp, k0 = sl.pos
                    ex = None
                    if d > 0:
                        ex = stop if bar.low <= stop else tp if bar.high >= tp else None
                    else:
                        ex = stop if bar.high + bar.spread >= stop else tp if bar.low + bar.spread <= tp else None
                    if ex is None and a.bar_i - k0 >= hold:
                        ex = bar.close if d > 0 else bar.close + bar.spread
                    if ex is None:
                        continue
                    p = (ex - entry) * d * contract * lot - comm * lot
                    sl.pnl += p
                    if si == 0:                       # แข่งคิดสูตร: นับเฉพาะสูตรที่สอนอยู่
                        a.contest.teacher_trade(t, p)
                    sl.trades += 1
                    sl.wins += p > 0
                    sl.peak = max(sl.peak, sl.pnl)
                    sl.dd = max(sl.dd, sl.peak - sl.pnl)
                    sl.pos = None
                if L < MIN_L:
                    continue
                score = signal_at(sl.g, a.s, L)[3]
                if abs(score) >= sl.g["thr"]:
                    d = 1 if score > 0 else -1
                    entry = bar.close + bar.spread if d > 0 else bar.close
                    sl_d, tp_d = stops(sl.g, a.s, L)
                    sl.pos = (d, entry, entry - d * sl_d, entry + d * tp_d, a.bar_i)
            if t.mode == "thinking" and a.bar_i >= t.think_until:
                t.mode = "ready"
                a.log("study", f"{t.name} คิดสูตรครบเวลาแล้ว กลับมาพร้อมเดินสอน")

    # ---------- ครูศึกษาสูตร: ทดสอบย้อนหลังหาผู้ท้าชิง แล้วตัดสินจากผลลองเทรด ----------
    def study(self, only=None, explore=0.12):
        if not self.enabled:
            return
        a, rng, goal = self.a, self.a.rng, self._goal()
        top = sorted([b for b in a.bots if b.jailed is None], key=a.rank_score, reverse=True)[:4]
        if not top:
            return
        wins_ = {}
        for t in (only or self.teachers):
            bars, L0 = self._window(t.window)
            if len(bars) < min(self.window, t.window) // 2:
                continue
            if t.window not in wins_:
                wins_[t.window] = Window(a.s, bars, L0)
            W = wins_[t.window]
            t.studies += 1
            ex = explore * (0.4 if t.whole else 0.6 if t.web else 1.0)   # ครูที่ปรับหลายค่าพร้อมกัน ขยับทีละน้อยกว่า
            if t.web and not t.recipes or not t.keys:
                continue
            # ส่วนที่ไม่ใช่วิชาของครู ใช้สูตรของบอทที่ทำผลงานดีที่สุดตอนนี้ ครูเปลี่ยนเฉพาะค่าในวิชาตัวเอง
            base = dict(top[0].g)
            mine = {k: (t.lesson or top[0].g)[k] for k in t.keys}

            def with_keys(vals):
                g = dict(base)
                g.update(vals)
                return fix_genome(g)
            cands = [("สูตรเดิม", with_keys(mine))]
            if t.web:
                # ครูนักค้นคว้า: ทดสอบสูตรจากเว็บทุกสูตร แล้วคิดสูตรของตัวเองต่อยอดจากสูตรที่ดีที่สุด
                atr = a.s.atr_at(int(IND["atr_period"]), len(a.s.c)) or 1.0
                web_c = []
                for rc in t.recipes:
                    vals = {}
                    for k, v in rc["params"].items():
                        if k in ("slA", "tpA") and not IND["atr_stops"]:
                            k, v = ("sl" if k == "slA" else "tp"), v * atr     # แปลงเป็นดอลลาร์ตาม ATR ตอนนี้
                        if k in t.keys:
                            vals[k] = v
                    g = with_keys(vals)
                    r = self._test(g, W)
                    t.web_results[rc["name"]] = {"pnl": round(r["pnl"], 2), "trades": r["trades"],
                                                 "wr": round(r["wr"] * 100) if r["wr"] is not None else None}
                    web_c.append((grade(r, goal), rc["name"], g))
                    cands.append(("เว็บ: " + rc["name"], g))
                web_c.sort(key=lambda x: -x[0])
                anchor, anchor_name = (mine, t.lesson_name or "สูตรเดิม") if t.lesson else \
                    ({k: web_c[0][2][k] for k in t.keys}, web_c[0][1])
                for _ in range(6):
                    cands.append((f"คิดเอง จาก {anchor_name}",
                                  with_keys({k: anchor[k] + rng.gauss(0, ex) * (GENE[k][1] - GENE[k][0]) for k in t.keys})))
            else:
                for b in top:                     # ดูว่าบอทที่ทำผลงานดีตั้งค่าในวิชานี้ไว้อย่างไร
                    cands.append((b.tag, with_keys({k: b.g[k] for k in t.keys})))
                for _ in range(6):                # คิดค่าใหม่เองในวิชาของตัวเอง
                    cands.append(("คิดเอง", with_keys({k: mine[k] + rng.gauss(0, ex) * (GENE[k][1] - GENE[k][0])
                                                       for k in t.keys})))
            graded = []
            for src, g in cands:
                r = self._test(g, W)
                graded.append((grade(r, goal), src, g, r))
            graded.sort(key=lambda x: -x[0])
            lesson_g = cands[0][1]
            if t.lesson is None:              # ครั้งแรก: ใช้ผลทดสอบย้อนหลังไปก่อน แล้วลองเทรดพิสูจน์ต่อ
                sc, src, g, r = graded[0]
                t.lesson = dict(g)
                t.slots = [Slot(g, "สูตรที่สอน", a.bar_i)]
                if t.web:
                    self._name_lesson(t, src)
                    a.log("study", f"{t.name} ค้นสูตรจากเว็บ {len(t.recipes)} สูตร ทดสอบแล้วเริ่มจาก: {t.lesson_name}")
            else:
                t.lesson = dict(lesson_g)     # ส่วนที่ไม่ใช่วิชาครู อัปเดตตามบอทที่เก่งที่สุดตอนนี้
                if not t.slots:
                    t.slots = [Slot(t.lesson, "สูตรที่สอน", a.bar_i)]
                t.slots[0].g = dict(t.lesson)
            lr = next(x for x in graded if x[1] == "สูตรเดิม") if t.lesson is not None else graded[0]
            t.result = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in lr[3].items()}
            t.score = lr[0]
            self._judge(t)
            # เติมผู้ท้าชิงจากสูตรที่ทดสอบย้อนหลังได้ดีกว่าสูตรที่สอน
            want = self.trial_slots + (2 if t.mode == "thinking" else 0)
            for sc, src, g, r in graded:
                if len(t.slots) - 1 >= want:
                    break
                if src == "สูตรเดิม" or sc <= t.score:
                    continue
                if any(all(abs(g[k] - x.g[k]) < 1e-6 for k in t.keys) for x in t.slots):
                    continue
                t.slots.append(Slot(g, src, a.bar_i))

    def _judge(self, t):
        """เทียบผลลองเทรด: ผู้ท้าชิงที่ชนะสูตรที่สอนอยู่ จะได้เป็นสูตรที่สอนแทน"""
        if len(t.slots) < 2:
            return
        a, goal = self.a, self._goal()
        cur = t.slots[0]
        keep = [cur]
        best = None
        for sl in t.slots[1:]:
            if sl.trades >= self.min_trial:
                gain = grade(sl.result(), goal) - grade(cur.result(), goal) if cur.trades >= self.min_trial \
                    else grade(sl.result(), goal)
                if gain > self.min_gain and sl.pnl > 0 and (best is None or gain > best[0]):
                    best = (gain, sl)
            if sl.trades >= self.max_trial or a.bar_i - sl.since > 6 * self.window:
                continue                      # ลองนานพอแล้วไม่ชนะ ทิ้ง
            keep.append(sl)
        t.slots = keep
        if best:
            gain, sl = best
            r = sl.result()
            for k in t.keys:
                t.lesson[k] = sl.g[k]
            t.improved += 1
            t.last_improve = a.bar_i
            if t.web:
                self._name_lesson(t, sl.src)
            new = Slot(t.lesson, "สูตรที่สอน", a.bar_i)
            new.trades, new.wins, new.pnl, new.peak, new.dd = sl.trades, sl.wins, sl.pnl, sl.peak, sl.dd
            t.slots = [new] + [x for x in t.slots[1:] if x is not sl]
            a.log("study", f"{t.name} (วิชา{t.subject}) ลองเทรดแล้วได้สูตรที่ดีกว่า ({sl.src}): "
                           f"ลองเทรด {r['trades']} ไม้ กำไร {fmt(r['pnl'])} ชนะ {pct(r['wr'])} ใช้เป็นสูตรสอนแทน")
            if t.mode == "thinking":
                t.mode = "ready"
                a.log("study", f"{t.name} ได้สูตรใหม่แล้ว กลับมาพร้อมเดินสอน")

    @staticmethod
    def _name_lesson(t, src):
        """ตั้งชื่อสูตรที่สอนของครูนักค้นคว้า: ตามเว็บตรงๆ หรือสูตรของตัวเองที่ต่อยอดมา"""
        if src.startswith("เว็บ:"):
            t.origin = src.split(":", 1)[1].strip()
            t.lesson_name = f"ตามเว็บ: {t.origin}"
        elif src.startswith("คิดเอง"):
            if t.origin is None:
                t.origin = (src.split("จาก", 1)[1] if "จาก" in src else "?").replace("ตามเว็บ:", "").strip()
            t.version += 1
            t.lesson_name = f"สูตรของ{t.name} v{t.version} (ต่อยอดจาก {t.origin})"

    # ---------- คำสั่งจากผู้ใช้ ----------
    def order_think(self, who):
        """ให้ครูกลับห้องครู ทิ้งผู้ท้าชิงเดิม แล้วคิดสูตรใหม่แบบกว้างขึ้น (ไม่ออกสอนในคาบตามรอบ)"""
        out = []
        for t in self.pick(who):
            t.mode = "thinking"
            t.think_until = self.a.bar_i + self.think_bars
            t.slots = t.slots[:1]
            self.study(only=[t], explore=0.25)
            out.append(t.name)
            self.a.log("study", f"{t.name} กลับห้องครูไปคิดสูตรใหม่ ลองเทรด {len(t.slots) - 1} สูตร "
                                f"(นานสุด {self.think_bars} นาที หรือจนเจอสูตรที่ดีกว่า)")
        return out

    def order_teach(self, who):
        """ให้ครูเดินสอนทันที"""
        ts = self.pick(who)
        for t in ts:
            t.mode = "ready"
        return self.teach_class("สั่งให้" + ("ครูทุกคน" if who == 0 else ts[0].name) + "เดินสอน", only=ts, forced=True)

    # ---------- คาบเรียน: ครูเดินไปสอนบอททุกตัวที่เทรด ----------
    def teach_class(self, why="คาบเรียนตามรอบ", only=None, forced=False):
        if not self.enabled:
            return 0
        bars, L0 = self._window()
        ready = [t for t in (only or self.teachers) if t.lesson and (forced or t.mode == "ready")]
        if len(bars) < self.window // 2 or not ready:
            return 0
        a, goal, n = self.a, self._goal(), 0
        W = Window(a.s, bars, L0)
        for b in a.bots:
            if b.jailed is not None:
                continue
            base = grade(self._test(b.g, W), goal)
            best = None
            for t in ready:
                g = dict(b.g)
                for k in t.keys:
                    g[k] = t.lesson[k]
                gain = grade(self._test(g, W), goal) - base
                if best is None or gain > best[0]:
                    best = (gain, t)
            if best is None or best[0] < self.min_gain:
                continue
            gain, t = best
            # บอทที่เทรดจริงอยู่แล้วปรับเบาๆ ตัวที่ยังไม่ผ่านเกณฑ์ปรับมากกว่า
            rate = 0.2 if b.live else 0.35 if a.eligible(b) else 0.6
            for k in t.keys:
                b.g[k] += (t.lesson[k] - b.g[k]) * rate
            fix_genome(b.g)
            b.taught += 1
            b.last_teacher = t.id
            t.taught += 1
            n += 1
            self.seq += 1
            self.lessons.append([self.seq, t.id, b.id, round(gain, 2)])
            self.lessons = self.lessons[-60:]
            a.log("teach", f"{t.name} สอน{t.lesson_name or 'วิชา' + t.subject} ให้ {b.tag} (ทดสอบแล้วดีขึ้น {fmt(gain)})")
        if n or forced:
            a.log("teach", f"{why}: ครูสอนบอทไป {n} ตัว")
        return n

    def jail_lesson(self, b, rate=0.02):
        """บอทในเขตห้ามเทรดเรียนสูตรเต็มจากครูที่ผลงานดีที่สุด"""
        t = self.teachers[b.jailed["teacher"]] if b.jailed.get("teacher") is not None else None
        if t and t.lesson:
            for k in GENE:
                b.g[k] += (t.lesson[k] - b.g[k]) * rate

    def to_state(self):
        return {"teachers": [dict(t.to_dict(), _bar_i=self.a.bar_i) for t in self.teachers],
                "lessons": self.lessons, "seq": self.seq}

    def load_state(self, st):
        for d in st.get("teachers", []):
            if 0 <= d.get("id", -1) < len(self.teachers):
                self.teachers[d["id"]].load_dict(d, self.a.bar_i)
        self.lessons = st.get("lessons", [])
        self.seq = st.get("seq", 0)


def fmt(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def pct(v):
    return "-" if v is None else f"{v * 100:.0f}%"
