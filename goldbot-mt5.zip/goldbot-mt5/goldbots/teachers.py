"""อาจารย์สอนสูตร 20 คน (5 คนเป็นอาจารย์ค้นสูตรจากเว็บ): ไม่ใช้เงินจริง แต่หาสูตรที่ดีที่สุดในวิชาของตัวเอง 2 ขั้น
1) ทดสอบสูตรกับราคาย้อนหลัง เพื่อคัดผู้ท้าชิง
2) ลองเทรดผู้ท้าชิงบนราคาจริงแบบไม่ใช้เงิน เทียบกับสูตรที่สอนอยู่ ตัวที่ชนะจึงได้เป็นสูตรสอน
แล้วนำไปสอนบอททุกตัวที่เทรด เฉพาะเมื่อทดสอบแล้วว่าช่วยให้บอทตัวนั้นดีขึ้นจริง
ผู้ใช้สั่งให้อาจารย์เดินสอนทันที หรือกลับห้องอาจารย์ไปคิดสูตรใหม่ได้"""
from .bots import GENE, IND, TF, fix_genome, genome_from, hold_bars, min_bars, signal_at, stops, tf_close, trail
from .fastsig import Window, scores_and_stops

# ชื่อ วิชา ค่าที่สอน (SL / TP / ALL ถูกแปลงตาม indicator ที่เปิดใช้) และช่วงราคาที่ใช้ทดสอบ (นาที, None = ค่าใน config)
TEACHERS = [
    ("อาจารย์วอร์เรน", "ตามเทรนด์", ["wT", "fast", "slow"], None),
    ("อาจารย์อีลอน", "เทรดสวนกลับ (RSI)", ["wM", "rsiN", "rsiLo", "rsiHi"], None),
    ("อาจารย์เจฟฟ์", "เบรกเอาต์", ["wB", "brkN"], None),
    ("อาจารย์บิล", "จุดตัดขาดทุน", ["SL"], None),
    ("อาจารย์เบอร์นาร์ด", "จังหวะเข้าเทรด", ["thr"], None),
    ("อาจารย์มาร์ค", "เทรนด์ใหญ่", ["htfN", "htfW"], None),
    ("อาจารย์แลร์รี่", "จุดทำกำไร", ["TP"], None),
    ("อาจารย์เจนเซ่น", "ผสมสัญญาณ (น้ำหนัก 3 แบบ)", ["wT", "wM", "wB"], None),
    ("อาจารย์จอร์จ", "สูตรครบชุด: ตลาดช่วงสั้น", ["ALL"], 180),
    ("อาจารย์เรย์", "สูตรครบชุด: มองยาว 1 วัน", ["ALL"], 1440),
    # อาจารย์นักค้นคว้า: เริ่มจากสูตรที่รวบรวมจากเว็บ (web_recipes.json) แล้วปรับเป็นสูตรของตัวเอง
    ("อาจารย์นิว", "ค้นเว็บ: เส้นค่าเฉลี่ยตัดกัน", ["WEB:ma"], None),
    ("อาจารย์เบลล์", "ค้นเว็บ: RSI กลับตัว", ["WEB:rsi"], None),
    ("อาจารย์ปอนด์", "ค้นเว็บ: เบรกเอาต์ Donchian/Turtle", ["WEB:breakout"], None),
    ("อาจารย์มิ้นท์", "ค้นเว็บ: ตามเทรนด์ใหญ่ + รอย่อ", ["WEB:pullback"], None),
    ("อาจารย์เจ", "ค้นเว็บ: บริหารความเสี่ยงด้วย ATR", ["WEB:risk"], None),
    # อาจารย์ชุดใหม่ 5 คน
    ("อาจารย์ชาร์ลี", "คลังสูตรชนะ 75% + สูตรที่เรียนจาก EA ตัวอื่น", ["ALL", "LIB"], None),
    ("อาจารย์ปีเตอร์", "จุดตัดขาดทุน ทำกำไร และวิธีออก (คุ้มทุน/เลื่อนตาม)", ["SL", "TP", "be", "trl"], None),
    ("อาจารย์จิม", "ตลาดผันผวน (ทดสอบกับช่วงราคาที่วิ่งแรงที่สุด)", ["ALL", "VOL"], None),
    ("อาจารย์พอล", "จังหวะเข้า + เทรนด์ใหญ่", ["thr", "htfN", "htfW"], None),
    ("อาจารย์สแตน", "สูตรครบชุด: มองกลาง 6 ชั่วโมง", ["ALL"], 360),
]


def load_ea_recipes():
    """สูตรที่เรียนจาก EA ตัวอื่น (สร้างด้วย analyze_ea.py) คืน (รายการสูตร, เวลาแก้ไขไฟล์)"""
    import json
    import os
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for p in (os.path.join(os.getcwd(), "ea_recipes.json"), os.path.join(here, "ea_recipes.json")):
        if os.path.exists(p):
            try:
                mt = os.path.getmtime(p)
                with open(p, encoding="utf-8") as f:
                    docs = json.load(f).get("recipes", [])
                return [d for d in docs if isinstance(d.get("params"), dict) and d.get("name")], mt
            except (OSError, ValueError):
                return [], None
    return [], None


def load_web_recipes():
    """อ่านคลังสูตรจากเว็บ (web_recipes.json ในโฟลเดอร์โปรแกรม) คืน {กลุ่ม: {"label", "recipes"}}"""
    import json
    import os
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for p in (os.path.join(os.getcwd(), "web_recipes.json"), os.path.join(here, "web_recipes.json")):
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as f:
                    fam = json.load(f).get("families", {})
            except (OSError, ValueError):
                continue
            out = {}
            for k, v in fam.items():
                rs = []
                for r in v.get("recipes", []):
                    prm = {pk: float(pv) for pk, pv in (r.get("params") or {}).items() if pk in GENE}
                    if prm and r.get("name"):
                        rs.append(dict(r, params=prm))
                if rs:
                    out[k] = {"label": v.get("label", k), "recipes": rs}
            return out
    return {}


def _manage(pos, bar, g, slip, max_hold, k):
    """ดูแลออเดอร์จำลอง 1 แท่ง: เช็ก SL/TP/ครบเวลา ก่อน (ใช้ SL ที่ตั้งไว้ก่อนแท่งนี้) ถ้ายังไม่ปิด
    ค่อยเลื่อน SL ตามวิธีออกของสูตร (คุ้มทุน / เลื่อนตามราคา) ไว้ใช้แท่งถัดไป คืนราคาที่ปิด หรือ None"""
    d, entry, sl, tp, k0, risk, best = pos
    ex = None
    if d > 0:
        if bar.low <= sl:
            ex = sl - slip                 # SL เป็นคำสั่งตลาด มักได้ราคาแย่กว่าที่ตั้ง (slippage)
        elif bar.high >= tp:
            ex = tp
    else:
        if bar.high + bar.spread >= sl:
            ex = sl + slip
        elif bar.low + bar.spread <= tp:
            ex = tp
    if ex is None and k - k0 >= max_hold:
        ex = (bar.close if d > 0 else bar.close + bar.spread) - d * slip
    if ex is None:
        best = max(best, bar.high) if d > 0 else min(best, bar.low + bar.spread)
        pos[6] = best
        pos[2] = trail(g, d, entry, sl, risk, best)
    return ex


def shadow_test(g, s, bars, L0, lot, contract, comm, max_hold, slip=0.0):
    """ทดสอบสูตร g กับแท่งราคา bars (ไม่ส่งออเดอร์จริง) แบบเดียวกับที่บอทเทรดจริง
    bars[k] คือแท่งที่มีราคาปิดสะสมถึง L0 + k + 1 แท่ง"""
    pos = None
    pnl = peak = dd = 0.0
    trades = wins = 0
    thr = g["thr"]
    mb = min_bars()
    max_hold = hold_bars(g, max_hold)
    for k, bar in enumerate(bars):
        if pos is not None:
            ex = _manage(pos, bar, g, slip, max_hold, k)
            if ex is None:
                continue
            d, entry = pos[0], pos[1]
            p = (ex - entry) * d * contract * lot - comm * lot
            pnl += p
            trades += 1
            wins += p > 0
            peak = max(peak, pnl)
            dd = max(dd, peak - pnl)
            pos = None
        L = L0 + k + 1
        if L < mb or not tf_close(getattr(bar, "time", 0), L):
            continue
        score = signal_at(g, s, L)[3]
        if abs(score) >= thr:
            d = 1 if score > 0 else -1
            entry = (bar.close + bar.spread if d > 0 else bar.close) + d * slip
            sl_d, tp_d = stops(g, s, L)
            pos = [d, entry, entry - d * sl_d, entry + d * tp_d, k, sl_d, entry]
    return {"pnl": pnl, "dd": dd, "trades": trades, "wins": wins,
            "wr": wins / trades if trades else None}


def shadow_test_fast(g, W, lot, contract, comm, max_hold, slip=0.0, segs=0):
    """เหมือน shadow_test ทุกประการ แต่คำนวณสัญญาณทั้งช่วงด้วย numpy ก่อน (เร็วกว่ามาก)
    segs > 0: แบ่งช่วงราคาเป็น segs ช่วงเท่าๆ กัน แล้วคืนกำไรของแต่ละช่วงใน r["seg"] (ใช้สอบหลายช่วง)"""
    seg = [0.0] * segs if segs else None
    nb = max(1, len(W.bars))
    score, sld, tpd = scores_and_stops(g, W)
    score, sld, tpd = score.tolist(), sld.tolist(), tpd.tolist()
    ok = ((W.L >= min_bars()) & W.gate).tolist()
    thr = g["thr"]
    max_hold = hold_bars(g, max_hold)
    pos = None
    pnl = peak = dd = 0.0
    trades = wins = 0
    for k, bar in enumerate(W.bars):
        if pos is not None:
            ex = _manage(pos, bar, g, slip, max_hold, k)
            if ex is None:
                continue
            d, entry = pos[0], pos[1]
            p = (ex - entry) * d * contract * lot - comm * lot
            pnl += p
            trades += 1
            wins += p > 0
            peak = max(peak, pnl)
            dd = max(dd, peak - pnl)
            pos = None
            if seg is not None:
                seg[min(segs - 1, k * segs // nb)] += p
        if not ok[k]:
            continue
        sc = score[k]
        if abs(sc) >= thr:
            d = 1 if sc > 0 else -1
            entry = (bar.close + bar.spread if d > 0 else bar.close) + d * slip
            pos = [d, entry, entry - d * sld[k], entry + d * tpd[k], k, sld[k], entry]
    r = {"pnl": pnl, "dd": dd, "trades": trades, "wins": wins, "wr": wins / trades if trades else None}
    if seg is not None:
        r["seg"] = seg
    return r


def perturb(g, rng, pct):
    """สูตรเดิมที่ขยับทุกค่าแบบสุ่ม ±pct% (ใช้ทดสอบความทนทาน)"""
    out = dict(g)
    for k, (lo, hi) in GENE.items():
        if k == "lr" or k not in out:
            continue
        v = out[k] * (1 + rng.uniform(-pct, pct) / 100.0)
        out[k] = min(hi, max(lo, v))
    return fix_genome(out)


def robustness(g, W, rng, test, n=6, pct=10.0):
    """ขยับสูตร ±pct% n แบบ แล้วดูว่ายังได้กำไรกี่แบบ คืน (สัดส่วนที่ได้กำไร, กำไรของแต่ละแบบ)
    สูตรที่ดีจริงได้กำไรทั้งช่วงกว้างๆ สูตรที่บังเอิญดีจะพังเมื่อขยับนิดเดียว"""
    res = [test(perturb(g, rng, pct), W)["pnl"] for _ in range(n)]
    return (sum(1 for x in res if x > 0) / n if n else 1.0), res


def grade(r, goal):
    """คะแนนของผลทดสอบ: กำไร หักความเสี่ยง (ขาดทุนสะสมจากจุดสูงสุด) และให้โบนัสเมื่ออัตราชนะถึงเกณฑ์"""
    if r["trades"] < 5:           # ไม้น้อยเกินไป เชื่อผลไม่ได้
        return r["pnl"] - 0.5 * r["dd"] - (5 - r["trades"]) * 2.0
    bonus = 0.2 * abs(r["pnl"]) if r["wr"] is not None and r["wr"] > goal else 0.0
    return r["pnl"] - 0.5 * r["dd"] + bonus


class Slot:
    """สูตรหนึ่งสูตรที่อาจารย์กำลังลองเทรด (บนราคาจริง แต่ไม่ใช้เงินจริง)"""

    def __init__(self, g, src, bar_i):
        self.g = dict(g)
        self.src = src
        self.since = bar_i
        self.pos = None          # (dir, entry, sl, tp, bar ที่เปิด)
        self.trades = self.wins = 0
        self.pnl = self.peak = self.dd = 0.0

    def result(self):
        return {"pnl": self.pnl, "dd": self.dd, "trades": self.trades, "wins": self.wins,
                "wr": self.wins / self.trades if self.trades else None}

    def to_dict(self):
        return {"g": self.g, "src": self.src, "since": self.since, "pos": self.pos, "trades": self.trades,
                "wins": self.wins, "pnl": round(self.pnl, 2), "peak": self.peak, "dd": round(self.dd, 2)}

    @classmethod
    def from_dict(cls, d, bar_i):
        sl = cls(genome_from(d["g"]),
                 d.get("src", "?"), bar_i)
        for k in ("trades", "wins", "pnl", "peak", "dd"):
            setattr(sl, k, d.get(k, 0))
        p = d.get("pos")
        sl.pos = None
        if p:
            risk = p[5] if len(p) > 5 else abs(p[1] - p[2])
            sl.pos = list(p[:4]) + [bar_i, risk, p[6] if len(p) > 6 else p[1]]
        return sl


class Teacher:
    def __init__(self, i, name, subject, keys):
        self.id = i
        self.name = name
        self.subject = subject
        self.keys = keys
        self.lesson = None       # สูตรที่อาจารย์ใช้สอน (ผ่านการลองเทรดแล้ว) ครบทุกค่า แต่สอนเฉพาะค่าในวิชาตัวเอง
        self.result = None       # ผลทดสอบย้อนหลังล่าสุดของสูตรที่สอน
        self.score = None
        self.mode = "ready"      # ready = พร้อมเดินสอน, thinking = อยู่ห้องอาจารย์ คิดและลองเทรดสูตรใหม่
        self.think_until = 0
        self.slots = []          # slots[0] = สูตรที่สอนอยู่, ที่เหลือ = สูตรที่กำลังลองเทรดเพื่อแข่ง
        self.studies = 0
        self.improved = 0
        self.taught = 0
        self.last_improve = None
        self.rush = None         # โหมดเร่งด่วนรับข่าว: สูตรรับข่าวที่ใช้อยู่ + สูตรเดิมสำรอง
        self.web = None          # กลุ่มสูตรจากเว็บ (เฉพาะอาจารย์นักค้นคว้า)
        self.recipes = []
        self.web_results = {}    # ผลทดสอบล่าสุดของแต่ละสูตรจากเว็บ
        self.origin = None       # สูตรจากเว็บที่เป็นต้นแบบของสูตรที่สอนอยู่
        self.version = 0         # สูตรของตัวเองเวอร์ชันที่เท่าไร
        self.lesson_name = None

    def to_dict(self):
        return {"id": self.id, "name": self.name, "subject": self.subject, "keys": self.keys,
                "web": self.web, "origin": self.origin, "version": self.version, "lesson_name": self.lesson_name,
                "web_results": self.web_results,
                "recipes": [{k: r.get(k, "") for k in ("name", "rule", "source", "url", "adapt")} for r in self.recipes],
                "lesson": self.lesson, "result": self.result, "score": self.score, "mode": self.mode,
                "think_until": self.think_until, "slots": [x.to_dict() for x in self.slots],
                "studies": self.studies, "improved": self.improved, "taught": self.taught,
                "rejected": getattr(self, "rejected", 0),
                "last_improve": self.last_improve,
                "rush": {k: v for k, v in self.rush.items() if k != "backup"} if self.rush else None,
                "_rush": self.rush}

    def load_dict(self, d, bar_i):
        for k in ("lesson", "result", "score", "studies", "improved", "taught", "last_improve", "mode",
                  "origin", "version", "lesson_name", "web_results"):
            if k in d:
                setattr(self, k, d[k])
        if self.lesson:
            self.lesson = genome_from(self.lesson)
        self.think_until = bar_i + max(0, d.get("think_until", 0) - d.get("_bar_i", bar_i)) if self.mode == "thinking" else 0
        self.slots = [Slot.from_dict(x, bar_i) for x in d.get("slots", [])]
        self.rush = d.get("_rush")


class TeacherRoom:
    def __init__(self, arena):
        self.a = arena
        cfg = arena.cfg.get("teachers", {})
        self.enabled = cfg.get("enabled", True)
        self.window = int(cfg.get("window_bars", 600))
        self.study_every = int(cfg.get("study_every", 60))
        self.class_every = int(cfg.get("class_every", 180))
        self.min_gain = float(cfg.get("min_gain", 1.0))
        self.trial_slots = int(cfg.get("practice_slots", 2))        # สูตรที่ลองเทรดพร้อมกันต่ออาจารย์ (ไม่รวมสูตรที่สอน)
        self.min_trial = int(cfg.get("min_practice_trades", 6))     # ต้องลองเทรดอย่างน้อยกี่ไม้ถึงตัดสินได้
        self.max_trial = int(cfg.get("max_practice_trades", 20))    # ลองเทรดครบกี่ไม้แล้วยังแพ้ ก็ทิ้งสูตรนั้น
        self.think_bars = int(cfg.get("think_bars", 180))
        # ทดสอบหลายช่วง: ผู้ท้าชิงต้องไม่แย่ลงเมื่อทดสอบกับ 7 วันล่าสุด และช่วงตลาดผันผวน (กันสูตรที่ดีแค่ช่วงเดียว)
        self.multi_check = bool(cfg.get("multi_window_check", True))
        self.long_window = int(cfg.get("long_window_bars", 7 * 1440))
        self.multi_rejected = 0
        self.wf_rejected = 0              # ผู้ท้าชิงที่สอบตกกับราคาที่ไม่เคยเห็น (ข้อ 1)
        self.robust_rejected = 0          # ผู้ท้าชิงที่ขยับค่าแล้วพัง (ข้อ 3)           # คิดสูตรใหม่นานสุดกี่นาที แล้วกลับไปพร้อมสอนเอง
        sl_k, tp_k = ("slA", "tpA") if IND["atr_stops"] else ("sl", "tp")
        all_k = [k for k in GENE if k != "lr" and k not in (("sl", "tp") if IND["atr_stops"] else ("slA", "tpA"))
                 and (IND["htf_filter"] or k not in ("htfN", "htfW"))]
        self.web = load_web_recipes()
        self.teachers = []
        for i, (n, sj, ks, win) in enumerate(TEACHERS):
            keys = []
            fam = ks[0][4:] if ks and ks[0].startswith("WEB:") else None
            if fam:
                for r in self.web.get(fam, {}).get("recipes", []):
                    for k in r["params"]:
                        k = {"slA": sl_k, "tpA": tp_k}.get(k, k)
                        if k not in keys and k in all_k:
                            keys.append(k)
            for k in ks:
                if k in ("VOL", "LIB"):
                    continue
                if not k.startswith("WEB:"):
                    keys += {"SL": [sl_k], "TP": [tp_k], "ALL": all_k}.get(k, [k])
            t = Teacher(i, n, sj + (" (ATR)" if ks in (["SL"], ["TP"]) and IND["atr_stops"] else ""), keys)
            t.window = int(win or self.window)
            if TF() > 1 and win:   # กรอบเวลาใหญ่: ช่วงทดสอบเฉพาะของอาจารย์ต้องยาวขึ้นให้มีไม้พอตัดสิน
                t.window = min(self.long_window, max(self.window, win * TF() // 3))
            t.whole = "ALL" in ks
            t.vol = "VOL" in ks        # ทดสอบกับช่วงราคาที่ผันผวนที่สุด แทนราคาล่าสุด
            t.lib = "LIB" in ks        # ใช้สูตรในคลังที่ชนะ 75% ขึ้นไปเป็นตัวตั้งต้น
            if fam:
                t.web = fam
                t.recipes = self.web.get(fam, {}).get("recipes", [])
                if not t.recipes:
                    t.subject += " (ไม่พบไฟล์ web_recipes.json)"
            if ks == ["htfN", "htfW"] and not IND["htf_filter"]:
                t.subject += " (ปิดอยู่ใน config)"
            self.teachers.append(t)
        self.max_window = max(t.window for t in self.teachers)
        self.lessons = []        # [ลำดับ, อาจารย์, บอท, ผลที่ดีขึ้น] ล่าสุด สำหรับแดชบอร์ด
        self.seq = 0

    # ---------- เครื่องมือ ----------
    def _window(self, n=None):
        a = self.a
        bars = list(a.bars)[-(n or self.window):]
        L0 = len(a.s.c) - len(bars)
        return bars, L0

    def _test(self, g, W):
        a = self.a
        return shadow_test_fast(g, W, a.B["lot"], a.contract, a.comm, a.SV["max_hold_bars"], a.slip)

    def _goal(self):
        return self.a.T["min_win_rate"] / 100

    def _ea_recipes(self):
        """อ่าน ea_recipes.json ใหม่เมื่อไฟล์เปลี่ยน และแจ้งเมื่อมีสูตรใหม่จาก EA"""
        docs, mt = load_ea_recipes()
        if mt != getattr(self, "_ea_mt", None):
            old = {d["name"] for d in getattr(self, "_ea_docs", [])}
            self._ea_mt = mt
            self._ea_docs = docs
            for d in docs:
                if d["name"] not in old:
                    self.a.log("study", f"อาจารย์ชาร์ลีได้สูตรที่เรียนจาก {d['name']} (เข้าไม้ตรงจังหวะ EA "
                                        f"{d.get('match', {}).get('recall', 0) * 100:.0f}%) นำไปทดสอบและลองเทรดก่อนสอนบอท")
        return getattr(self, "_ea_docs", [])

    def _split(self, W):
        """แบ่งช่วงทดสอบเป็น ส่วนที่ใช้คัดสูตร + ส่วนท้ายที่เก็บไว้สอบ (walk-forward) คืน (ส่วนคัด, ส่วนสอบ หรือ None)"""
        a = self.a
        if not a.X["on"] or a.X["holdout"] <= 0:
            return W, None
        h = int(W.n * a.X["holdout"])
        if h < 30 or W.n - h < 60:
            return W, None
        L0 = int(W.L[0]) - 1
        return Window(a.s, W.bars[:-h], L0), Window(a.s, W.bars[-h:], L0 + W.n - h)

    def best(self):
        c = [t for t in self.teachers if t.lesson is not None and t.score is not None]
        return max(c, key=lambda t: t.score) if c else None

    def pick(self, who):
        """who = 1-5 หรือ 0 = อาจารย์ทุกคน"""
        return self.teachers if who == 0 else [self.teachers[who - 1]]

    # ---------- อาจารย์ลองเทรด (ทุกแท่ง บนราคาจริง ไม่ใช้เงินจริง) ----------
    def on_bar(self, bar):
        if not self.enabled:
            return
        a = self.a
        L = len(a.s.c)
        lot, contract, comm, hold, slip = a.B["lot"], a.contract, a.comm, a.SV["max_hold_bars"], a.slip
        gate = L >= min_bars() and tf_close(bar.time, L)
        for t in self.teachers:
            for si, sl in enumerate(t.slots):
                if sl.pos is not None:
                    ex = _manage(sl.pos, bar, sl.g, slip, hold_bars(sl.g, hold), a.bar_i)
                    if ex is None:
                        continue
                    d, entry = sl.pos[0], sl.pos[1]
                    p = (ex - entry) * d * contract * lot - comm * lot
                    sl.pnl += p
                    if si == 0:                       # แข่งคิดสูตร: นับเฉพาะสูตรที่สอนอยู่
                        a.contest.teacher_trade(t, p)
                    sl.trades += 1
                    sl.wins += p > 0
                    sl.peak = max(sl.peak, sl.pnl)
                    sl.dd = max(sl.dd, sl.peak - sl.pnl)
                    sl.pos = None
                if not gate:
                    continue
                score = signal_at(sl.g, a.s, L)[3]
                if abs(score) >= sl.g["thr"]:
                    d = 1 if score > 0 else -1
                    entry = (bar.close + bar.spread if d > 0 else bar.close) + d * slip
                    sl_d, tp_d = stops(sl.g, a.s, L)
                    sl.pos = [d, entry, entry - d * sl_d, entry + d * tp_d, a.bar_i, sl_d, entry]
            if t.mode == "thinking" and a.bar_i >= t.think_until:
                t.mode = "ready"
                a.log("study", f"{t.name} คิดสูตรครบเวลาแล้ว กลับมาพร้อมเดินสอน")

    # ---------- อาจารย์ศึกษาสูตร: ทดสอบย้อนหลังหาผู้ท้าชิง แล้วตัดสินจากผลลองเทรด ----------
    def study(self, only=None, explore=0.12):
        if not self.enabled:
            return
        a, rng, goal = self.a, self.a.rng, self._goal()
        top = sorted([b for b in a.bots if b.jailed is None], key=a.rank_score, reverse=True)[:4]
        if not top:
            return
        wins_ = {}
        extra = None                  # หน้าต่างทดสอบเพิ่ม (7 วัน, ช่วงผันผวน) เตรียมเมื่อจำเป็นเท่านั้น

        def extras():
            nonlocal extra
            if extra is None:
                extra = []
                lb, lL0 = self._window(self.long_window)
                if len(lb) >= 2 * 1440:
                    extra.append(("7 วัน", Window(a.s, lb, lL0)))
                vw = self._volatile_window()
                if vw:
                    extra.append(("ช่วงผันผวน", vw[0]))
            return extra
        for t in (only or self.teachers):
            bars, L0 = self._window(t.window)
            if len(bars) < min(self.window, t.window) // 2:
                continue
            if getattr(t, "vol", False):
                if "vol" not in wins_:
                    vw = self._volatile_window()
                    wins_["vol"] = vw[0] if vw else None
                W = wins_["vol"]
                if W is None:
                    continue
            else:
                if t.window not in wins_:
                    wins_[t.window] = Window(a.s, bars, L0)
                W = wins_[t.window]
            # ข้อ 1: แบ่งราคาส่วนท้ายเก็บไว้เป็น "ข้อสอบ" ที่อาจารย์ไม่ได้ใช้คัดสูตร ผู้ท้าชิงต้องทำได้ไม่แย่กว่าสูตรเดิมกับข้อสอบนี้
            key = ("split", id(W))
            if key not in wins_:
                wins_[key] = self._split(W)
            W, W_hold = wins_[key]
            t.studies += 1
            ex = explore * (0.4 if t.whole else 0.6 if t.web else 1.0)   # อาจารย์ที่ปรับหลายค่าพร้อมกัน ขยับทีละน้อยกว่า
            if t.web and not t.recipes or not t.keys:
                continue
            # ส่วนที่ไม่ใช่วิชาของอาจารย์ ใช้สูตรของบอทที่ทำผลงานดีที่สุดตอนนี้ อาจารย์เปลี่ยนเฉพาะค่าในวิชาตัวเอง
            base = dict(top[0].g)
            mine = {k: (t.lesson or top[0].g)[k] for k in t.keys}

            def with_keys(vals):
                g = dict(base)
                g.update(vals)
                return fix_genome(g)
            cands = [("สูตรเดิม", with_keys(mine))]
            if t.web:
                # อาจารย์นักค้นคว้า: ทดสอบสูตรจากเว็บทุกสูตร แล้วคิดสูตรของตัวเองต่อยอดจากสูตรที่ดีที่สุด
                atr = a.s.atr_at(int(IND["atr_period"]), len(a.s.c)) or 1.0
                web_c = []
                for rc in t.recipes:
                    vals = {}
                    for k, v in rc["params"].items():
                        if k in ("slA", "tpA") and not IND["atr_stops"]:
                            k, v = ("sl" if k == "slA" else "tp"), v * atr     # แปลงเป็นดอลลาร์ตาม ATR ตอนนี้
                        if k in t.keys:
                            vals[k] = v
                    g = with_keys(vals)
                    r = self._test(g, W)
                    t.web_results[rc["name"]] = {"pnl": round(r["pnl"], 2), "trades": r["trades"],
                                                 "wr": round(r["wr"] * 100) if r["wr"] is not None else None}
                    web_c.append((grade(r, goal), rc["name"], g))
                    cands.append(("เว็บ: " + rc["name"], g))
                web_c.sort(key=lambda x: -x[0])
                anchor, anchor_name = (mine, t.lesson_name or "สูตรเดิม") if t.lesson else \
                    ({k: web_c[0][2][k] for k in t.keys}, web_c[0][1])
                for _ in range(6):
                    cands.append((f"คิดเอง จาก {anchor_name}",
                                  with_keys({k: anchor[k] + rng.gauss(0, ex) * (GENE[k][1] - GENE[k][0]) for k in t.keys})))
            else:
                for b in top:                     # ดูว่าบอทที่ทำผลงานดีตั้งค่าในวิชานี้ไว้อย่างไร
                    cands.append((b.tag, with_keys({k: b.g[k] for k in t.keys})))
                if getattr(t, "lib", False):      # สูตรที่เซฟไว้ซึ่งชนะ 75% ขึ้นไป (คลังเดียวกับที่หัวแถวใช้)
                    for doc in a.rows.library[-12:]:
                        cands.append(("คลังสูตร: " + str(doc["name"]), with_keys({k: doc["genome"][k] for k in t.keys})))
                    # สูตรที่เรียนจาก EA ตัวอื่น (analyze_ea.py) ต้องผ่านการทดสอบและลองเทรดเหมือนสูตรอื่น
                    for doc in self._ea_recipes():
                        prm = genome_from(doc["params"])
                        cands.append(("สูตรจาก " + str(doc["name"]), with_keys({k: prm[k] for k in t.keys})))
                for _ in range(6):                # คิดค่าใหม่เองในวิชาของตัวเอง
                    cands.append(("คิดเอง", with_keys({k: mine[k] + rng.gauss(0, ex) * (GENE[k][1] - GENE[k][0])
                                                       for k in t.keys})))
            graded = []
            for src, g in cands:
                r = self._test(g, W)
                graded.append((grade(r, goal), src, g, r))
            graded.sort(key=lambda x: -x[0])
            lesson_g = cands[0][1]
            if t.lesson is None:              # ครั้งแรก: ใช้ผลทดสอบย้อนหลังไปก่อน แล้วลองเทรดพิสูจน์ต่อ
                sc, src, g, r = graded[0]
                t.lesson = dict(g)
                t.slots = [Slot(g, "สูตรที่สอน", a.bar_i)]
                if t.web:
                    self._name_lesson(t, src)
                    a.log("study", f"{t.name} ค้นสูตรจากเว็บ {len(t.recipes)} สูตร ทดสอบแล้วเริ่มจาก: {t.lesson_name}")
            else:
                t.lesson = dict(lesson_g)     # ส่วนที่ไม่ใช่วิชาอาจารย์ อัปเดตตามบอทที่เก่งที่สุดตอนนี้
                if not t.slots:
                    t.slots = [Slot(t.lesson, "สูตรที่สอน", a.bar_i)]
                t.slots[0].g = dict(t.lesson)
            lr = next(x for x in graded if x[1] == "สูตรเดิม") if t.lesson is not None else graded[0]
            t.result = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in lr[3].items()}
            t.score = lr[0]
            self._judge(t)
            # เติมผู้ท้าชิงจากสูตรที่ทดสอบย้อนหลังได้ดีกว่าสูตรที่สอน
            want = self.trial_slots + (2 if t.mode == "thinking" else 0)
            base_x = None
            for sc, src, g, r in graded:
                if len(t.slots) - 1 >= want:
                    break
                if src == "สูตรเดิม" or sc <= t.score:
                    continue
                if any(all(abs(g[k] - x.g[k]) < 1e-6 for k in t.keys) for x in t.slots):
                    continue
                if W_hold is not None:
                    hb = grade(self._test(lesson_g, W_hold), goal)
                    hc = grade(self._test(g, W_hold), goal)
                    if hc < hb:
                        self.wf_rejected += 1
                        t.rejected = getattr(t, "rejected", 0) + 1
                        continue          # ดีกับราคาที่ใช้คัด แต่สอบกับราคาที่ไม่เคยเห็นแล้วแย่กว่าสูตรเดิม: ไม่เอา
                if a.X["on"] and a.X["robust_tests"] > 0:
                    share, _ = robustness(g, W, a.xrng, self._test, a.X["robust_tests"], a.X["robust_pct"])
                    if share < a.X["robust_share"]:
                        self.robust_rejected += 1
                        t.rejected = getattr(t, "rejected", 0) + 1
                        continue          # ขยับค่าในสูตรนิดเดียวแล้วขาดทุน แปลว่าดีเพราะบังเอิญ: ไม่เอา
                if self.multi_check and extras():
                    if base_x is None:
                        base_x = [grade(self._test(lesson_g, X), goal) for _, X in extras()]
                    cand_x = [grade(self._test(g, X), goal) for _, X in extras()]
                    if any(c < b - max(1.0, 0.1 * abs(b)) for c, b in zip(cand_x, base_x)):
                        self.multi_rejected += 1
                        t.rejected = getattr(t, "rejected", 0) + 1
                        continue          # ดีแค่ช่วงล่าสุด แต่แย่ลงเมื่อมองทั้งสัปดาห์หรือตอนผันผวน: ไม่เอา
                t.slots.append(Slot(g, src, a.bar_i))

    def _judge(self, t):
        """เทียบผลลองเทรด: ผู้ท้าชิงที่ชนะสูตรที่สอนอยู่ จะได้เป็นสูตรที่สอนแทน"""
        if len(t.slots) < 2 or (t.rush and t.rush.get("adopted")):
            return                            # ระหว่างโหมดเร่งด่วนรับข่าว ตัดสินตอนจบโหมดแทน
        a, goal = self.a, self._goal()
        cur = t.slots[0]
        keep = [cur]
        best = None
        for sl in t.slots[1:]:
            if sl.trades >= self.min_trial:
                gain = grade(sl.result(), goal) - grade(cur.result(), goal) if cur.trades >= self.min_trial \
                    else grade(sl.result(), goal)
                if gain > self.min_gain and sl.pnl > 0 and (best is None or gain > best[0]):
                    best = (gain, sl)
            if sl.trades >= self.max_trial or a.bar_i - sl.since > 6 * self.window:
                continue                      # ลองนานพอแล้วไม่ชนะ ทิ้ง
            keep.append(sl)
        t.slots = keep
        if best:
            gain, sl = best
            r = sl.result()
            for k in t.keys:
                t.lesson[k] = sl.g[k]
            t.improved += 1
            t.last_improve = a.bar_i
            if t.web:
                self._name_lesson(t, sl.src)
            new = Slot(t.lesson, "สูตรที่สอน", a.bar_i)
            new.trades, new.wins, new.pnl, new.peak, new.dd = sl.trades, sl.wins, sl.pnl, sl.peak, sl.dd
            t.slots = [new] + [x for x in t.slots[1:] if x is not sl]
            a.log("study", f"{t.name} (วิชา{t.subject}) ลองเทรดแล้วได้สูตรที่ดีกว่า ({sl.src}): "
                           f"ลองเทรด {r['trades']} ไม้ กำไร {fmt(r['pnl'])} ชนะ {pct(r['wr'])} ใช้เป็นสูตรสอนแทน")
            if t.mode == "thinking":
                t.mode = "ready"
                a.log("study", f"{t.name} ได้สูตรใหม่แล้ว กลับมาพร้อมเดินสอน")

    @staticmethod
    def _name_lesson(t, src):
        """ตั้งชื่อสูตรที่สอนของอาจารย์นักค้นคว้า: ตามเว็บตรงๆ หรือสูตรของตัวเองที่ต่อยอดมา"""
        if src.startswith("เว็บ:"):
            t.origin = src.split(":", 1)[1].strip()
            t.lesson_name = f"ตามเว็บ: {t.origin}"
        elif src.startswith("คิดเอง"):
            if t.origin is None:
                t.origin = (src.split("จาก", 1)[1] if "จาก" in src else "?").replace("ตามเว็บ:", "").strip()
            t.version += 1
            t.lesson_name = f"สูตรของ{t.name} v{t.version} (ต่อยอดจาก {t.origin})"

    # ---------- คำสั่งจากผู้ใช้ ----------
    def order_think(self, who):
        """ให้อาจารย์กลับห้องอาจารย์ ทิ้งผู้ท้าชิงเดิม แล้วคิดสูตรใหม่แบบกว้างขึ้น (ไม่ออกสอนในคาบตามรอบ)"""
        out = []
        for t in self.pick(who):
            t.mode = "thinking"
            t.think_until = self.a.bar_i + self.think_bars
            t.slots = t.slots[:1]
            self.study(only=[t], explore=0.25)
            out.append(t.name)
            self.a.log("study", f"{t.name} กลับห้องอาจารย์ไปคิดสูตรใหม่ ลองเทรด {len(t.slots) - 1} สูตร "
                                f"(นานสุด {self.think_bars} นาที หรือจนเจอสูตรที่ดีกว่า)")
        return out

    def order_teach(self, who):
        """ให้อาจารย์เดินสอนทันที"""
        ts = self.pick(who)
        for t in ts:
            t.mode = "ready"
        return self.teach_class("สั่งให้" + ("อาจารย์ทุกคน" if who == 0 else ts[0].name) + "เดินสอน", only=ts, forced=True)

    # ---------- คาบเรียน: อาจารย์เดินไปสอนบอททุกตัวที่เทรด ----------
    def teach_class(self, why="คาบเรียนตามรอบ", only=None, forced=False, windows=None, bots=None):
        if not self.enabled:
            return 0
        bars, L0 = self._window()
        ready = [t for t in (only or self.teachers) if t.lesson and (forced or t.mode == "ready")]
        if len(bars) < self.window // 2 or not ready:
            return 0
        a, goal, n = self.a, self._goal(), 0
        W = Window(a.s, bars, L0)
        Ws = windows or [(W, 1.0)]

        def sc(g):
            return sum(w * grade(self._test(g, X), goal) for X, w in Ws)
        ready = [t for t in ready if a.teacher_ok(f"t{t.id}")]     # อาจารย์ที่สอนแล้วไม่ช่วยจริง ได้สอนน้อยลง
        if not ready:
            return 0
        for b in (bots if bots is not None else a.bots):
            if b.jailed is not None or b.explorer or not a.can_learn(b):
                continue                          # บอทนักสำรวจเรียนจากผลเทรดของตัวเองเท่านั้น
            base = sc(b.g)
            best = None
            for t in ready:
                g = dict(b.g)
                for k in t.keys:
                    g[k] = t.lesson[k]
                gain = sc(g) - base
                if best is None or gain > best[0]:
                    best = (gain, t)
            if best is None or best[0] < self.min_gain:
                continue
            gain, t = best
            # บอทที่เทรดจริงอยู่แล้วปรับเบาๆ ตัวที่ยังไม่ผ่านเกณฑ์ปรับมากกว่า
            rate = 0.2 if b.live else 0.35 if a.eligible(b) else 0.6
            for k in t.keys:
                b.g[k] += (t.lesson[k] - b.g[k]) * rate
            fix_genome(b.g)
            b.taught += 1
            b.last_teacher = t.id
            a.lesson_given(b, f"t{t.id}")
            t.taught += 1
            n += 1
            self.seq += 1
            self.lessons.append([self.seq, t.id, b.id, round(gain, 2)])
            self.lessons = self.lessons[-60:]
            a.log("teach", f"{t.name} สอน{t.lesson_name or 'วิชา' + t.subject} ให้ {b.tag} (ทดสอบแล้วดีขึ้น {fmt(gain)})")
        if n or forced:
            a.log("teach", f"{why}: อาจารย์สอนบอทไป {n} ตัว")
        return n

    # ---------- โหมดเร่งด่วนรับข่าว ----------
    def _volatile_window(self, n=240):
        """ช่วงราคาที่ผันผวนที่สุดในข้อมูลที่มี (ใช้แทนสภาพตลาดตอนข่าวออก)"""
        a = self.a
        bars = list(a.bars)
        if len(bars) < n + 10:
            return None
        rs = [b.high - b.low for b in bars]
        cur = sum(rs[:n])
        best, j = cur, 0
        for i in range(n, len(rs)):
            cur += rs[i] - rs[i - n]
            if cur > best:
                best, j = cur, i - n + 1
        L0 = len(a.s.c) - len(bars) + j
        return Window(a.s, bars[j:j + n], L0), best / n

    def rush(self, why, until_ts):
        """ข่าวสำคัญมา: อาจารย์ทุกคนเร่งหาสูตรที่รับมือตลาดผันผวนได้ดี ทดสอบกับราคาช่วงที่ผันผวนที่สุด
        และราคาล่าสุด ถ้าเจอสูตรที่ดีกว่าสูตรที่สอนอยู่ ใช้เป็น "สูตรรับข่าว" ทันที (เก็บสูตรเดิมไว้สำรอง)
        แล้วเปิดคาบเรียนเร่งด่วนสอนบอท ตอนจบโหมดจะเทียบผลลองเทรดของสูตรรับข่าวกับสูตรเดิม"""
        if not self.enabled:
            return None
        a, rng, goal = self.a, self.a.rng, self._goal()
        bars, L0 = self._window()
        vw = self._volatile_window()
        if len(bars) < self.window // 2 or vw is None:
            return None
        Wl = Window(a.s, bars, L0)
        Wv, vol = vw
        Ws = [(Wl, 0.4), (Wv, 0.6)]

        def sc(g):
            return sum(w * grade(self._test(g, X), goal) for X, w in Ws)
        top = sorted([b for b in a.bots if b.jailed is None], key=a.rank_score, reverse=True)[:4]
        out = []
        for t in self.teachers:
            if not t.lesson or not t.keys:
                continue
            if t.rush and t.rush.get("adopted"):
                out.append((t, None, "ใช้สูตรรับข่าวอยู่แล้ว"))
                continue
            cur = dict(t.lesson)
            cands = [("สูตรเดิม", cur)] + [(x.src, dict(x.g)) for x in t.slots[1:]]
            for b in top:
                g = dict(cur)
                g.update({k: b.g[k] for k in t.keys})
                cands.append((b.tag, fix_genome(g)))
            for _ in range(8):                       # คิดแบบกว้างกว่าปกติ เพราะต้องรีบ
                g = dict(cur)
                g.update({k: cur[k] + rng.gauss(0, 0.25) * (GENE[k][1] - GENE[k][0]) for k in t.keys})
                cands.append(("คิดเร่งด่วน", fix_genome(g)))
            graded = sorted(((sc(g), src, g) for src, g in cands), key=lambda x: -x[0])
            base = next(x[0] for x in graded if x[1] == "สูตรเดิม")
            best = graded[0]
            if best[1] != "สูตรเดิม" and best[0] - base >= self.min_gain:
                t.rush = {"adopted": True, "why": why, "since": a.bar_i, "until": until_ts, "src": best[1],
                          "gain": round(best[0] - base, 2), "backup": cur, "backup_name": t.lesson_name}
                for k in t.keys:
                    t.lesson[k] = best[2][k]
                fix_genome(t.lesson)
                others = [x for x in t.slots[1:] if x.src != "สูตรเดิม (สำรอง)"][: self.trial_slots]
                t.slots = [Slot(t.lesson, "สูตรรับข่าว", a.bar_i), Slot(cur, "สูตรเดิม (สำรอง)", a.bar_i)] + others
                t.mode = "ready"
                out.append((t, best[0] - base, best[1]))
            else:
                t.rush = {"adopted": False, "why": why, "since": a.bar_i, "until": until_ts}
                out.append((t, None, "สูตรเดิมรับมือได้ดีอยู่แล้ว"))
        adopted = [x for x in out if x[1] is not None]
        for t, gain, src in adopted:
            a.log("study", f"{t.name} เร่งหาสูตรรับข่าว ({why}) ได้สูตรใหม่จาก{src} "
                           f"ทดสอบกับช่วงตลาดผันผวน (แท่งละ ${vol:.2f}) ดีขึ้น {fmt(gain)} ใช้สอนทันที เก็บสูตรเดิมไว้สำรอง")
        n = self.teach_class(f"คาบเร่งด่วนรับข่าว ({why})", forced=True, windows=Ws)
        return {"adopted": [t.id for t, g, s_ in adopted], "taught": n, "vol": round(vol, 2),
                "teachers": len(out)}

    def rush_end(self):
        """จบโหมดเร่งด่วน: สูตรรับข่าวที่ลองเทรดแล้วแย่กว่าสูตรเดิม กลับไปใช้สูตรเดิม"""
        a = self.a
        res = []
        for t in self.teachers:
            r = t.rush
            t.rush = None
            if not r or not r.get("adopted"):
                continue
            s0 = t.slots[0] if t.slots and t.slots[0].src == "สูตรรับข่าว" else None
            bk = next((x for x in t.slots if x.src == "สูตรเดิม (สำรอง)"), None)
            if s0 is None or bk is None:
                continue
            if s0.pnl < bk.pnl - 0.01:
                t.lesson = dict(r["backup"])
                bk.src = "สูตรที่สอน"
                t.slots = [bk] + [x for x in t.slots if x is not s0 and x is not bk]
                verdict = "กลับไปใช้สูตรเดิม"
            else:
                s0.src = "สูตรที่สอน"
                t.slots = [s0] + [x for x in t.slots if x is not s0 and x is not bk]
                t.improved += 1
                t.last_improve = a.bar_i
                verdict = "เก็บสูตรรับข่าวไว้ใช้ต่อ"
            res.append({"teacher": t.id, "name": t.name, "rush_pnl": round(s0.pnl, 2), "rush_trades": s0.trades,
                        "old_pnl": round(bk.pnl, 2), "old_trades": bk.trades, "verdict": verdict})
            a.log("study", f"{t.name} จบโหมดเร่งด่วน: สูตรรับข่าวลองเทรด {s0.trades} ไม้ {fmt(s0.pnl)} "
                           f"สูตรเดิม {bk.trades} ไม้ {fmt(bk.pnl)} → {verdict}")
        return res

    def jail_lesson(self, b, rate=0.02):
        """บอทในเขตห้ามเทรดเรียนสูตรเต็มจากอาจารย์ที่ผลงานดีที่สุด"""
        t = self.teachers[b.jailed["teacher"]] if b.jailed.get("teacher") is not None else None
        if t and t.lesson:
            for k in GENE:
                b.g[k] += (t.lesson[k] - b.g[k]) * rate

    def to_state(self):
        return {"teachers": [dict(t.to_dict(), _bar_i=self.a.bar_i) for t in self.teachers],
                "lessons": self.lessons, "seq": self.seq}

    def load_state(self, st):
        for d in st.get("teachers", []):
            if 0 <= d.get("id", -1) < len(self.teachers):
                self.teachers[d["id"]].load_dict(d, self.a.bar_i)
        self.lessons = st.get("lessons", [])
        self.seq = st.get("seq", 0)


def fmt(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def pct(v):
    return "-" if v is None else f"{v * 100:.0f}%"
