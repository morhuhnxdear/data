import json
import threading
import urllib.request


class Notifier:
    """ส่งข้อความเข้า Telegram (ถ้าตั้งค่าไว้) แบบไม่บล็อกการเทรด"""

    def __init__(self, cfg, log=None):
        n = cfg.get("notify", {})
        self.token = n.get("telegram_token", "").strip()
        self.chat = str(n.get("telegram_chat_id", "")).strip()
        self.log = log

    @property
    def enabled(self):
        return bool(self.token and self.chat)

    def send(self, text):
        if not self.enabled:
            return
        threading.Thread(target=self._send, args=(text,), daemon=True).start()

    def _send(self, text):
        try:
            data = json.dumps({"chat_id": self.chat, "text": text[:4000]}).encode()
            req = urllib.request.Request(f"https://api.telegram.org/bot{self.token}/sendMessage", data=data,
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=10).read()
        except Exception as e:  # แจ้งเตือนล้มเหลวต้องไม่ทำให้ระบบเทรดหยุด
            if self.log:
                self.log("warn", f"ส่ง Telegram ไม่สำเร็จ: {e}")
