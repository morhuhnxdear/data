"""เปิดเว็บแบบตรวจใบรับรอง HTTPS เสมอ (ไม่ปิดการตรวจ) แต่ลองหลายแหล่งใบรับรอง:
1) truststore: ใช้ใบรับรองของ Windows/macOS เอง (แก้กรณีโปรแกรมแอนตี้ไวรัสหรือ proxy บริษัทตรวจ HTTPS)
2) certifi: ชุดใบรับรองมาตรฐานของ Mozilla
3) ค่าเริ่มต้นของ Python
ถ้าแบบแรกตรวจไม่ผ่าน จะลองแบบถัดไป และจำแบบที่ใช้ได้ไว้ใช้ครั้งต่อไป"""
import ssl
import urllib.error
import urllib.request

_contexts = None
_good = None


def _build():
    out = []
    try:
        import truststore
        out.append(("ใบรับรองของระบบ (truststore)", truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)))
    except Exception:
        pass
    try:
        import certifi
        out.append(("certifi", ssl.create_default_context(cafile=certifi.where())))
    except Exception:
        pass
    out.append(("ค่าเริ่มต้นของ Python", ssl.create_default_context()))
    return out


def _is_cert_error(e):
    r = getattr(e, "reason", e)
    return isinstance(r, ssl.SSLCertVerificationError) or "CERTIFICATE_VERIFY_FAILED" in str(e)


def urlopen(req, timeout=20):
    """เหมือน urllib.request.urlopen แต่ลองแหล่งใบรับรองหลายแบบเมื่อเจอ CERTIFICATE_VERIFY_FAILED"""
    global _contexts, _good
    if _contexts is None:
        _contexts = _build()
    order = ([_good] if _good is not None else []) + [c for c in _contexts if c is not _good]
    last = None
    for item in order:
        try:
            r = urllib.request.urlopen(req, timeout=timeout, context=item[1])
            _good = item
            return r
        except (urllib.error.URLError, ssl.SSLError) as e:
            if not _is_cert_error(e):
                raise
            last = e
    raise urllib.error.URLError(
        f"ตรวจใบรับรอง HTTPS ไม่ผ่าน ({last}) ลองพิมพ์: py -3.12 -m pip install --upgrade truststore certifi")
