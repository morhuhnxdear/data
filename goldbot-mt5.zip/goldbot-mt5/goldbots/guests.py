"""EA รับเชิญ: ติดตามออเดอร์ของ EA ตัวอื่นที่รันอยู่ในบัญชีเดียวกัน (แยกด้วย magic number)
ระบบเราอ่านอย่างเดียว ไม่เปิด/ปิด/แก้ออเดอร์ของ EA รับเชิญ แล้วสรุปผลเทียบกับทีมบอทของเรา
พร้อมเตือนพฤติกรรมเสี่ยง (เบิ้ลไม้ วางไม้ซ้อน ล็อกไม้ ไม่มี SL) ใช้กับบัญชี Demo เท่านั้น"""
import datetime as dt
import time

from .eacheck import FLAG_TH, risk_check


def _day(t):
    return dt.datetime.fromtimestamp(t, dt.timezone.utc).date()


class Guests:
    def __init__(self, arena):
        self.a = arena
        c = arena.cfg.get("guest", {})
        self.enabled = bool(c.get("enabled", True))
        self.every = int(c.get("check_every", 5))                 # อ่านทุกกี่นาที
        self.lookback = int(c.get("lookback_days", 30))            # ครั้งแรกอ่านประวัติย้อนหลังกี่วัน
        self.manual = bool(c.get("include_manual", False))         # รวมไม้ที่เปิดเอง (magic 0) ไหม
        # EA รับเชิญขาดทุนค้าง (ยังไม่ปิด) รวมกันเกินนี้ ผู้คุมความเสี่ยงหยุดเปิดไม้เงินจริงของบอทเราชั่วคราว (margin ใช้ร่วมกัน)
        self.max_float = float(c.get("pause_if_float_loss", 100))
        self.block = False
        self.names = {}
        for x in c.get("names", []) or []:
            if ":" in str(x):
                k, v = str(x).split(":", 1)
                if k.strip().isdigit():
                    self.names[int(k.strip())] = v.strip()
        self.data = {}            # magic -> สรุปผล
        self.seen_flags = {}      # magic -> ธงที่แจ้งไปแล้ว
        self.since = None
        self.err = None
        self.last = -10 ** 9

    def tick(self, bar):
        a = self.a
        if not self.enabled or a.qualifying or a.ex is None or not hasattr(a.ex, "guest_trades"):
            return
        if a.bar_i - self.last < self.every:
            return
        self.last = a.bar_i
        if self.since is None:
            self.since = time.time() - self.lookback * 86400
        try:
            closed, opened = a.ex.guest_trades(self.since, self.manual)
            self.err = None
        except Exception as e:          # อ่านไม่ได้ต้องไม่ทำให้ระบบเทรดหยุด
            self.err = str(e)[:200]
            return
        self._summarize(closed, opened)

    def _summarize(self, closed, opened):
        a = self.a
        mags = sorted({p["magic"] for p in closed} | {p["magic"] for p in opened})
        out = {}
        for m in mags:
            cs = [p for p in closed if p["magic"] == m]
            os_ = [p for p in opened if p["magic"] == m]
            rc = risk_check(cs + [dict(p, close=time.time() + 10 ** 6, profit=p["profit"]) for p in os_]) \
                if os_ else risk_check(cs)
            rc_closed = risk_check(cs) if cs else {"trades": 0}
            today = sum(p["profit"] for p in cs if a.day is not None and _day(p["close"]) == a.day)
            flags = [(k, msg) for k, msg in rc.get("flags", [])]
            # ไม้ที่ยังถืออยู่และไม่มี SL ก็นับเป็นความเสี่ยง
            no_sl_open = sum(1 for p in os_ if not p.get("sl"))
            nb, ns = sum(1 for p in os_ if p["dir"] > 0), sum(1 for p in os_ if p["dir"] < 0)
            if nb and ns and not any(k == "lock" for k, _ in flags):
                flags.append(("lock", f"กำลังถือไม้ซื้อ {nb} ไม้และขาย {ns} ไม้พร้อมกัน (ล็อกไม้)"))
            if no_sl_open and not any(k == "no_sl" for k, _ in flags):
                flags.append(("no_sl", f"ถือไม้ที่ไม่มี SL อยู่ {no_sl_open} ไม้"))
            out[m] = {"magic": m, "name": self.names.get(m) or ("เทรดมือ" if m == 0 else f"EA magic {m}"),
                      "trades": rc_closed.get("trades", 0), "total": round(sum(p["profit"] for p in cs), 2),
                      "today": round(today, 2), "win_rate": rc_closed.get("win_rate"), "pf": rc_closed.get("pf"),
                      "max_dd": round(rc_closed.get("max_dd_closed", 0.0), 2), "worst": rc_closed.get("worst"),
                      "open_n": len(os_), "open_lots": round(sum(p["volume"] for p in os_), 2),
                      "open_pnl": round(sum(p["profit"] for p in os_), 2),
                      "open_buy": sum(1 for p in os_ if p["dir"] > 0), "open_sell": sum(1 for p in os_ if p["dir"] < 0),
                      "flags": [[k, FLAG_TH.get(k, k), msg] for k, msg in flags],
                      "last": max([p["close"] for p in cs] + [p["open"] for p in os_] or [0])}
            seen = self.seen_flags.setdefault(m, set())
            for k, msg in flags:
                if k not in seen:
                    seen.add(k)
                    a.log("risk", f"EA รับเชิญ {out[m]['name']}: ⚠ {msg} (ระบบเราไม่แตะออเดอร์ของ EA นี้ แต่ใช้ margin ร่วมกัน)")
            if m not in self.data:
                a.log("team", f"พบ EA รับเชิญ {out[m]['name']} ในบัญชี: เทรดแล้ว {out[m]['trades']} ไม้ "
                              f"ถืออยู่ {len(os_)} ไม้ จะติดตามผลเทียบกับทีมบอท")
        self.data = out
        fl = sum(g["open_pnl"] for g in out.values())
        blk = self.max_float > 0 and fl <= -self.max_float
        if blk != self.block:
            self.block = blk
            a.log("risk", f"ผู้คุมความเสี่ยง: EA รับเชิญขาดทุนค้างรวม ${-fl:,.2f} เกิน ${self.max_float:,.0f} "
                          "หยุดเปิดไม้เงินจริงของบอทเราชั่วคราว (ใช้ margin ร่วมกัน)" if blk else
                  "ผู้คุมความเสี่ยง: EA รับเชิญขาดทุนค้างลดลงแล้ว บอทเรากลับมาเปิดไม้เงินจริงได้")

    def dash(self):
        a = self.a
        live = [b for b in a.bots if b.live_trades]
        return {"enabled": self.enabled, "error": self.err, "list": list(self.data.values()), "block": self.block,
                "max_float": self.max_float,
                "team": {"total": round(a.team_total, 2), "today": round(a.team_today, 2),
                         "trades": sum(b.live_trades for b in live), "wins": sum(b.live_wins for b in live)}}

    def to_state(self):
        return {"since": self.since, "seen": {str(k): sorted(v) for k, v in self.seen_flags.items()}}

    def load_state(self, st):
        self.since = st.get("since", self.since)
        self.seen_flags = {int(k): set(v) for k, v in (st.get("seen") or {}).items()}
