class SimExecutor:
    """ตัวส่งคำสั่งจำลอง ใช้ใน backtest: ออเดอร์ "เงินจริง" ถูกจำลองด้วยราคาในไฟล์ พร้อม spread และค่าคอม"""

    def open(self, arena, b, d, lot, sl_d, tp_d, bar):
        entry = bar.close + bar.spread if d > 0 else bar.close
        return {"entry": entry, "sl": entry - d * sl_d, "tp": entry + d * tp_d, "ticket": None}

    def poll(self, arena, bar):
        out = []
        for b in arena.bots:
            if b.pos and b.pos["live"]:
                r = arena.paper_exit(b, bar)
                if r:
                    out.append((b, arena._pnl(b.pos, r[0], arena.B["lot"]), r[1]))
        return out

    def close(self, arena, b, bar):
        return arena._pnl(b.pos, arena.market_exit_price(b.pos, bar), arena.B["lot"])
