"""โหลดข้อมูลราคาแท่ง M1 จากไฟล์ CSV (ไฟล์ที่ export_history.py สร้าง หรือไฟล์ที่ Export จากหน้าต่าง Symbols ของ MT5)"""
import csv
import datetime as dt
import math
import random

from .arena import Bar


def _ts(date_s, time_s=None):
    s = date_s.strip().replace(".", "-")
    if time_s:
        s += " " + time_s.strip()
    if s.isdigit():
        return int(s)
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return int(dt.datetime.strptime(s, fmt).replace(tzinfo=dt.timezone.utc).timestamp())
        except ValueError:
            pass
    raise ValueError(f"อ่านวันเวลาไม่ได้: {s}")


def load_csv(path, point=0.01, default_spread=0.25):
    with open(path, encoding="utf-8-sig") as f:
        head = f.readline()
        delim = "\t" if "\t" in head else ";" if head.count(";") > head.count(",") else ","
        f.seek(0)
        rows = list(csv.reader(f, delimiter=delim))
    header = [h.strip().strip("<>").lower() for h in rows[0]]
    idx = {h: i for i, h in enumerate(header)}
    bars = []
    for r in rows[1:]:
        if not r or len(r) < 5:
            continue
        if "date" in idx:
            t = _ts(r[idx["date"]], r[idx["time"]] if "time" in idx else None)
        else:
            t = _ts(r[idx["time"]])
        sp = default_spread
        if "spread" in idx and r[idx["spread"]].strip():
            v = float(r[idx["spread"]])
            sp = v * point if v > 0 else default_spread
        bars.append(Bar(t, float(r[idx["open"]]), float(r[idx["high"]]), float(r[idx["low"]]),
                        float(r[idx["close"]]), sp))
    bars.sort(key=lambda b: b.time)
    return bars


def synthetic(days=30, seed=1, start=3300.0, spread=0.25):
    """ข้อมูลปลอมไว้ลองโปรแกรมเท่านั้น ห้ามใช้ตัดสินใจลงทุน"""
    rng = random.Random(seed)
    t = int(dt.datetime(2025, 1, 6, tzinfo=dt.timezone.utc).timestamp())
    p = start
    bars, drift, vol, left, anchor, kind = [], 0.0, 0.5, 0, p, "range"
    day = 0
    while day < days:
        d = dt.datetime.fromtimestamp(t, dt.timezone.utc)
        if d.weekday() >= 5:
            t += 60
            continue
        if left <= 0:
            kind = rng.choice(["up", "down", "range"])
            drift = {"up": rng.uniform(0.01, 0.05), "down": -rng.uniform(0.01, 0.05), "range": 0}[kind]
            vol, left, anchor = rng.uniform(0.25, 0.9), rng.randint(120, 600), p
        left -= 1
        o = p
        path = [o]
        for _ in range(4):
            step = drift / 4 + vol / 2 * rng.gauss(0, 1)
            if kind == "range":
                step += (anchor - path[-1]) * 0.005
            path.append(path[-1] + step)
        p = path[-1]
        bars.append(Bar(t, o, max(path), min(path), p, spread))
        t += 60
        if dt.datetime.fromtimestamp(t, dt.timezone.utc).date() != d.date():
            day += 1
    return bars
