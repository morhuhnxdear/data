"""ผู้คุมชุดใหม่ 5 คน (เพิ่มจากผู้คุมวินัยและผู้คุมความเสี่ยง รวมเป็น 7 คน)
1) ผู้คุมกำไร: ทีมเงินจริงเคยกำไรถึงระดับหนึ่งแล้วคืนกำไรเกินครึ่ง ปิดออเดอร์จริงและหยุดเทรดจริงถึงสิ้นวัน (เก็บกำไรที่เหลือไว้)
2) ผู้คุมขาดทุนรายสัปดาห์: ทีมเงินจริงขาดทุนในสัปดาห์นี้ถึงเพดาน หยุดเทรดจริงถึงสัปดาห์หน้า
3) ผู้คุมทิศทาง: ไม่ให้ทีมเงินจริงถือออเดอร์ทิศเดียวกันพร้อมกันเกินกำหนด (กันพอร์ตเสี่ยงไปทางเดียว)
4) ผู้คุมเทรดถี่: บอทในทีมเงินจริงเปิดออเดอร์จริงในวันเดียวเกินกำหนด พักจากทีมเงินจริงถึงสิ้นวัน
5) ผู้คุมแถว (กรรมการแข่งแถว): ตัดสินการแข่งขันระหว่างแถวทุกวัน แจกถ้วยแถวที่ชนะเฉลี่ยสูงสุด
ทุกคนยอมให้บอทฝึกเทรดต่อ หยุดเฉพาะเงินจริง"""
from .contest import week_key


def money(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


GUARDS = [
    # (รหัส, ชื่อ, หน้าที่, สีเครื่องแบบ)
    ("discipline", "ผู้คุมวินัย", "จับบอทที่แพ้ติดกัน ขาดทุนเกินเพดาน หรือออเดอร์ไม่ตรงสูตร ส่งเข้าเขตห้ามเทรด", "#2a3d66"),
    ("risk", "ผู้คุมความเสี่ยง", "ดูแลเงินจริงทั้งพอร์ต: spread, ราคากระชาก, ออเดอร์ไม่มี SL, เพดานขาดทุนทีมรายวัน", "#7a2230"),
    ("profit", "ผู้คุมกำไร", "ทีมเงินจริงคืนกำไรเกินกำหนดจากจุดสูงสุดของวัน ปิดเก็บกำไรที่เหลือและหยุดเทรดจริงถึงสิ้นวัน", "#1C7C53"),
    ("weekly", "ผู้คุมขาดทุนรายสัปดาห์", "ทีมเงินจริงขาดทุนในสัปดาห์ถึงเพดาน หยุดเทรดจริงถึงสัปดาห์หน้า", "#5B21B6"),
    ("direction", "ผู้คุมทิศทาง", "ไม่ให้ทีมเงินจริงถือออเดอร์ทิศเดียวกันพร้อมกันเกินกำหนด", "#0E7490"),
    ("overtrade", "ผู้คุมเทรดถี่", "บอทในทีมเปิดออเดอร์จริงในวันเดียวเกินกำหนด พักจากทีมเงินจริงถึงสิ้นวัน", "#B45309"),
    ("rows", "ผู้คุมแถว", "กรรมการแข่งขันระหว่างแถว ตัดสินทุกวันว่าแถวไหนชนะเฉลี่ยสูงสุด แจกถ้วยแถว", "#9D174D"),
]


class Guards:
    def __init__(self, arena):
        self.a = arena
        sv = arena.SV
        self.giveback_min_peak = float(sv.get("giveback_min_peak", 30))
        self.giveback_pct = float(sv.get("giveback_pct", 50))
        self.weekly_max_loss = float(sv.get("weekly_max_loss", 300))
        self.max_same_dir = int(sv.get("max_same_direction_live", 3))
        self.max_live_trades = int(sv.get("max_live_trades_per_bot_day", 8))
        self.peak_today = 0.0
        self.giveback_halt = False
        self.week = None
        self.team_week = 0.0
        self.week_halt = False
        self.opens_today = {}       # บอท -> ออเดอร์จริงที่เปิดวันนี้
        self.benched = set()        # บอทที่ผู้คุมเทรดถี่พักจากทีมเงินจริงถึงสิ้นวัน
        self.count = {g[0]: 0 for g in GUARDS}   # ทำงานกี่ครั้ง (ไว้แสดงในแดชบอร์ด)
        self.dir_blocked_today = 0
        self._dir_warned = -10 ** 9
        self.seq = 0
        self.events = []            # [ลำดับ, รหัสผู้คุม, ข้อความสั้น] สำหรับภาพออฟฟิศ

    def _event(self, code, text):
        self.seq += 1
        self.count[code] = self.count.get(code, 0) + 1
        self.events = (self.events + [[self.seq, code, text]])[-40:]

    # ---------- ใช้ตอนตัดสินใจเทรดเงินจริง ----------
    def block_reason(self):
        if self.giveback_halt:
            return "ผู้คุมกำไรสั่งหยุดเทรดจริงถึงสิ้นวัน (เก็บกำไรไว้)"
        if self.week_halt:
            return "ผู้คุมขาดทุนรายสัปดาห์สั่งหยุดเทรดจริงถึงสัปดาห์หน้า"
        return None

    def is_benched(self, b):
        return b.id in self.benched

    def open_check(self, b, d):
        """ตรวจก่อนเปิดออเดอร์เงินจริง คืนเหตุผลถ้าไม่อนุญาต (บอทจะเปิดเป็นออเดอร์ฝึกแทน)"""
        a = self.a
        if self.opens_today.get(b.id, 0) >= self.max_live_trades:
            self.benched.add(b.id)
            self._event("overtrade", f"{b.tag} เทรดถี่เกิน")
            a.log("risk", f"ผู้คุมเทรดถี่: {b.tag} เปิดออเดอร์จริงวันนี้ครบ {self.max_live_trades} ไม้แล้ว พักจากทีมเงินจริงถึงสิ้นวัน")
            a.set_live(b, False, "ผู้คุมเทรดถี่สั่งพักถึงสิ้นวัน")
            a.fill_lineup(f"แทนที่ {b.tag}")
            return "เทรดถี่เกิน"
        same = sum(1 for x in a.bots if x.pos and x.pos["live"] and x.pos["dir"] == d)
        if same >= self.max_same_dir:
            self.dir_blocked_today += 1
            if a.bar_i - self._dir_warned >= 30:
                self._dir_warned = a.bar_i
                self._event("direction", f"ฝั่ง{'ซื้อ' if d > 0 else 'ขาย'}เต็มแล้ว")
                a.log("risk", f"ผู้คุมทิศทาง: ทีมถือออเดอร์จริงฝั่ง{'ซื้อ' if d > 0 else 'ขาย'}อยู่แล้ว {same} ไม้ (สูงสุด {self.max_same_dir}) "
                              f"{b.tag} เปิดเป็นออเดอร์ฝึกแทน")
            return "ทิศเดียวกันเต็ม"
        return None

    def on_live_open(self, b):
        self.opens_today[b.id] = self.opens_today.get(b.id, 0) + 1

    def on_live_close(self, b, pnl):
        a = self.a
        self.team_week += pnl
        self.peak_today = max(self.peak_today, a.team_today)
        if not self.giveback_halt and self.peak_today >= self.giveback_min_peak \
                and a.team_today <= self.peak_today * (1 - self.giveback_pct / 100):
            self.giveback_halt = True
            self._event("profit", "ปิดเก็บกำไร!")
            msg = (f"ผู้คุมกำไร: ทีมเคยกำไรสูงสุดวันนี้ {money(self.peak_today)} ตอนนี้เหลือ {money(a.team_today)} "
                   f"คืนกำไรเกิน {self.giveback_pct:.0f}% ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน")
            a.log("risk", msg)
            a.notify(msg)
            a.close_all_live("ผู้คุมกำไรสั่งเก็บกำไร")
        if not self.week_halt and self.team_week <= -self.weekly_max_loss:
            self.week_halt = True
            self._event("weekly", "หยุดถึงสัปดาห์หน้า")
            msg = (f"ผู้คุมขาดทุนรายสัปดาห์: ทีมเงินจริงขาดทุนสัปดาห์นี้ {money(self.team_week)} ถึงเพดาน "
                   f"{money(-self.weekly_max_loss)} หยุดเทรดจริงถึงสัปดาห์หน้า บอทยังฝึกเทรดต่อ")
            a.log("risk", msg)
            a.notify(msg)
            a.close_all_live("ผู้คุมขาดทุนรายสัปดาห์สั่งหยุด")

    # ---------- วัน / สัปดาห์ ----------
    def end_day(self):
        a = self.a
        if not a.qualifying:
            res = a.rows.award_day()
            if res:
                self._event("rows", f"แถว {res[0] + 1} ชนะ!")
        self.peak_today = 0.0
        self.giveback_halt = False
        self.opens_today = {}
        if self.benched:
            a.log("team", "ผู้คุมเทรดถี่: วันใหม่ บอทที่ถูกพักกลับมาลงทีมเงินจริงได้ ("
                  + ", ".join(a.bots[i].tag for i in sorted(self.benched)) + ")")
        self.benched = set()
        self.dir_blocked_today = 0

    def new_day(self, day):
        wk = week_key(day)
        if self.week != wk:
            if self.week is not None and self.week_halt:
                self.a.log("risk", "ผู้คุมขาดทุนรายสัปดาห์: สัปดาห์ใหม่ กลับมาเทรดจริงได้")
            self.week = wk
            self.team_week = 0.0
            self.week_halt = False

    # ---------- แสดงผล / บันทึก ----------
    def dash(self):
        a = self.a
        status = {
            "discipline": f"ขังอยู่ {sum(1 for b in a.bots if b.jailed)} ตัว · แพ้ติดกัน {a.SV['max_consecutive_losses']} ไม้หรือขาดทุนวันละ "
                          f"{money(-a.SV['bot_daily_loss_limit'])} ถูกขัง",
            "risk": ("หยุดเทรดจริง (ถึงเพดานขาดทุนทีม)" if a.halted else
                     f"พักเพราะราคากระชาก/spread วันนี้ {a.risk_blocks + a.spread_blocked} ครั้ง · เพดานทีม {money(-a.T['max_daily_loss'])}/วัน"),
            "profit": ("หยุดเทรดจริงถึงสิ้นวันแล้ว (เก็บกำไร)" if self.giveback_halt else
                       f"กำไรสูงสุดวันนี้ {money(self.peak_today)} · ถ้าเคยถึง {money(self.giveback_min_peak)} แล้วคืนเกิน "
                       f"{self.giveback_pct:.0f}% จะปิดเก็บกำไร"),
            "weekly": ("หยุดเทรดจริงถึงสัปดาห์หน้า" if self.week_halt else
                       f"ทีมสัปดาห์นี้ {money(self.team_week)} · เพดาน {money(-self.weekly_max_loss)}"),
            "direction": (f"ฝั่งเดียวกันถือได้สูงสุด {self.max_same_dir} ไม้ · ตอนนี้ซื้อ "
                          f"{sum(1 for b in a.bots if b.pos and b.pos['live'] and b.pos['dir'] > 0)} ขาย "
                          f"{sum(1 for b in a.bots if b.pos and b.pos['live'] and b.pos['dir'] < 0)} · กันไว้วันนี้ {self.dir_blocked_today} ครั้ง"),
            "overtrade": (f"เปิดจริงได้ตัวละ {self.max_live_trades} ไม้/วัน · พักอยู่ "
                          + (", ".join(a.bots[i].tag for i in sorted(self.benched)) if self.benched else "ไม่มี")),
            "rows": a.rows.referee_text(),
        }
        alert = {"profit": self.giveback_halt, "weekly": self.week_halt, "risk": a.halted,
                 "overtrade": bool(self.benched), "discipline": False, "direction": False, "rows": False}
        return {"list": [{"code": c, "name": n, "duty": d, "color": col, "status": status[c], "alert": alert[c],
                          "count": self.count.get(c, 0)} for c, n, d, col in GUARDS],
                "events": self.events[-20:], "seq": self.seq, "benched": sorted(self.benched)}

    def to_state(self):
        return {"peak_today": self.peak_today, "giveback_halt": self.giveback_halt, "week": self.week,
                "team_week": self.team_week, "week_halt": self.week_halt,
                "opens_today": {str(k): v for k, v in self.opens_today.items()}, "benched": sorted(self.benched),
                "count": self.count, "dir_blocked_today": self.dir_blocked_today, "seq": self.seq, "events": self.events}

    def load_state(self, st):
        for k in ("peak_today", "giveback_halt", "week", "team_week", "week_halt", "count", "dir_blocked_today",
                  "seq", "events"):
            if k in st:
                setattr(self, k, st[k])
        self.opens_today = {int(k): v for k, v in st.get("opens_today", {}).items()}
        n = len(self.a.bots)
        self.benched = {i for i in st.get("benched", []) if 0 <= i < n}
