from collections import deque

NAMES = ["ทองแท้", "สิงห์", "มังกร", "พยัคฆ์", "เหยี่ยว", "กระทิง", "หมีขาว", "จิ้งจอก", "นกฮูก", "ฉลาม",
         "ม้าเร็ว", "แมวดำ", "กระต่าย", "ช้างศึก", "อินทรี", "งูเห่า", "ปลาวาฬ", "ผึ้งงาน", "หมาป่า", "เต่าทอง",
         "เสือดาว", "กวางทอง", "นกยูง", "โลมา", "แรด", "ม้าลาย", "ยีราฟ", "จระเข้", "กระเรียน", "หงส์",
         "กระรอก", "วานร", "นากทะเล", "หมึกยักษ์", "นกแก้ว", "อูฐ", "ควายทอง", "ไก่ชน", "ปูทอง", "แพนด้า"]

# ช่วงค่าของ "สูตร" แต่ละตัว  (sl / tp เป็นระยะราคาหน่วยดอลลาร์)
GENE = {
    "wT": (0.05, 1.5),    # น้ำหนักสัญญาณตามเทรนด์ (เส้นค่าเฉลี่ยเร็ว/ช้า)
    "wM": (0.05, 1.5),    # น้ำหนักสัญญาณสวนกลับ (RSI)
    "wB": (0.05, 1.5),    # น้ำหนักสัญญาณเบรกเอาต์
    "fast": (3, 15),
    "slow": (16, 60),
    "rsiN": (6, 20),
    "rsiLo": (18, 42),
    "rsiHi": (58, 82),
    "brkN": (10, 50),
    "sl": (2.0, 25.0),
    "tp": (1.5, 40.0),
    "thr": (0.2, 0.75),   # เกณฑ์ความแรงสัญญาณขั้นต่ำ
    "lr": (0.02, 0.15),   # อัตราการเรียนรู้
}


def clamp(x, a, b):
    return a if x < a else b if x > b else x


def fix_genome(g):
    for k, (a, b) in GENE.items():
        g[k] = clamp(g[k], a, b)
    return g


def genome_dist(a, b):
    return sum(abs(a[k] - b[k]) / (hi - lo) for k, (lo, hi) in GENE.items())


class Bot:
    def __init__(self, i, name, rng, window):
        self.id = i
        self.name = name
        self.g = {k: rng.uniform(a, b) for k, (a, b) in GENE.items()}
        self.today = 0.0
        self.total = 0.0
        self.trades = 0
        self.wins = 0
        self.today_trades = 0
        self.today_wins = 0
        self.live_today = 0.0
        self.live_total = 0.0
        self.live_trades = 0
        self.live_wins = 0
        self.recent = deque(maxlen=window)
        self.consec_losses = 0
        self.live = False
        self.paused = False
        self.jailed = None      # {"until": bar, "mentor": id, "reason": str}
        self.pos = None         # {"dir","entry","sl","tp","bar0","live","ticket","comps"}
        self.violations = 0
        self.chats = 0
        self.tips = 0
        self.learn_count = 0     # ปรับสูตรจากผลเทรดของตัวเองกี่ครั้ง
        self.learn_today = 0
        self.taught = 0          # ถูกสอน (คาบเรียน/เขตห้ามเทรด/สั่งสอน) กี่ครั้ง
        self.last_teacher = None
        self.g0 = dict(self.g)   # สูตรตอนเริ่ม ใช้วัดว่าสูตรเปลี่ยนไปแค่ไหน

    @property
    def tag(self):
        return f"บอท {self.id + 1:02d} {self.name}"

    def recent_wr(self):
        return sum(self.recent) / len(self.recent) if self.recent else None

    def signals(self, s):
        return signal_at(self.g, s, len(s.c))


    # ---------- บันทึก/โหลดสถานะ ----------
    FIELDS = ["today", "total", "trades", "wins", "today_trades", "today_wins", "live_today", "live_total",
              "live_trades", "live_wins", "consec_losses", "live", "paused", "jailed", "pos", "violations",
              "chats", "tips", "learn_count", "learn_today", "taught", "last_teacher"]

    def change_pct(self):
        """สูตรเปลี่ยนไปจากตอนเริ่มกี่ % (เฉลี่ยทุกค่า เทียบกับช่วงที่เป็นไปได้)"""
        return 100 * genome_dist(self.g, self.g0) / len(GENE)

    def to_dict(self):
        d = {k: getattr(self, k) for k in self.FIELDS}
        d.update(id=self.id, name=self.name, g=self.g, g0=self.g0, recent=list(self.recent),
                 change_pct=round(self.change_pct(), 2))
        return d

    def load_dict(self, d):
        for k in self.FIELDS:
            if k in d:
                setattr(self, k, d[k])
        self.g = fix_genome({k: float(d["g"].get(k, self.g[k])) for k in GENE})
        self.g0 = fix_genome({k: float(d.get("g0", d["g"]).get(k, self.g[k])) for k in GENE})
        self.recent.clear()
        self.recent.extend(d.get("recent", []))


def signal_at(g, s, L):
    """คำนวณสัญญาณของสูตร g ณ จุดที่มีราคาปิด L แท่ง (ใช้ทั้งตอนเทรดและตอนครูทดสอบย้อนหลัง)"""
    if True:
        p = s.c[L - 1]
        sd = max(0.3, s.vol_at(30, L))
        t = clamp((s.sma_at(round(g["fast"]), L) - s.sma_at(round(g["slow"]), L)) / (2 * sd), -1.0, 1.0)
        r = s.rsi_at(round(g["rsiN"]), L)
        m = 0.0
        if r < g["rsiLo"]:
            m = clamp((g["rsiLo"] - r) / 15, 0.0, 1.0)
        elif r > g["rsiHi"]:
            m = -clamp((r - g["rsiHi"]) / 15, 0.0, 1.0)
        hi, lo = s.hilo_at(round(g["brkN"]), L)
        bk = 0.0
        if p > hi:
            bk = clamp((p - hi) / sd + 0.5, 0.0, 1.0)
        elif p < lo:
            bk = -clamp((lo - p) / sd + 0.5, 0.0, 1.0)
        W = g["wT"] + g["wM"] + g["wB"]
        score = (g["wT"] * t + g["wM"] * m + g["wB"] * bk) / W
        return t, m, bk, score

