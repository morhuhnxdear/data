from collections import deque

NAMES = ["ทองคำ", "ทองแท้", "ทองดี", "ทองมา", "ทองเต็ม", "ทองพูน", "ทองล้น", "ทองหยิบ", "ทองเอก", "ทองทวี",
         "เฮง", "ปัง", "รวย", "มั่งมี", "ร่ำ", "ลาภ", "โชค", "มณี", "เพชร", "นพเก้า",
         "ขึ้น", "พุ่ง", "ทะยาน", "ไฮ", "บูม", "ฟ้า", "เทียน", "กรีน", "ท็อป", "วิน",
         "แม่น", "นิ่ง", "ชัวร์", "คม", "ไว", "เป๊ะ", "เฉียบ", "ปราชญ์", "ตาทิพย์", "ใจเย็น",
         "โกลดี้", "ออรัม", "ไมดาส", "บูลลี่", "แพลตตินัม", "ลัคกี้", "ริชชี่", "โกลด์ฟินช์", "โซล", "แจ็คพอต",
         "มงคล", "ศรี", "สุข", "เจริญ", "รุ่ง", "เรือง", "ทรัพย์", "มั่นคง", "พูนผล", "อุดม",
         "ดาว", "เดือน", "ตะวัน", "รุ้ง", "สายฟ้า", "พายุ", "ฟีนิกซ์", "มังกร", "สิงห์", "อินทรี",
         "เสือ", "ม้าทอง", "หงส์", "กิเลน", "นาคา", "ไพลิน", "ทับทิม", "มรกต", "บุษราคัม", "โกเมน",
         "ไข่มุก", "อำพัน", "หยก", "เงินยวง", "นาก", "ทองเหลือง", "ทองชมพู", "ทองขาว", "ทองทราย", "ทองฟ้า",
         "เทรนดี้", "ชาร์ต", "แท่งเทียน", "ซิกม่า", "อัลฟ่า", "เบต้า", "เดลต้า", "โอเมก้า", "แมคดี", "ฟีโบ"]

# ช่วงค่าของ "สูตร" แต่ละตัว  (sl / tp เป็นระยะราคาหน่วยดอลลาร์)
GENE = {
    "wT": (0.05, 1.5),    # น้ำหนักสัญญาณตามเทรนด์ (เส้นค่าเฉลี่ยเร็ว/ช้า)
    "wM": (0.05, 1.5),    # น้ำหนักสัญญาณสวนกลับ (RSI)
    "wB": (0.05, 1.5),    # น้ำหนักสัญญาณเบรกเอาต์
    "fast": (3, 15),
    "slow": (16, 60),
    "rsiN": (6, 20),
    "rsiLo": (18, 42),
    "rsiHi": (58, 82),
    "brkN": (10, 50),
    "sl": (2.0, 25.0),
    "tp": (1.5, 40.0),
    "thr": (0.2, 0.75),   # เกณฑ์ความแรงสัญญาณขั้นต่ำ
    "lr": (0.02, 0.15),   # อัตราการเรียนรู้
    "slA": (0.8, 8.0),    # ตัดขาดทุนกี่เท่าของ ATR (ใช้เมื่อเปิด atr_stops)
    "tpA": (0.4, 10.0),   # ทำกำไรกี่เท่าของ ATR (ใช้เมื่อเปิด atr_stops)
    "htfN": (4, 48),      # เส้นค่าเฉลี่ยเทรนด์ใหญ่กี่ชั่วโมง (ใช้เมื่อเปิด htf_filter)
    "htfW": (0.0, 1.0),   # เคารพเทรนด์ใหญ่แค่ไหน 0 = ไม่สนใจ, 1 = ห้ามเทรดสวนเทรนด์ใหญ่เด็ดขาด
    # รู้จักสภาพตลาด: น้ำหนักสัญญาณตามช่วงเวลาตลาด และตอนตลาดผันผวนแรง (1 = เทรดเต็มที่, 0 = ไม่เทรดช่วงนั้น)
    "sA": (0.0, 1.0),     # ช่วงตลาดเอเชีย (22:00-07:00 UTC)
    "sE": (0.0, 1.0),     # ช่วงตลาดยุโรป (07:00-13:00 UTC)
    "sU": (0.0, 1.0),     # ช่วงตลาดสหรัฐ (13:00-22:00 UTC)
    "vH": (0.0, 1.0),     # ตอนตลาดผันผวนแรง (ATR สั้นสูงกว่าค่าเฉลี่ยทั้งวันเกิน 1.5 เท่า)
    # วิธีออกจากออเดอร์ (หน่วยเป็นเท่าของระยะตัดขาดทุนตอนเข้า = 1R)
    "be": (0.3, 2.0),     # กำไรถึงกี่ R แล้วเลื่อน SL มาที่ราคาเข้า (ไม่ขาดทุนแล้ว) เกิน 1.8 = ไม่ใช้
    "trl": (0.0, 3.0),    # เลื่อน SL ตามราคา ห่างจากราคาที่ดีที่สุดกี่ R ต่ำกว่า 0.5 = ไม่ใช้
    "hold": (2.0, 16.0),  # ถือไม้นานสุดเท่าไร (16 = เต็ม max_hold_bars, 8 = ครึ่งหนึ่ง) ไม้ที่ไม่ไปไหนจะถูกปิดเร็วขึ้น
    "vk": (1.0, 3.0),     # สายตามแรงกระชาก: แท่งล่าสุดวิ่งกี่เท่าของ ATR ถึงนับว่ากระชาก
}

# สายของบอท (แบ่งตามแถว แถวละ 10 ตัว 2 แถวต่อสาย = สายละ 20 ตัว) แต่ละสายใช้สัญญาณของตัวเองอย่างเดียว
# จึงไม่กลายเป็นสูตรเดียวกันหมด และตลาดแบบไหนก็มีบางสายที่ถนัด
FAMILIES = [("trend", "สายตามเทรนด์", "เส้นค่าเฉลี่ยเร็วอยู่เหนือ/ใต้เส้นช้า"),
            ("revert", "สายสวนกลับ", "RSI ซื้อมากเกิน/ขายมากเกิน แล้วเข้าสวน"),
            ("breakout", "สายเบรกเอาต์", "ราคาทะลุจุดสูงสุด/ต่ำสุดเดิม"),
            ("session", "สายเบรกกรอบเอเชีย", "ตลาดยุโรป/สหรัฐเปิดแล้วราคาทะลุกรอบช่วงเอเชีย"),
            ("burst", "สายตามแรงกระชาก", "แท่งวิ่งแรงผิดปกติ (มักเป็นตอนข่าว) แล้วตามทิศนั้น")]


FAM_COUNTS = [20, 20, 20, 40, 0]   # จำนวนบอทต่อสาย ตามลำดับใน FAMILIES (ตั้งได้ที่ families หมวด [bots])


def family_of(bot_id, n_bots=100):
    """สายของบอทตามลำดับ: นับตาม FAM_COUNTS (ค่าเริ่มต้น 1-20 ตามเทรนด์, 21-40 สวนกลับ, 41-60 เบรกเอาต์,
    61-100 เบรกกรอบเอเชีย, สายตามแรงกระชากไม่มีบอท เพราะผลทดสอบขาดทุนทุกรอบ)"""
    acc = 0
    for f, n in enumerate(FAM_COUNTS):
        acc += n
        if bot_id < acc:
            return f
    return max(f for f, n in enumerate(FAM_COUNTS) if n > 0) if any(FAM_COUNTS) else 0


def family_ranges():
    """[(สาย, บอทตัวแรก, บอทตัวสุดท้าย)] เฉพาะสายที่มีบอท (นับจาก 1)"""
    out, acc = [], 0
    for f, n in enumerate(FAM_COUNTS):
        if n > 0:
            out.append((f, acc + 1, acc + n))
        acc += n
    return out
# ค่าที่ใช้เมื่อสูตรเก่า (ก่อนมีค่านี้) ไม่มีค่านั้น ให้ทำงานเหมือนเดิม
GENE_MISSING = {"sA": 1.0, "sE": 1.0, "sU": 1.0, "vH": 1.0, "be": 2.0, "trl": 0.0, "hold": 16.0, "vk": 2.0}
BE_OFF = 1.8
TRL_ON = 0.5


def gene_default(k):
    lo, hi = GENE[k]
    return GENE_MISSING.get(k, (lo + hi) / 2)


def genome_from(d):
    """แปลงสูตรที่บันทึกไว้ (อาจเป็นรุ่นเก่า) เป็นสูตรครบทุกค่า"""
    g = fix_genome({k: float((d or {}).get(k, gene_default(k))) for k in GENE})
    if d and d.get("fam") is not None:
        g["fam"] = int(d["fam"])
    return g

# ตั้งค่า indicator (อ่านจาก config.toml ตอนเริ่มระบบ ผ่าน configure())
IND = {"atr_stops": True, "atr_period": 14, "htf_filter": True, "sessions": True, "vol_regime": True,
       "server_utc_offset": 2, "vol_ratio": 1.5, "tf": 1}


def TF():
    """กรอบเวลาที่บอทตัดสินใจ (นาที): บอทดูสัญญาณและเปิดออเดอร์เฉพาะตอนแท่ง TF ปิด
    ค่าในสูตร (เส้นค่าเฉลี่ย RSI เบรกเอาต์ ATR) นับเป็นแท่ง TF ส่วนการดูแลออเดอร์ (SL/TP) ยังดูทุก 1 นาที"""
    return max(1, int(IND.get("tf", 1) or 1))


def min_bars():
    """ต้องมีราคาย้อนหลังกี่แท่ง 1 นาที ถึงคำนวณสัญญาณได้ครบ"""
    return max(72, 61 * TF() + 12)


def tf_close(t, L):
    """แท่ง 1 นาทีนี้เป็นแท่งสุดท้ายของแท่ง TF ไหม (ถึงเวลาตัดสินใจเข้าออเดอร์)"""
    tf = TF()
    if tf == 1:
        return True
    if t:
        return (int(t) // 60 + 1) % tf == 0
    return L % tf == 0


def trail(g, d, entry, sl, risk, best):
    """SL ใหม่จากวิธีออกของสูตร (ขยับเข้าหาราคาเท่านั้น ไม่ถอยออก)
    best = ราคาที่ดีที่สุดตั้งแต่เข้า (ซื้อ = สูงสุดฝั่ง bid, ขาย = ต่ำสุดฝั่ง ask)"""
    new = sl
    if risk <= 0:
        return new
    be = g.get("be", 2.0)
    if be <= BE_OFF and (best - entry) * d >= be * risk and (entry - new) * d > 0:
        new = entry
    tr = g.get("trl", 0.0)
    if tr >= TRL_ON:
        t = best - d * tr * risk
        if (t - new) * d > 0:
            new = t
    return new


def configure(cfg):
    IND.update(cfg.get("indicators", {}))
    fc = cfg.get("bots", {}).get("families")
    if isinstance(fc, list) and len(fc) == len(FAMILIES) and all(isinstance(x, int) and x >= 0 for x in fc) and sum(fc) > 0:
        FAM_COUNTS[:] = fc
    from . import indicators
    indicators.SERVER_OFFSET = int(IND.get("server_utc_offset", 2))


def hold_bars(g, cap):
    """ถือไม้นานสุดกี่แท่ง 1 นาที ตามสูตร: hold 16 = เต็มเวลา max_hold_bars, 8 = ครึ่งหนึ่ง, 2 = หนึ่งในแปด"""
    return max(1, int(round(int(cap) * min(16.0, max(1.0, g.get("hold", 16.0))) / 16.0)))


def stop_keys():
    """ค่าในสูตรที่ใช้ตั้ง SL/TP ตอนนี้"""
    return ("slA", "tpA") if IND["atr_stops"] else ("sl", "tp")


def stops(g, s, L):
    """ระยะตัดขาดทุน/ทำกำไร (ดอลลาร์) ของสูตร g ณ จุด L"""
    if IND["atr_stops"]:
        tf = TF()
        atr = s.atr_at(int(IND["atr_period"]) * tf, L) * tf ** 0.5   # ATR ของแท่ง TF (ประมาณจากแท่ง 1 นาที)
        if atr > 0:
            return clamp(g["slA"] * atr, 0.5, 60.0), clamp(g["tpA"] * atr, 0.3, 80.0)
    return g["sl"], g["tp"]


def clamp(x, a, b):
    return a if x < a else b if x > b else x


def fix_genome(g):
    for k, (a, b) in GENE.items():
        g[k] = clamp(g[k], a, b)
    return g


def genome_dist(a, b):
    return sum(abs(a[k] - b[k]) / (hi - lo) for k, (lo, hi) in GENE.items())


class Bot:
    def __init__(self, i, name, rng, window):
        self.id = i
        self.name = name
        self.g = {k: rng.uniform(a, b) for k, (a, b) in GENE.items()}
        self.g["fam"] = family_of(i)
        self.today = 0.0
        self.total = 0.0
        self.trades = 0
        self.wins = 0
        self.today_trades = 0
        self.today_wins = 0
        self.live_today = 0.0
        self.live_total = 0.0
        self.live_trades = 0
        self.live_wins = 0
        self.recent = deque(maxlen=window)
        self.recent_pnl = deque(maxlen=window)   # กำไร/ขาดทุนของไม้ล่าสุด (ใช้วัดว่าได้กำไรต่อไม้จริงไหม)
        self.hist_pnl = deque(maxlen=100)        # กำไรของไม้ล่าสุดชุดยาว ใช้วัดทางสถิติว่ากำไรจริงหรือฟลุ๊ค (ข้อ 2)
        self.exam = None                         # ผลสอบล่าสุดก่อนขึ้นทีมเงินจริง (ข้อ 1 + 3)
        self.stress = 0.0        # ความเครียด 0-100 (ขึ้นเมื่อแพ้ ลดเมื่อชนะ/พัก)
        self.rest_until = None   # กำลังพักที่มุมพักผ่อนถึงแท่งนี้ (ไม่เปิดไม้ใหม่ระหว่างพัก)
        self.rests = 0
        self.generation = 0      # รุ่นของสูตร (เพิ่มเมื่อถูกแทนที่ด้วยสูตรลูกของบอทเก่ง)
        self.parents = None
        self.consec_losses = 0
        self.live = False
        self.paused = False
        self.jailed = None      # {"until": bar, "mentor": id, "reason": str}
        self.pos = None         # {"dir","entry","sl","tp","bar0","live","ticket","comps"}
        self.violations = 0
        self.chats = 0
        self.tips = 0
        self.learn_count = 0     # ปรับสูตรจากผลเทรดของตัวเองกี่ครั้ง
        self.learn_today = 0
        self.taught = 0          # ถูกสอน (คาบเรียน/เขตห้ามเทรด/สั่งสอน) กี่ครั้ง
        self.last_teacher = None
        self.g0 = dict(self.g)   # สูตรตอนเริ่ม ใช้วัดว่าสูตรเปลี่ยนไปแค่ไหน

    @property
    def fam(self):
        return family_of(self.id)

    @property
    def explorer(self):
        """บอทนักสำรวจ (ทุกตัวที่ 5): ไม่ลอกสูตรจากอาจารย์/เพื่อน/หัวแถว เรียนจากผลเทรดของตัวเองเท่านั้น
        กันไม่ให้บอททั้งหมดกลายเป็นสูตรเดียวกัน"""
        return self.id % 5 == 4

    @property
    def tag(self):
        return f"บอท {self.id + 1:02d} {self.name}"

    def recent_wr(self):
        return sum(self.recent) / len(self.recent) if self.recent else None

    def recent_exp(self):
        """กำไรเฉลี่ยต่อไม้ในไม้ล่าสุด (หลังหัก spread/ค่าคอมแล้ว)"""
        return sum(self.recent_pnl) / len(self.recent_pnl) if self.recent_pnl else None

    def t_stat(self):
        """ค่า t ของกำไรเฉลี่ยต่อไม้ = ค่าเฉลี่ย / (ส่วนเบี่ยงเบน / √จำนวนไม้)
        ยิ่งสูงยิ่งมั่นใจว่ากำไรต่อไม้เป็นบวกจริง ไม่ใช่ดวง (ประมาณ 1.3 = มั่นใจ 90%, 1.65 = 95%)"""
        x = self.hist_pnl
        n = len(x)
        if n < 3:
            return None
        m = sum(x) / n
        v = sum((a - m) ** 2 for a in x) / (n - 1)
        if v <= 1e-12:
            return 9.99 if m > 0 else (-9.99 if m < 0 else 0.0)
        return max(-9.99, min(9.99, m / (v ** 0.5 / n ** 0.5)))

    def recent_pf(self):
        """profit factor ของไม้ล่าสุด = กำไรรวม / ขาดทุนรวม (ไม่มีไม้ขาดทุน = 9.99)"""
        if not self.recent_pnl:
            return None
        g = sum(x for x in self.recent_pnl if x > 0)
        l = -sum(x for x in self.recent_pnl if x < 0)
        return round(min(9.99, g / l), 2) if l > 1e-9 else (9.99 if g > 0 else 0.0)

    def signals(self, s):
        return signal_at(self.g, s, len(s.c))


    # ---------- บันทึก/โหลดสถานะ ----------
    FIELDS = ["today", "total", "trades", "wins", "today_trades", "today_wins", "live_today", "live_total",
              "live_trades", "live_wins", "consec_losses", "live", "paused", "jailed", "pos", "violations",
              "chats", "tips", "learn_count", "learn_today", "taught", "last_teacher", "generation", "parents",
              "stress", "rest_until", "rests"]

    def change_pct(self):
        """สูตรเปลี่ยนไปจากตอนเริ่มกี่ % (เฉลี่ยทุกค่า เทียบกับช่วงที่เป็นไปได้)"""
        return 100 * genome_dist(self.g, self.g0) / len(GENE)

    def to_dict(self):
        d = {k: getattr(self, k) for k in self.FIELDS}
        d.update(id=self.id, name=self.name, g=self.g, g0=self.g0, recent=list(self.recent),
                 recent_pnl=[round(x, 2) for x in self.recent_pnl], change_pct=round(self.change_pct(), 2),
                 exp=None if self.recent_exp() is None else round(self.recent_exp(), 3), pf=self.recent_pf(),
                 hist_pnl=[round(x, 2) for x in self.hist_pnl], hist_n=len(self.hist_pnl),
                 tstat=None if self.t_stat() is None else round(self.t_stat(), 2), exam=self.exam,
                 explorer=self.explorer, fam=self.fam)
        return d

    def load_dict(self, d):
        for k in self.FIELDS:
            if k in d:
                setattr(self, k, d[k])
        self.g = genome_from(d["g"])
        self.g["fam"] = self.fam
        self.g0 = genome_from(d.get("g0", d["g"]))
        self.recent.clear()
        self.recent.extend(d.get("recent", []))
        self.recent_pnl.clear()
        self.recent_pnl.extend(d.get("recent_pnl", []))
        self.hist_pnl.clear()
        self.hist_pnl.extend(d.get("hist_pnl", d.get("recent_pnl", [])))
        self.exam = d.get("exam")


def signal_at(g, s, L):
    """คำนวณสัญญาณของสูตร g ณ จุดที่มีราคาปิด L แท่ง (ใช้ทั้งตอนเทรดและตอนอาจารย์ทดสอบย้อนหลัง)"""
    if True:
        tf = TF()
        p = s.c[L - 1]
        sd = max(0.3, s.vol_at(30 * tf, L)) * tf ** 0.5
        t = clamp((s.sma_at(round(g["fast"]) * tf, L) - s.sma_at(round(g["slow"]) * tf, L)) / (2 * sd), -1.0, 1.0)
        r = s.rsi_tf_at(round(g["rsiN"]), tf, L)
        m = 0.0
        if r < g["rsiLo"]:
            m = clamp((g["rsiLo"] - r) / 15, 0.0, 1.0)
        elif r > g["rsiHi"]:
            m = -clamp((r - g["rsiHi"]) / 15, 0.0, 1.0)
        hi, lo = s.hilo_at(round(g["brkN"]) * tf, L)
        bk = 0.0
        if p > hi:
            bk = clamp((p - hi) / sd + 0.5, 0.0, 1.0)
        elif p < lo:
            bk = -clamp((lo - p) / sd + 0.5, 0.0, 1.0)
        fam = g.get("fam")
        if fam is None:            # สูตรแบบผสม (สูตรเดิม / สูตรของอาจารย์ที่ไม่ได้ระบุสาย)
            W = g["wT"] + g["wM"] + g["wB"]
            score = (g["wT"] * t + g["wM"] * m + g["wB"] * bk) / W
        elif fam == 0:
            score = t
        elif fam == 1:
            score = m
        elif fam == 2:
            score = bk
        elif fam == 3:
            score = session_break(s, L, p, sd)
        else:
            score = burst(g, s, L, tf)
        # ตัวกรองเทรนด์ใหญ่: ราคาอยู่เหนือหรือใต้เส้นค่าเฉลี่ย N ชั่วโมง ถ้าสัญญาณสวนทาง ลดความแรงลงตาม htfW
        h = 0
        if IND["htf_filter"]:
            n = int(round(g["htfN"])) * 60
            if L > n:
                ma = s.sma_at(n, L)
                h = 1 if p > ma else -1 if p < ma else 0
                if h and score and (score > 0) != (h > 0):
                    score *= 1.0 - g["htfW"]
        ses, hv = market_ctx(s, L)
        if ses:
            score *= g[ses]
        if hv:
            score *= g["vH"]
        return t, m, bk, score, h


def session_break(s, L, p, sd):
    """สายเบรกกรอบเอเชีย: ช่วง 07-16 UTC ราคาทะลุกรอบสูง/ต่ำของช่วงเอเชีย (22-07 UTC) วันนั้น"""
    hi, lo = s.asia_at(L)
    if hi is None:
        return 0.0
    if p > hi:
        return clamp((p - hi) / sd + 0.5, 0.0, 1.0)
    if p < lo:
        return -clamp((lo - p) / sd + 0.5, 0.0, 1.0)
    return 0.0


def burst(g, s, L, tf):
    """สายตามแรงกระชาก: ราคาวิ่งในแท่ง TF ล่าสุดเกิน vk เท่าของ ATR (ของแท่ง TF) ให้ตามทิศนั้น"""
    if L <= tf + 1:
        return 0.0
    a = s.atr_at(int(IND["atr_period"]) * tf, L) * tf ** 0.5
    if a <= 0:
        return 0.0
    mv = s.c[L - 1] - s.c[L - 1 - tf]
    x = abs(mv) / a
    if x < g.get("vk", 2.0):
        return 0.0
    v = clamp((x - g["vk"]) / g["vk"] + 0.5, 0.0, 1.0)
    return v if mv > 0 else -v


def session_key(t):
    """ช่วงตลาดจากเวลาแท่งราคา (เวลาเซิร์ฟเวอร์ MT5 แปลงเป็น UTC ด้วย server_utc_offset)"""
    hu = (int(t) // 3600 - int(IND["server_utc_offset"])) % 24
    return "sE" if 7 <= hu < 13 else "sU" if 13 <= hu < 22 else "sA"


def market_ctx(s, L):
    """(ช่วงตลาด, ตลาดผันผวนแรงไหม) ณ จุด L"""
    ses = None
    if IND["sessions"] and len(s.t) >= L and s.t[L - 1]:
        ses = session_key(s.t[L - 1])
    hv = False
    if IND["vol_regime"] and L > 240:
        a, A = s.atr_at(int(IND["atr_period"]) * TF(), L), s.atr_at(1440, L)
        hv = A > 0 and a > IND["vol_ratio"] * A
    return ses, hv

