from collections import deque

NAMES = ["ทองคำ", "ทองแท้", "ทองดี", "ทองมา", "ทองเต็ม", "ทองพูน", "ทองล้น", "ทองหยิบ", "ทองเอก", "ทองทวี",
         "เฮง", "ปัง", "รวย", "มั่งมี", "ร่ำ", "ลาภ", "โชค", "มณี", "เพชร", "นพเก้า",
         "ขึ้น", "พุ่ง", "ทะยาน", "ไฮ", "บูม", "ฟ้า", "เทียน", "กรีน", "ท็อป", "วิน",
         "แม่น", "นิ่ง", "ชัวร์", "คม", "ไว", "เป๊ะ", "เฉียบ", "ปราชญ์", "ตาทิพย์", "ใจเย็น",
         "โกลดี้", "ออรัม", "ไมดาส", "บูลลี่", "แพลตตินัม", "ลัคกี้", "ริชชี่", "โกลด์ฟินช์", "โซล", "แจ็คพอต",
         "มงคล", "ศรี", "สุข", "เจริญ", "รุ่ง", "เรือง", "ทรัพย์", "มั่นคง", "พูนผล", "อุดม",
         "ดาว", "เดือน", "ตะวัน", "รุ้ง", "สายฟ้า", "พายุ", "ฟีนิกซ์", "มังกร", "สิงห์", "อินทรี",
         "เสือ", "ม้าทอง", "หงส์", "กิเลน", "นาคา", "ไพลิน", "ทับทิม", "มรกต", "บุษราคัม", "โกเมน",
         "ไข่มุก", "อำพัน", "หยก", "เงินยวง", "นาก", "ทองเหลือง", "ทองชมพู", "ทองขาว", "ทองทราย", "ทองฟ้า",
         "เทรนดี้", "ชาร์ต", "แท่งเทียน", "ซิกม่า", "อัลฟ่า", "เบต้า", "เดลต้า", "โอเมก้า", "แมคดี", "ฟีโบ"]

# ช่วงค่าของ "สูตร" แต่ละตัว  (sl / tp เป็นระยะราคาหน่วยดอลลาร์)
GENE = {
    "wT": (0.05, 1.5),    # น้ำหนักสัญญาณตามเทรนด์ (เส้นค่าเฉลี่ยเร็ว/ช้า)
    "wM": (0.05, 1.5),    # น้ำหนักสัญญาณสวนกลับ (RSI)
    "wB": (0.05, 1.5),    # น้ำหนักสัญญาณเบรกเอาต์
    "fast": (3, 15),
    "slow": (16, 60),
    "rsiN": (6, 20),
    "rsiLo": (18, 42),
    "rsiHi": (58, 82),
    "brkN": (10, 50),
    "sl": (2.0, 25.0),
    "tp": (1.5, 40.0),
    "thr": (0.2, 0.75),   # เกณฑ์ความแรงสัญญาณขั้นต่ำ
    "lr": (0.02, 0.15),   # อัตราการเรียนรู้
    "slA": (0.8, 8.0),    # ตัดขาดทุนกี่เท่าของ ATR (ใช้เมื่อเปิด atr_stops)
    "tpA": (0.4, 10.0),   # ทำกำไรกี่เท่าของ ATR (ใช้เมื่อเปิด atr_stops)
    "htfN": (4, 48),      # เส้นค่าเฉลี่ยเทรนด์ใหญ่กี่ชั่วโมง (ใช้เมื่อเปิด htf_filter)
    "htfW": (0.0, 1.0),   # เคารพเทรนด์ใหญ่แค่ไหน 0 = ไม่สนใจ, 1 = ห้ามเทรดสวนเทรนด์ใหญ่เด็ดขาด
    # รู้จักสภาพตลาด: น้ำหนักสัญญาณตามช่วงเวลาตลาด และตอนตลาดผันผวนแรง (1 = เทรดเต็มที่, 0 = ไม่เทรดช่วงนั้น)
    "sA": (0.0, 1.0),     # ช่วงตลาดเอเชีย (22:00-07:00 UTC)
    "sE": (0.0, 1.0),     # ช่วงตลาดยุโรป (07:00-13:00 UTC)
    "sU": (0.0, 1.0),     # ช่วงตลาดสหรัฐ (13:00-22:00 UTC)
    "vH": (0.0, 1.0),     # ตอนตลาดผันผวนแรง (ATR สั้นสูงกว่าค่าเฉลี่ยทั้งวันเกิน 1.5 เท่า)
}
# ค่าที่ใช้เมื่อสูตรเก่า (ก่อนมีค่านี้) ไม่มีค่านั้น ให้ทำงานเหมือนเดิม
GENE_MISSING = {"sA": 1.0, "sE": 1.0, "sU": 1.0, "vH": 1.0}


def gene_default(k):
    lo, hi = GENE[k]
    return GENE_MISSING.get(k, (lo + hi) / 2)


def genome_from(d):
    """แปลงสูตรที่บันทึกไว้ (อาจเป็นรุ่นเก่า) เป็นสูตรครบทุกค่า"""
    return fix_genome({k: float((d or {}).get(k, gene_default(k))) for k in GENE})

# ตั้งค่า indicator (อ่านจาก config.toml ตอนเริ่มระบบ ผ่าน configure())
IND = {"atr_stops": True, "atr_period": 14, "htf_filter": True, "sessions": True, "vol_regime": True,
       "server_utc_offset": 2, "vol_ratio": 1.5}


def configure(cfg):
    IND.update(cfg.get("indicators", {}))


def stop_keys():
    """ค่าในสูตรที่ใช้ตั้ง SL/TP ตอนนี้"""
    return ("slA", "tpA") if IND["atr_stops"] else ("sl", "tp")


def stops(g, s, L):
    """ระยะตัดขาดทุน/ทำกำไร (ดอลลาร์) ของสูตร g ณ จุด L"""
    if IND["atr_stops"]:
        atr = s.atr_at(int(IND["atr_period"]), L)
        if atr > 0:
            return clamp(g["slA"] * atr, 0.5, 60.0), clamp(g["tpA"] * atr, 0.3, 80.0)
    return g["sl"], g["tp"]


def clamp(x, a, b):
    return a if x < a else b if x > b else x


def fix_genome(g):
    for k, (a, b) in GENE.items():
        g[k] = clamp(g[k], a, b)
    return g


def genome_dist(a, b):
    return sum(abs(a[k] - b[k]) / (hi - lo) for k, (lo, hi) in GENE.items())


class Bot:
    def __init__(self, i, name, rng, window):
        self.id = i
        self.name = name
        self.g = {k: rng.uniform(a, b) for k, (a, b) in GENE.items()}
        self.today = 0.0
        self.total = 0.0
        self.trades = 0
        self.wins = 0
        self.today_trades = 0
        self.today_wins = 0
        self.live_today = 0.0
        self.live_total = 0.0
        self.live_trades = 0
        self.live_wins = 0
        self.recent = deque(maxlen=window)
        self.recent_pnl = deque(maxlen=window)   # กำไร/ขาดทุนของไม้ล่าสุด (ใช้วัดว่าได้กำไรต่อไม้จริงไหม)
        self.stress = 0.0        # ความเครียด 0-100 (ขึ้นเมื่อแพ้ ลดเมื่อชนะ/พัก)
        self.rest_until = None   # กำลังพักที่มุมพักผ่อนถึงแท่งนี้ (ไม่เปิดไม้ใหม่ระหว่างพัก)
        self.rests = 0
        self.generation = 0      # รุ่นของสูตร (เพิ่มเมื่อถูกแทนที่ด้วยสูตรลูกของบอทเก่ง)
        self.parents = None
        self.consec_losses = 0
        self.live = False
        self.paused = False
        self.jailed = None      # {"until": bar, "mentor": id, "reason": str}
        self.pos = None         # {"dir","entry","sl","tp","bar0","live","ticket","comps"}
        self.violations = 0
        self.chats = 0
        self.tips = 0
        self.learn_count = 0     # ปรับสูตรจากผลเทรดของตัวเองกี่ครั้ง
        self.learn_today = 0
        self.taught = 0          # ถูกสอน (คาบเรียน/เขตห้ามเทรด/สั่งสอน) กี่ครั้ง
        self.last_teacher = None
        self.g0 = dict(self.g)   # สูตรตอนเริ่ม ใช้วัดว่าสูตรเปลี่ยนไปแค่ไหน

    @property
    def tag(self):
        return f"บอท {self.id + 1:02d} {self.name}"

    def recent_wr(self):
        return sum(self.recent) / len(self.recent) if self.recent else None

    def recent_exp(self):
        """กำไรเฉลี่ยต่อไม้ในไม้ล่าสุด (หลังหัก spread/ค่าคอมแล้ว)"""
        return sum(self.recent_pnl) / len(self.recent_pnl) if self.recent_pnl else None

    def recent_pf(self):
        """profit factor ของไม้ล่าสุด = กำไรรวม / ขาดทุนรวม (ไม่มีไม้ขาดทุน = 9.99)"""
        if not self.recent_pnl:
            return None
        g = sum(x for x in self.recent_pnl if x > 0)
        l = -sum(x for x in self.recent_pnl if x < 0)
        return round(min(9.99, g / l), 2) if l > 1e-9 else (9.99 if g > 0 else 0.0)

    def signals(self, s):
        return signal_at(self.g, s, len(s.c))


    # ---------- บันทึก/โหลดสถานะ ----------
    FIELDS = ["today", "total", "trades", "wins", "today_trades", "today_wins", "live_today", "live_total",
              "live_trades", "live_wins", "consec_losses", "live", "paused", "jailed", "pos", "violations",
              "chats", "tips", "learn_count", "learn_today", "taught", "last_teacher", "generation", "parents",
              "stress", "rest_until", "rests"]

    def change_pct(self):
        """สูตรเปลี่ยนไปจากตอนเริ่มกี่ % (เฉลี่ยทุกค่า เทียบกับช่วงที่เป็นไปได้)"""
        return 100 * genome_dist(self.g, self.g0) / len(GENE)

    def to_dict(self):
        d = {k: getattr(self, k) for k in self.FIELDS}
        d.update(id=self.id, name=self.name, g=self.g, g0=self.g0, recent=list(self.recent),
                 recent_pnl=[round(x, 2) for x in self.recent_pnl], change_pct=round(self.change_pct(), 2),
                 exp=None if self.recent_exp() is None else round(self.recent_exp(), 3), pf=self.recent_pf())
        return d

    def load_dict(self, d):
        for k in self.FIELDS:
            if k in d:
                setattr(self, k, d[k])
        self.g = genome_from(d["g"])
        self.g0 = genome_from(d.get("g0", d["g"]))
        self.recent.clear()
        self.recent.extend(d.get("recent", []))
        self.recent_pnl.clear()
        self.recent_pnl.extend(d.get("recent_pnl", []))


def signal_at(g, s, L):
    """คำนวณสัญญาณของสูตร g ณ จุดที่มีราคาปิด L แท่ง (ใช้ทั้งตอนเทรดและตอนอาจารย์ทดสอบย้อนหลัง)"""
    if True:
        p = s.c[L - 1]
        sd = max(0.3, s.vol_at(30, L))
        t = clamp((s.sma_at(round(g["fast"]), L) - s.sma_at(round(g["slow"]), L)) / (2 * sd), -1.0, 1.0)
        r = s.rsi_at(round(g["rsiN"]), L)
        m = 0.0
        if r < g["rsiLo"]:
            m = clamp((g["rsiLo"] - r) / 15, 0.0, 1.0)
        elif r > g["rsiHi"]:
            m = -clamp((r - g["rsiHi"]) / 15, 0.0, 1.0)
        hi, lo = s.hilo_at(round(g["brkN"]), L)
        bk = 0.0
        if p > hi:
            bk = clamp((p - hi) / sd + 0.5, 0.0, 1.0)
        elif p < lo:
            bk = -clamp((lo - p) / sd + 0.5, 0.0, 1.0)
        W = g["wT"] + g["wM"] + g["wB"]
        score = (g["wT"] * t + g["wM"] * m + g["wB"] * bk) / W
        # ตัวกรองเทรนด์ใหญ่: ราคาอยู่เหนือหรือใต้เส้นค่าเฉลี่ย N ชั่วโมง ถ้าสัญญาณสวนทาง ลดความแรงลงตาม htfW
        h = 0
        if IND["htf_filter"]:
            n = int(round(g["htfN"])) * 60
            if L > n:
                ma = s.sma_at(n, L)
                h = 1 if p > ma else -1 if p < ma else 0
                if h and score and (score > 0) != (h > 0):
                    score *= 1.0 - g["htfW"]
        ses, hv = market_ctx(s, L)
        if ses:
            score *= g[ses]
        if hv:
            score *= g["vH"]
        return t, m, bk, score, h


def session_key(t):
    """ช่วงตลาดจากเวลาแท่งราคา (เวลาเซิร์ฟเวอร์ MT5 แปลงเป็น UTC ด้วย server_utc_offset)"""
    hu = (int(t) // 3600 - int(IND["server_utc_offset"])) % 24
    return "sE" if 7 <= hu < 13 else "sU" if 13 <= hu < 22 else "sA"


def market_ctx(s, L):
    """(ช่วงตลาด, ตลาดผันผวนแรงไหม) ณ จุด L"""
    ses = None
    if IND["sessions"] and len(s.t) >= L and s.t[L - 1]:
        ses = session_key(s.t[L - 1])
    hv = False
    if IND["vol_regime"] and L > 240:
        a, A = s.atr_at(int(IND["atr_period"]), L), s.atr_at(1440, L)
        hv = A > 0 and a > IND["vol_ratio"] * A
    return ses, hv

