from collections import deque

NAMES = ["ทองแท้", "สิงห์", "มังกร", "พยัคฆ์", "เหยี่ยว", "กระทิง", "หมีขาว", "จิ้งจอก", "นกฮูก", "ฉลาม",
         "ม้าเร็ว", "แมวดำ", "กระต่าย", "ช้างศึก", "อินทรี", "งูเห่า", "ปลาวาฬ", "ผึ้งงาน", "หมาป่า", "เต่าทอง"]

# ช่วงค่าของ "สูตร" แต่ละตัว  (sl / tp เป็นระยะราคาหน่วยดอลลาร์)
GENE = {
    "wT": (0.05, 1.5),    # น้ำหนักสัญญาณตามเทรนด์ (เส้นค่าเฉลี่ยเร็ว/ช้า)
    "wM": (0.05, 1.5),    # น้ำหนักสัญญาณสวนกลับ (RSI)
    "wB": (0.05, 1.5),    # น้ำหนักสัญญาณเบรกเอาต์
    "fast": (3, 15),
    "slow": (16, 60),
    "rsiN": (6, 20),
    "rsiLo": (18, 42),
    "rsiHi": (58, 82),
    "brkN": (10, 50),
    "sl": (2.0, 25.0),
    "tp": (1.5, 40.0),
    "thr": (0.2, 0.75),   # เกณฑ์ความแรงสัญญาณขั้นต่ำ
    "lr": (0.02, 0.15),   # อัตราการเรียนรู้
}


def clamp(x, a, b):
    return a if x < a else b if x > b else x


def fix_genome(g):
    for k, (a, b) in GENE.items():
        g[k] = clamp(g[k], a, b)
    return g


def genome_dist(a, b):
    return sum(abs(a[k] - b[k]) / (hi - lo) for k, (lo, hi) in GENE.items())


class Bot:
    def __init__(self, i, name, rng, window):
        self.id = i
        self.name = name
        self.g = {k: rng.uniform(a, b) for k, (a, b) in GENE.items()}
        self.today = 0.0
        self.total = 0.0
        self.trades = 0
        self.wins = 0
        self.today_trades = 0
        self.today_wins = 0
        self.live_today = 0.0
        self.live_total = 0.0
        self.live_trades = 0
        self.live_wins = 0
        self.recent = deque(maxlen=window)
        self.consec_losses = 0
        self.live = False
        self.paused = False
        self.jailed = None      # {"until": bar, "mentor": id, "reason": str}
        self.pos = None         # {"dir","entry","sl","tp","bar0","live","ticket","comps"}
        self.violations = 0
        self.chats = 0
        self.tips = 0

    @property
    def tag(self):
        return f"บอท {self.id + 1:02d} {self.name}"

    def recent_wr(self):
        return sum(self.recent) / len(self.recent) if self.recent else None

    def signals(self, s):
        g = self.g
        p = s.c[-1]
        sd = max(0.3, s.vol(30))
        t = clamp((s.sma(round(g["fast"])) - s.sma(round(g["slow"]))) / (2 * sd), -1.0, 1.0)
        r = s.rsi(round(g["rsiN"]))
        m = 0.0
        if r < g["rsiLo"]:
            m = clamp((g["rsiLo"] - r) / 15, 0.0, 1.0)
        elif r > g["rsiHi"]:
            m = -clamp((r - g["rsiHi"]) / 15, 0.0, 1.0)
        hi, lo = s.hilo(round(g["brkN"]))
        bk = 0.0
        if p > hi:
            bk = clamp((p - hi) / sd + 0.5, 0.0, 1.0)
        elif p < lo:
            bk = -clamp((lo - p) / sd + 0.5, 0.0, 1.0)
        W = g["wT"] + g["wM"] + g["wB"]
        score = (g["wT"] * t + g["wM"] * m + g["wB"] * bk) / W
        return t, m, bk, score

    # ---------- บันทึก/โหลดสถานะ ----------
    FIELDS = ["today", "total", "trades", "wins", "today_trades", "today_wins", "live_today", "live_total",
              "live_trades", "live_wins", "consec_losses", "live", "paused", "jailed", "pos", "violations",
              "chats", "tips"]

    def to_dict(self):
        d = {k: getattr(self, k) for k in self.FIELDS}
        d.update(id=self.id, name=self.name, g=self.g, recent=list(self.recent))
        return d

    def load_dict(self, d):
        for k in self.FIELDS:
            if k in d:
                setattr(self, k, d[k])
        self.g = fix_genome({k: float(d["g"].get(k, self.g[k])) for k in GENE})
        self.recent.clear()
        self.recent.extend(d.get("recent", []))
