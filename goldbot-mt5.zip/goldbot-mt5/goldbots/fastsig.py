"""คำนวณสัญญาณของสูตรทั้งช่วงเวลาในครั้งเดียวด้วย numpy (ผลเหมือน signal_at / stops ทุกจุด)
ใช้ตอนครูทดสอบสูตรย้อนหลัง ซึ่งต้องทดสอบหลายร้อยสูตรกับราคาชุดเดียวกัน"""
import numpy as np

from .bots import IND

BACK = 48 * 60 + 80   # ราคาย้อนหลังที่ต้องมี (เทรนด์ใหญ่ยาวสุด 48 ชั่วโมง)


class Window:
    """ข้อมูลราคาของช่วงทดสอบ เตรียมครั้งเดียว ใช้ทดสอบได้หลายสูตร"""

    def __init__(self, s, bars, L0):
        self.bars = bars
        self.n = len(bars)
        self.L = np.arange(L0 + 1, L0 + self.n + 1)          # จำนวนราคาปิด ณ แต่ละแท่ง
        self.base = max(0, L0 + 1 - BACK)
        end = L0 + self.n
        b = self.base
        self.cs = np.asarray(s._cs[b:end + 1], dtype=float)
        self.G = np.asarray(s._g[b:end + 1], dtype=float)
        self.Lo = np.asarray(s._l[b:end + 1], dtype=float)
        self.d = np.asarray(s._d[b:end + 1], dtype=float)
        self.d2 = np.asarray(s._d2[b:end + 1], dtype=float)
        self.tr = np.asarray(s._tr[b:end + 1], dtype=float)
        self.c = np.asarray(s.c[b:end], dtype=float)
        self.i = self.L - b                                    # ตำแหน่งในอาเรย์สะสม
        self.p = self.c[self.i - 1]
        m = (self.d[self.i] - self.d[self._back(30)]) / 30
        v = (self.d2[self.i] - self.d2[self._back(30)]) / 30 - m * m
        self.sd = np.maximum(0.3, np.sqrt(np.where(v > 0, v, 0.0)))
        an = np.minimum(int(IND["atr_period"]), self.L - 1)
        self.atr = np.where(an > 0, (self.tr[self.i] - self.tr[np.maximum(self.i - an, 0)]) / np.maximum(an, 1), 0.0)
        self._cache = {}

    def _back(self, n):
        return np.maximum(self.i - n, 0)

    def sma(self, n):
        k = ("sma", n)
        if k not in self._cache:
            self._cache[k] = (self.cs[self.i] - self.cs[self._back(n)]) / n
        return self._cache[k]

    def rsi(self, n):
        k = ("rsi", n)
        if k not in self._cache:
            g = self.G[self.i] - self.G[self._back(n)]
            l = self.Lo[self.i] - self.Lo[self._back(n)]
            with np.errstate(divide="ignore", invalid="ignore"):
                r = 100.0 - 100.0 / (1.0 + g / l)
            self._cache[k] = np.where(l <= 1e-12, 100.0, r)
        return self._cache[k]

    def hilo(self, n):
        """สูงสุด/ต่ำสุดของ n แท่งก่อนหน้า (ไม่รวมแท่งปัจจุบัน)"""
        k = ("hilo", n)
        if k not in self._cache:
            w = np.lib.stride_tricks.sliding_window_view(self.c, n)
            st = np.maximum(self.i - 1 - n, 0)
            self._cache[k] = (w.max(axis=1)[st], w.min(axis=1)[st])
        return self._cache[k]


def scores_and_stops(g, W):
    """คืนค่า (ความแรงสัญญาณ, ระยะ SL, ระยะ TP) ของทุกแท่งในช่วงทดสอบ"""
    p, sd = W.p, W.sd
    t = np.clip((W.sma(int(round(g["fast"]))) - W.sma(int(round(g["slow"])))) / (2 * sd), -1.0, 1.0)
    r = W.rsi(int(round(g["rsiN"])))
    m = np.where(r < g["rsiLo"], np.clip((g["rsiLo"] - r) / 15, 0.0, 1.0),
                 np.where(r > g["rsiHi"], -np.clip((r - g["rsiHi"]) / 15, 0.0, 1.0), 0.0))
    hi, lo = W.hilo(int(round(g["brkN"])))
    bk = np.where(p > hi, np.clip((p - hi) / sd + 0.5, 0.0, 1.0),
                  np.where(p < lo, -np.clip((lo - p) / sd + 0.5, 0.0, 1.0), 0.0))
    Wt = g["wT"] + g["wM"] + g["wB"]
    score = (g["wT"] * t + g["wM"] * m + g["wB"] * bk) / Wt
    if IND["htf_filter"]:
        n = int(round(g["htfN"])) * 60
        ma = W.sma(n)
        h = np.where(W.L > n, np.sign(p - ma), 0.0)
        against = (h != 0) & (score != 0) & ((score > 0) != (h > 0))
        score = np.where(against, score * (1.0 - g["htfW"]), score)
    if IND["atr_stops"]:
        ok = W.atr > 0
        sl = np.where(ok, np.clip(g["slA"] * W.atr, 0.5, 60.0), g["sl"])
        tp = np.where(ok, np.clip(g["tpA"] * W.atr, 0.3, 80.0), g["tp"])
    else:
        sl = np.full(W.n, g["sl"])
        tp = np.full(W.n, g["tp"])
    return score, sl, tp
