"""คำนวณสัญญาณของสูตรทั้งช่วงเวลาในครั้งเดียวด้วย numpy (ผลเหมือน signal_at / stops ทุกจุด)
ใช้ตอนอาจารย์ทดสอบสูตรย้อนหลัง ซึ่งต้องทดสอบหลายร้อยสูตรกับราคาชุดเดียวกัน"""
import numpy as np

from .bots import IND, TF

BACK = 48 * 60 + 80   # ราคาย้อนหลังที่ต้องมี (เทรนด์ใหญ่ยาวสุด 48 ชั่วโมง)


def _roll(a, w, op):
    """ค่าสูงสุด/ต่ำสุดของทุกช่วงยาว w ติดกัน (ผลเท่ากับ sliding_window_view(a, w).max(axis=1) แต่เร็วกว่ามากเมื่อ w ยาว)"""
    n = len(a)
    if w <= 1:
        return a[:n - w + 1].copy()
    m = -(-n // w) * w
    fill = -np.inf if op is np.maximum else np.inf
    b = np.full(m, fill)
    b[:n] = a
    blk = b.reshape(-1, w)
    pre = op.accumulate(blk, axis=1).ravel()
    suf = op.accumulate(blk[:, ::-1], axis=1)[:, ::-1].ravel()
    return op(suf[:n - w + 1], pre[w - 1:n])


class Window:
    """ข้อมูลราคาของช่วงทดสอบ เตรียมครั้งเดียว ใช้ทดสอบได้หลายสูตร"""

    def __init__(self, s, bars, L0):
        self.bars = bars
        self.n = len(bars)
        self.L = np.arange(L0 + 1, L0 + self.n + 1)          # จำนวนราคาปิด ณ แต่ละแท่ง
        self.base = max(0, L0 + 1 - max(BACK, 61 * TF() + 80))
        end = L0 + self.n
        b = self.base
        self.cs = np.asarray(s._cs[b:end + 1], dtype=float)
        self.G = np.asarray(s._g[b:end + 1], dtype=float)
        self.Lo = np.asarray(s._l[b:end + 1], dtype=float)
        self.d = np.asarray(s._d[b:end + 1], dtype=float)
        self.d2 = np.asarray(s._d2[b:end + 1], dtype=float)
        self.tr = np.asarray(s._tr[b:end + 1], dtype=float)
        self.c = np.asarray(s.c[b:end], dtype=float)
        self.i = self.L - b                                    # ตำแหน่งในอาเรย์สะสม
        self.p = self.c[self.i - 1]
        tf = TF()
        self.tf = tf
        nv = 30 * tf
        m = (self.d[self.i] - self.d[self._back(nv)]) / nv
        v = (self.d2[self.i] - self.d2[self._back(nv)]) / nv - m * m
        self.sd = np.maximum(0.3, np.sqrt(np.where(v > 0, v, 0.0))) * tf ** 0.5
        an = np.minimum(int(IND["atr_period"]) * tf, self.L - 1)
        self.atr = np.where(an > 0, (self.tr[self.i] - self.tr[np.maximum(self.i - an, 0)]) / np.maximum(an, 1), 0.0)
        # สภาพตลาด: ช่วงตลาด (0 = เอเชีย, 1 = ยุโรป, 2 = สหรัฐ) และตลาดผันผวนแรง ให้ตรงกับ bots.market_ctx
        tt = np.array([int(getattr(b, "time", 0) or 0) for b in bars], dtype=np.int64)
        hu = (tt // 3600 - int(IND["server_utc_offset"])) % 24
        self.ses = np.where((hu >= 7) & (hu < 13), 1, np.where((hu >= 13) & (hu < 22), 2, 0))
        self.has_t = tt > 0
        anL = np.minimum(1440, self.L - 1)
        atrL = np.where(anL > 0, (self.tr[self.i] - self.tr[np.maximum(self.i - anL, 0)]) / np.maximum(anL, 1), 0.0)
        self.hv = (self.L > 240) & (atrL > 0) & (self.atr > IND["vol_ratio"] * atrL)
        self.atr_s = self.atr * tf ** 0.5          # ATR ของแท่ง TF ใช้ตั้ง SL/TP
        self.ahi = np.asarray(s._ahi[b:end], dtype=float)[self.i - 1]     # กรอบช่วงเอเชีย (nan = ใช้ไม่ได้)
        self.alo = np.asarray(s._alo[b:end], dtype=float)[self.i - 1]
        self.mv = self.c[self.i - 1] - self.c[np.maximum(self.i - 1 - tf, 0)]   # ราคาวิ่งในแท่ง TF ล่าสุด
        self.hu = np.where(self.has_t, hu, 99)                                # ชั่วโมง UTC (99 = ไม่ทราบ)
        # แท่งที่เป็นจุดปิดของแท่ง TF (บอทตัดสินใจเข้าออเดอร์เฉพาะจุดนี้) ให้ตรงกับ bots.tf_close
        if tf == 1:
            self.gate = np.ones(self.n, dtype=bool)
        else:
            self.gate = np.where(self.has_t, ((tt // 60 + 1) % tf) == 0, (self.L % tf) == 0)
        self._cache = {}

    def _back(self, n):
        return np.maximum(self.i - n, 0)

    def sma(self, n):
        k = ("sma", n)
        if k not in self._cache:
            self._cache[k] = (self.cs[self.i] - self.cs[self._back(n)]) / n
        return self._cache[k]

    def rsi(self, n):
        k = ("rsi", n)
        if k not in self._cache:
            g = self.G[self.i] - self.G[self._back(n)]
            l = self.Lo[self.i] - self.Lo[self._back(n)]
            with np.errstate(divide="ignore", invalid="ignore"):
                r = 100.0 - 100.0 / (1.0 + g / l)
            self._cache[k] = np.where(l <= 1e-12, 100.0, r)
        return self._cache[k]

    def rsi_tf(self, n):
        """RSI จากการเปลี่ยนแปลงของแท่ง TF ให้ตรงกับ Series.rsi_tf_at"""
        tf = self.tf
        if tf == 1:
            return self.rsi(n)
        k = ("rsitf", n)
        if k not in self._cache:
            c = self.c
            N = len(c)
            D = np.zeros(N)
            D[tf:] = c[tf:] - c[:-tf]
            G, Lo = np.maximum(D, 0.0), np.maximum(-D, 0.0)
            CG, CL = np.zeros(N), np.zeros(N)
            for r in range(tf):                       # ผลรวมสะสมแยกตามเศษ (ทุก tf แท่ง)
                CG[r::tf] = np.cumsum(G[r::tf])
                CL[r::tf] = np.cumsum(Lo[r::tf])
            x = self.i - 1
            y = x - n * tf
            # ถ้าย้อนไม่ถึง n แท่ง ใช้เท่าที่มี (ตำแหน่ง < tf ไม่มีการเปลี่ยนแปลง)
            g = CG[x] - np.where(y >= 0, CG[np.maximum(y, 0)], 0.0)
            l = CL[x] - np.where(y >= 0, CL[np.maximum(y, 0)], 0.0)
            with np.errstate(divide="ignore", invalid="ignore"):
                rr = 100.0 - 100.0 / (1.0 + g / l)
            self._cache[k] = np.where(l <= 1e-12, 100.0, rr)
        return self._cache[k]

    def hilo(self, n):
        """สูงสุด/ต่ำสุดของ n แท่งก่อนหน้า (ไม่รวมแท่งปัจจุบัน)"""
        k = ("hilo", n)
        if k not in self._cache:
            if n >= len(self.c):            # ราคาย้อนหลังยังไม่พอ (จุดเหล่านี้ไม่ถูกใช้เปิดออเดอร์อยู่แล้ว)
                self._cache[k] = (np.full(self.n, np.inf), np.full(self.n, -np.inf))
            else:
                st = np.minimum(np.maximum(self.i - 1 - n, 0), len(self.c) - n)
                self._cache[k] = (_roll(self.c, n, np.maximum)[st], _roll(self.c, n, np.minimum)[st])
        return self._cache[k]


def scores_and_stops(g, W):
    """คืนค่า (ความแรงสัญญาณ, ระยะ SL, ระยะ TP) ของทุกแท่งในช่วงทดสอบ"""
    p, sd, tf = W.p, W.sd, W.tf
    t = np.clip((W.sma(int(round(g["fast"])) * tf) - W.sma(int(round(g["slow"])) * tf)) / (2 * sd), -1.0, 1.0)
    r = W.rsi_tf(int(round(g["rsiN"])))
    m = np.where(r < g["rsiLo"], np.clip((g["rsiLo"] - r) / 15, 0.0, 1.0),
                 np.where(r > g["rsiHi"], -np.clip((r - g["rsiHi"]) / 15, 0.0, 1.0), 0.0))
    hi, lo = W.hilo(int(round(g["brkN"])) * tf)
    bk = np.where(p > hi, np.clip((p - hi) / sd + 0.5, 0.0, 1.0),
                  np.where(p < lo, -np.clip((lo - p) / sd + 0.5, 0.0, 1.0), 0.0))
    fam = g.get("fam")
    if fam is None:
        Wt = g["wT"] + g["wM"] + g["wB"]
        score = (g["wT"] * t + g["wM"] * m + g["wB"] * bk) / Wt
    elif fam == 0:
        score = t
    elif fam == 1:
        score = m
    elif fam == 2:
        score = bk
    elif fam == 3:
        ok = ~np.isnan(W.ahi)
        with np.errstate(invalid="ignore"):
            ok = ok & ~((W.hu != 99) & (W.hu >= 7 + g.get("swin", 9.0)))
            ok = ok & ~((W.atr_s > 0) & ((W.ahi - W.alo) > g.get("rmax", 10.0) * W.atr_s))
        hi = np.where(ok, W.ahi, np.inf)
        lo = np.where(ok, W.alo, -np.inf)
        with np.errstate(invalid="ignore"):
            score = np.where(p > hi, np.clip((p - hi) / sd + 0.5, 0.0, 1.0),
                             np.where(p < lo, -np.clip((lo - p) / sd + 0.5, 0.0, 1.0), 0.0))
    else:
        a = W.atr_s
        with np.errstate(divide="ignore", invalid="ignore"):
            x = np.where(a > 0, np.abs(W.mv) / np.where(a > 0, a, 1.0), 0.0)
        vk = g.get("vk", 2.0)
        v = np.where((x >= vk) & (W.L > tf + 1) & (a > 0), np.clip((x - vk) / vk + 0.5, 0.0, 1.0), 0.0)
        score = np.where(W.mv > 0, v, -v)
    if IND["htf_filter"]:
        n = int(round(g["htfN"])) * 60
        ma = W.sma(n)
        h = np.where(W.L > n, np.sign(p - ma), 0.0)
        against = (h != 0) & (score != 0) & ((score > 0) != (h > 0))
        score = np.where(against, score * (1.0 - g["htfW"]), score)
    if IND["sessions"]:
        w = np.where(W.ses == 1, g["sE"], np.where(W.ses == 2, g["sU"], g["sA"]))
        score = np.where(W.has_t, score * w, score)
    if IND["vol_regime"]:
        score = np.where(W.hv, score * g["vH"], score)
    if IND["atr_stops"]:
        ok = W.atr_s > 0
        sl = np.where(ok, np.clip(g["slA"] * W.atr_s, 0.5, 60.0), g["sl"])
        if g.get("fam") == 3 and g.get("smid", 0.0) > 0.5:
            rok = ok & ~np.isnan(W.ahi)
            mid = np.where(rok, (np.nan_to_num(W.ahi) + np.nan_to_num(W.alo)) / 2, 0.0)
            sl = np.where(rok, np.clip(np.abs(W.p - mid), 0.5, 60.0), sl)
        tp = np.where(ok, np.clip(g["tpA"] * W.atr_s, 0.3, 80.0), g["tp"])
    else:
        sl = np.full(W.n, g["sl"])
        tp = np.full(W.n, g["tp"])
    return score, sl, tp
