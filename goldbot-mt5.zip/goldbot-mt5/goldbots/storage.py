import csv
import json
import os


class Storage:
    def __init__(self, folder):
        self.folder = folder
        os.makedirs(folder, exist_ok=True)
        self.p_state = os.path.join(folder, "state.json")
        self.p_trades = os.path.join(folder, "trades.csv")
        self.p_days = os.path.join(folder, "days.csv")
        self.p_strat = os.path.join(folder, "strategies.json")

    def _append_csv(self, path, row):
        new = not os.path.exists(path)
        with open(path, "a", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=list(row.keys()))
            if new:
                w.writeheader()
            w.writerow(row)

    def log_trade(self, row):
        self._append_csv(self.p_trades, row)

    def log_day(self, row):
        self._append_csv(self.p_days, row)

    def save_state(self, state):
        tmp = self.p_state + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
        os.replace(tmp, self.p_state)

    def load_state(self):
        if not os.path.exists(self.p_state):
            return None
        with open(self.p_state, encoding="utf-8") as f:
            return json.load(f)

    def load_strategies(self):
        if not os.path.exists(self.p_strat):
            return []
        with open(self.p_strat, encoding="utf-8") as f:
            return json.load(f)

    def save_strategy(self, doc):
        items = self.load_strategies()
        items.append(doc)
        with open(self.p_strat, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=1)
