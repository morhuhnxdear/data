import copy
import tomllib

DEFAULTS = {
    "account": {"login": 0, "password": "", "server": "", "terminal_path": ""},
    "market": {"symbol": "XAUUSD", "contract_size": 100, "point": 0.01, "default_spread": 0.25,
               "commission_per_lot": 0.0, "deviation": 30},
    "bots": {"count": 20, "lot": 0.01, "max_lot": 0.01, "magic_base": 770000, "seed": 42},
    "team": {"size": 4, "min_win_rate": 80, "recent_window": 20, "min_trades": 10, "require_profit": True,
             "daily_target": 100.0, "stop_at_target": True, "max_daily_loss": 100.0},
    "supervisor": {"max_spread": 0.60, "max_consecutive_losses": 4, "bot_daily_loss_limit": 60.0,
                   "jail_bars": 90, "max_hold_bars": 90},
    "learning": {"peer_talk_every": 10, "teach_bottom_n": 3, "autosave_champion": True},
    "live": {"warmup_bars": 3000, "status_every_minutes": 30},
    "notify": {"telegram_token": "", "telegram_chat_id": ""},
}


def load_config(path="config.toml"):
    cfg = copy.deepcopy(DEFAULTS)
    try:
        with open(path, "rb") as f:
            user = tomllib.load(f)
    except FileNotFoundError:
        user = {}
    for sec, vals in user.items():
        cfg.setdefault(sec, {}).update(vals)
    if cfg["bots"]["lot"] > cfg["bots"]["max_lot"]:
        raise ValueError("bots.lot ต้องไม่เกิน bots.max_lot")
    return cfg
