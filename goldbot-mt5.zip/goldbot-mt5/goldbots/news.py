"""ห้องข่าว: บอทข่าว 5 ตัว ติดตามข่าวที่มีผลต่อทอง แล้วแจ้งทุกคนว่าทองน่าจะผันผวนตอนไหน และไปทางไหน
- ปฏิทินเศรษฐกิจ (ForexFactory) บอกเวลาประกาศตัวเลขสำคัญล่วงหน้า เช่น CPI, NFP, ประชุมเฟด
- หัวข่าวจาก RSS (FXStreet, investingLive) แยกให้บอทข่าวแต่ละโต๊ะตามหัวข้อ แล้วให้คะแนนว่าข่าวนั้นมักทำให้ทองขึ้นหรือลง
- หลังข่าวแรงประกาศ บอทข่าววัดว่าทองวิ่งจริงเท่าไรใน 30 นาที แล้วเก็บเป็นสถิติอ้างอิงครั้งต่อไป
- ผู้คุมความเสี่ยงพักเปิดออเดอร์เงินจริงช่วงก่อน-หลังข่าวแรง (ตั้งค่าได้) บอทยังฝึกเทรดต่อ
ดึงข่าวในเธรดแยก ไม่ทำให้การเทรดช้า ถ้าอินเทอร์เน็ตหรือเว็บข่าวมีปัญหา ระบบเทรดยังทำงานต่อตามปกติ"""
import csv
import datetime as dt
import email.utils
import html
import json
import math
import os
import re
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET

try:
    from zoneinfo import ZoneInfo
except Exception:          # pragma: no cover
    ZoneInfo = None

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) goldbot-mt5-newsroom/1.0"

# (ชื่อบอทข่าว, โต๊ะข่าว, รหัส, สีประจำโต๊ะ)
DESKS = [
    ("พิมพ์ทอง", "ข่าวทองคำ", "gold", "#B8860B"),
    ("แซม", "ตลาดอเมริกา", "us", "#1D4ED8"),
    ("ยูโร่", "ตลาดยุโรป", "eu", "#0E7490"),
    ("หมิง", "ตลาดเอเชีย", "asia", "#B91C1C"),
    ("ชิลด์", "ภูมิรัฐศาสตร์และน้ำมัน", "geo", "#4D7C0F"),
]
DESK_IDX = {d[2]: i for i, d in enumerate(DESKS)}

# หัวข้อของแต่ละโต๊ะ (ข่าวหนึ่งอาจเข้าหลายโต๊ะ)
TOPIC = {
    "gold": re.compile(r"\bgold\b|xau|bullion|precious metal|\bsilver\b", re.I),
    "us": re.compile(r"\bfed\b|fomc|powell|federal reserve|dollar|\busd\b|treasur|payroll|\bnfp\b|jobless|\bcpi\b|\bpce\b|"
                     r"wall street|s&p|nasdaq|\bdow\b|white house|trump|bessent|\bism\b", re.I),
    "eu": re.compile(r"\becb\b|lagarde|\beuro\b|eurozone|euro area|eur/|germany|german|france|french|\bboe\b|"
                     r"bank of england|britain|british|\bgbp\b|pound|sterling|swiss|\bsnb\b|europe", re.I),
    "asia": re.compile(r"china|chinese|pboc|yuan|japan|\bboj\b|\byen\b|india|asia|\brba\b|australia|aussie|korea|"
                       r"hong kong|beijing|tokyo", re.I),
    "geo": re.compile(r"\bwar\b|strike|missile|attack|iran|israel|russia|ukraine|sanction|tariff|hormuz|houthi|"
                      r"military|ceasefire|truce|explosion|geopolit|opec|\boil\b|crude|tension|conflict|gaza|nato", re.I),
}
US_CASE = re.compile(r"\bUS\b|U\.S\.")

# กฎให้คะแนนผลต่อทอง (+ = ทองมักขึ้น, - = ทองมักลง) พร้อมเหตุผลภาษาไทย
RULES = [
    (r"\bgold\b.{0,45}\b(rises?|gains?|climbs?|rall(y|ies)|jumps?|surges?|soars?|record|rebounds?|higher|regains?|extends gains|advances?)",
     1.5, "ข่าวรายงานว่าทองกำลังขึ้น"),
    (r"\bgold\b.{0,45}\b(falls?|drops?|slides?|slips?|declines?|retreats?|tumbles?|plunges?|sinks?|lower|loses|eases|dips?)",
     -1.5, "ข่าวรายงานว่าทองกำลังลง"),
    (r"rate cuts?|cuts? (interest )?rates|dovish|easing cycle|lower rates|pause (rate )?hikes", 1.0,
     "ดอกเบี้ยมีแนวโน้มลด ทองมักได้ประโยชน์"),
    (r"rate hikes?|hikes? (interest )?rates|raises? rates|hawkish|tightening|higher for longer", -1.0,
     "ดอกเบี้ยมีแนวโน้มขึ้น ทองมักถูกกดดัน"),
    (r"(?<![/\w])(dollar|usd|dxy|greenback)(?![/\w]).{0,30}\b(gains?|rises?|strengthens?|rall(y|ies)|climbs?|firms?|jumps?|higher|bid)",
     -1.0, "ดอลลาร์แข็ง ทองมักอ่อน"),
    (r"(?<![/\w])(dollar|usd|dxy|greenback)(?![/\w]).{0,30}\b(falls?|weakens?|slides?|drops?|declines?|slips?|lower|softer|offered)",
     1.0, "ดอลลาร์อ่อน ทองมักขึ้น"),
    (r"yields?\b.{0,30}\b(rises?|climbs?|jumps?|surges?|higher|spikes?)|high(er)? yield", -0.8,
     "บอนด์ยีลด์ขึ้น ทองมักถูกกดดัน"),
    (r"yields?\b.{0,30}\b(falls?|drops?|slides?|declines?|lower|retreats?)", 0.8, "บอนด์ยีลด์ลง ทองมักได้ประโยชน์"),
    (r"\b(war|missiles?|strikes?|attacks?|explosions?|escalat\w*|invasion|tensions?|conflict|military)\b", 1.0,
     "ความตึงเครียด นักลงทุนมักหนีเข้าทอง"),
    (r"ceasefire|truce|peace (deal|talks|agreement|plan)|de-?escalat", -0.8, "ความตึงเครียดลดลง แรงซื้อทองหลุมหลบภัยลด"),
    (r"safe.haven", 0.8, "มีแรงซื้อสินทรัพย์ปลอดภัย"),
    (r"central banks?.{0,30}(gold|buy)|pboc.{0,30}gold|gold reserves|gold purchases", 1.0, "ธนาคารกลางซื้อทองสะสม"),
    (r"recession|slowdown|weak(er)? (jobs|data|payrolls|growth)|unemployment (rises|jumps|climbs)|jobs miss|contraction",
     0.8, "เศรษฐกิจอ่อน ทองมักได้ประโยชน์"),
    (r"(strong|robust|hot|solid)(er)? (jobs|payrolls|data|gdp|retail sales|growth)|beats? (expectations|estimates)|"
     r"unemployment (falls|drops)", -0.8, "ตัวเลขเศรษฐกิจแข็ง ดอลลาร์มักแข็ง ทองถูกกดดัน"),
    (r"inflation.{0,30}(hotter|accelerat\w*|rises?|jumps?|higher than|sticky)|hot(ter)? (cpi|inflation)", -0.6,
     "เงินเฟ้อสูง ดอกเบี้ยอาจไม่ลด ทองถูกกดดันระยะสั้น"),
    (r"inflation.{0,30}(cools?|eases?|slows?|lower than)|(soft|cool)(er)? (cpi|inflation)", 0.6,
     "เงินเฟ้อชะลอ เปิดทางลดดอกเบี้ย ทองมักขึ้น"),
    (r"(stocks|equities|wall street|markets?).{0,30}(sell-?off|tumble|plunge|slump|heavy selling|rout)|risk.off", 0.6,
     "ตลาดหุ้นเทขาย เงินมักไหลเข้าทอง"),
    (r"\btariffs?\b|trade war", 0.5, "ความไม่แน่นอนเรื่องการค้า มักหนุนทอง"),
]
RULES = [(re.compile(p, re.I), s, why) for p, s, why in RULES]
# คำที่บอกว่าข่าวนี้อาจทำให้ราคาวิ่งแรง (แม้ทิศไม่ชัด)
HOT = re.compile(r"breaking|explosion|strike|attack|surprise|emergency|unexpected|shock|plunge|surge|record|"
                 r"\bcpi\b|nonfarm|payrolls|\bfomc\b|powell|rate decision", re.I)

COUNTRY_DESK = {"USD": "us", "CAD": "us", "EUR": "eu", "GBP": "eu", "CHF": "eu", "CNY": "asia", "JPY": "asia",
                "AUD": "asia", "NZD": "asia", "INR": "asia", "All": "geo"}
COUNTRY_TH = {"USD": "สหรัฐ", "EUR": "ยูโรโซน", "GBP": "อังกฤษ", "CHF": "สวิส", "CNY": "จีน", "JPY": "ญี่ปุ่น",
              "AUD": "ออสเตรเลีย", "NZD": "นิวซีแลนด์", "CAD": "แคนาดา", "INR": "อินเดีย", "All": "ทั่วโลก"}
IMPACT_TH = {"High": "แรง", "Medium": "กลาง", "Low": "เบา"}


def fmt(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def hm(ts):
    return time.strftime("%H:%M", time.localtime(ts))


def score_title(title):
    """ให้คะแนนผลต่อทองของหัวข่าว คืน (คะแนน -2..2, เหตุผล, ข่าวแรงไหม)"""
    s, why = 0.0, []
    for rx, v, w in RULES:
        if rx.search(title):
            s += v
            if w not in why:
                why.append(w)
    s = max(-2.0, min(2.0, s))
    return round(s, 2), why[:2], bool(HOT.search(title)) or abs(s) >= 1.5


def desks_of(title):
    out = [k for k, rx in TOPIC.items() if rx.search(title)]
    if US_CASE.search(title) and "us" not in out:
        out.append("us")
    return out


def parse_rss(data, source):
    root = ET.fromstring(data)
    out = []
    for it in root.iter("item"):
        t = html.unescape((it.findtext("title") or "").strip())
        link = (it.findtext("link") or "").strip()
        pd = it.findtext("pubDate") or ""
        ts = None
        try:
            ts = email.utils.parsedate_to_datetime(pd).timestamp()
        except Exception:
            try:
                ts = dt.datetime.fromisoformat(pd.strip()).replace(tzinfo=dt.timezone.utc).timestamp()
            except Exception:
                ts = time.time()
        if t:
            out.append({"title": t, "link": link, "ts": ts, "source": source})
    return out


def parse_calendar(data):
    out = []
    for e in json.loads(data):
        try:
            ts = dt.datetime.fromisoformat(e["date"]).timestamp()
        except Exception:
            continue
        out.append({"title": e.get("title", "?"), "country": e.get("country", ""), "ts": ts,
                    "impact": e.get("impact", ""), "forecast": e.get("forecast", ""), "previous": e.get("previous", "")})
    return out


def ev_key(e):
    return f"{e['country']}|{e['title']}|{int(e['ts'])}"


class NewsRoom:
    def __init__(self, arena):
        self.a = arena
        c = arena.cfg.get("news", {})
        self.enabled = bool(c.get("enabled", True))
        self.cal_url = c.get("calendar_url", "https://nfs.faireconomy.media/ff_calendar_thisweek.json")
        self.feeds = c.get("feeds") or [
            {"name": "FXStreet ข่าว", "url": "https://www.fxstreet.com/rss/news"},
            {"name": "FXStreet บทวิเคราะห์", "url": "https://www.fxstreet.com/rss/analysis"},
            {"name": "investingLive", "url": "https://investinglive.com/feed/"},
        ]
        self.cal_every = 60 * float(c.get("calendar_every_minutes", 60))
        self.feed_every = 60 * float(c.get("feeds_every_minutes", 10))
        self.watch = set(c.get("watch_countries", ["USD", "EUR", "GBP", "CNY", "JPY", "CHF", "All"]))
        self.pause_on = bool(c.get("pause_live_on_news", True))
        self.pause_before = 60 * float(c.get("pause_before_minutes", 10))
        self.pause_after = 60 * float(c.get("pause_after_minutes", 20))
        self.pause_countries = set(c.get("pause_countries", ["USD"]))
        self.measure_min = int(c.get("measure_minutes", 30))
        self.notify_on = bool(c.get("notify", True))
        self.calendar = []          # ข่าวในปฏิทินที่ติดตาม
        self.items = []             # หัวข่าวล่าสุด
        self.seen = []              # ลิงก์/หัวข่าวที่เคยเห็น (กันซ้ำ)
        self.stats = {}             # สถิติทองวิ่งหลังข่าวแต่ละชนิด
        self.results = []           # ผลวัดหลังข่าวล่าสุด
        self.watching = {}          # ข่าวที่กำลังวัดผล
        self.done = []              # ข่าวที่วัดผลแล้ว/พลาด
        self.alerted = []           # คีย์ที่แจ้งเตือนไปแล้ว
        self.alerts = []            # [ลำดับ, เวลา, โต๊ะ, ข้อความ, ระดับ]
        self.seq = 0
        self.last_cal = 0.0
        self.last_feed = 0.0
        self.errors = {}
        self.paused_for = None
        self._last_bar_wall = 0.0
        self._inbox = []
        self._lock = threading.Lock()
        self._force = threading.Event()
        self._thread = None
        self.folder = getattr(arena.storage, "folder", None) if arena.storage else None

    # ================= ดึงข่าว (เธรดแยก) =================
    def start(self):
        if not self.enabled or self._thread:
            return
        self._load_cache()
        self._thread = threading.Thread(target=self._loop, name="newsroom", daemon=True)
        self._thread.start()

    def refresh(self):
        self.last_cal = self.last_feed = 0.0
        self._force.set()

    def _get(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read()

    def _put(self, *msg):
        with self._lock:
            self._inbox.append(msg)

    def _loop(self):
        while True:
            now = time.time()
            if now - self.last_cal >= self.cal_every:
                self.last_cal = now
                try:
                    data = self._get(self.cal_url)
                    cal = parse_calendar(data)
                    self._put("cal", cal)
                    if self.folder:
                        with open(os.path.join(self.folder, "news_calendar_cache.json"), "wb") as f:
                            f.write(data)
                except Exception as e:
                    self._put("err", "ปฏิทินเศรษฐกิจ", str(e)[:120])
            if now - self.last_feed >= self.feed_every:
                self.last_feed = now
                for fd in self.feeds:
                    try:
                        self._put("rss", fd["name"], parse_rss(self._get(fd["url"]), fd["name"]))
                    except Exception as e:
                        self._put("err", fd["name"], str(e)[:120])
            self._force.wait(20)
            self._force.clear()

    def _load_cache(self):
        if not self.folder:
            return
        p = os.path.join(self.folder, "news_calendar_cache.json")
        if os.path.exists(p) and not self.calendar:
            try:
                with open(p, "rb") as f:
                    self._put("cal", parse_calendar(f.read()))
            except Exception:
                pass

    # ================= รับข่าวเข้า (เธรดหลัก) =================
    def _drain(self):
        with self._lock:
            box, self._inbox = self._inbox, []
        for msg in box:
            if msg[0] == "cal":
                self._take_calendar(msg[1])
            elif msg[0] == "rss":
                self.errors.pop(msg[1], None)
                self._take_items(msg[2])
            elif msg[0] == "err":
                first = msg[1] not in self.errors
                self.errors[msg[1]] = msg[2]
                if first:
                    self.a.log("news", f"ห้องข่าว: ดึง {msg[1]} ไม่ได้ ({msg[2]}) จะลองใหม่รอบถัดไป ระบบเทรดทำงานต่อตามปกติ")

    def _take_calendar(self, cal):
        self.errors.pop("ปฏิทินเศรษฐกิจ", None)
        keep = []
        for e in cal:
            if e["country"] not in self.watch or e["impact"] not in ("High", "Medium"):
                continue
            if e["impact"] == "Medium" and e["country"] != "USD":
                continue
            e["desk"] = DESK_IDX[COUNTRY_DESK.get(e["country"], "geo")]
            keep.append(e)
        old = {ev_key(e) for e in self.calendar}
        now = time.time()
        # เก็บข่าวที่ผ่านไปแล้วไม่เกิน 2 วันไว้ด้วย รวมกับของใหม่
        merged = {ev_key(e): e for e in self.calendar if e["ts"] > now - 2 * 86400}
        merged.update({ev_key(e): e for e in keep})
        self.calendar = sorted(merged.values(), key=lambda e: e["ts"])
        new_hi = [e for e in keep if ev_key(e) not in old and e["impact"] == "High" and e["ts"] > now]
        if new_hi and old:
            for e in new_hi[:3]:
                self._alert(e["desk"], f"เพิ่มในปฏิทิน: {e['title']} ({COUNTRY_TH.get(e['country'], e['country'])}) "
                                       f"{time.strftime('%a %H:%M', time.localtime(e['ts']))}", "info")
        elif not old and keep:
            nxt = [e for e in keep if e["ts"] > now and e["impact"] == "High"]
            self.a.log("news", f"ห้องข่าว: โหลดปฏิทินเศรษฐกิจแล้ว ข่าวแรงที่รอประกาศสัปดาห์นี้ {len(nxt)} ข่าว")

    def _take_items(self, items):
        seen = set(self.seen)
        new = []
        for it in items:
            k = it["link"] or it["title"].lower()
            k2 = re.sub(r"\W+", "", it["title"].lower())[:80]
            if k in seen or k2 in seen:
                continue
            seen.add(k)
            seen.add(k2)
            self.seen += [k, k2]
            ds = desks_of(it["title"])
            if not ds:
                continue
            s, why, hot = score_title(it["title"])
            it.update(desks=[DESK_IDX[d] for d in ds], score=s, why=why, hot=hot)
            new.append(it)
        self.seen = self.seen[-3000:]
        if not new:
            return
        new.sort(key=lambda x: x["ts"])
        self.items = (self.items + new)[-300:]
        if self.folder:
            p = os.path.join(self.folder, "news_headlines.csv")
            first = not os.path.exists(p)
            try:
                with open(p, "a", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f)
                    if first:
                        w.writerow(["time", "desks", "score", "reason", "title", "source", "link"])
                    for it in new:
                        w.writerow([time.strftime("%Y-%m-%d %H:%M", time.localtime(it["ts"])),
                                    "/".join(DESKS[d][1] for d in it["desks"]), it["score"], " / ".join(it["why"]),
                                    it["title"], it["source"], it["link"]])
            except OSError:
                pass
        # ข่าวใหม่ที่แรงพอ แจ้งทุกคน (ไม่เกิน 3 ข่าวต่อรอบ และเฉพาะข่าวไม่เกิน 2 ชั่วโมง)
        now = time.time()
        for it in [x for x in new if x["hot"] and abs(x["score"]) >= 1 and now - x["ts"] < 7200][-3:]:
            d = it["desks"][0] if DESK_IDX["gold"] not in it["desks"] else DESK_IDX["gold"]
            side = "ทองมักขึ้น" if it["score"] > 0 else "ทองมักลง"
            self._alert(d, f"{side}: {it['why'][0] if it['why'] else ''} | {it['title'][:90]}", "warn")

    def _alert(self, desk, text, level, notify=False):
        self.seq += 1
        self.alerts.append([self.seq, time.time(), desk, text, level])
        self.alerts = self.alerts[-60:]
        self.a.log("news", f"📰 {DESKS[desk][0]} ({DESKS[desk][1]}): {text}")
        if notify and self.notify_on:
            self.a.notify(f"📰 {DESKS[desk][0]}: {text}")

    # ================= งานทุกนาที =================
    def tick(self, bar=None):
        if not self.enabled:
            return
        self._drain()
        now = time.time()
        a = self.a
        for e in self.calendar:
            k = ev_key(e)
            left = e["ts"] - now
            if e["impact"] == "High" and 0 < left <= 3600 and k + "|60" not in self.alerted and left > 900:
                self.alerted.append(k + "|60")
                self._alert(e["desk"], f"อีกประมาณ 1 ชั่วโมง ({hm(e['ts'])}) ประกาศ {e['title']} "
                                       f"({COUNTRY_TH.get(e['country'], e['country'])}) {self._expect(e)}".strip(), "warn")
            if e["impact"] == "High" and 0 < left <= 900 and k + "|15" not in self.alerted:
                self.alerted.append(k + "|15")
                extra = ""
                if self.pause_on and e["country"] in self.pause_countries:
                    extra = (f" ผู้คุมความเสี่ยงจะพักเปิดออเดอร์เงินจริง {int(self.pause_before / 60)} นาทีก่อน "
                             f"ถึง {int(self.pause_after / 60)} นาทีหลังข่าว")
                self._alert(e["desk"], f"อีก {max(1, int(left / 60))} นาที ({hm(e['ts'])}) ประกาศ {e['title']} "
                                       f"({COUNTRY_TH.get(e['country'], e['country'])}) ระวังทองผันผวน {self._expect(e)}{extra}",
                            "hot", notify=True)
            # เริ่มวัดผลหลังข่าว
            if left <= 0 and k not in self.watching and k not in self.done:
                fresh = a.last_bar is not None and (bar is not None or now - self._last_bar_wall < 300)
                if -left < 600 and fresh:
                    p = a.last_bar.close
                    atr = a.s.atr_at(14, len(a.s.c)) if len(a.s.c) > 15 else 0.0
                    self.watching[k] = {"p0": p, "hi": p, "lo": p, "last": p, "bars": 0, "end": e["ts"] + 60 * self.measure_min,
                                        "atr": atr, "ev": e}
                else:
                    self.done.append(k)
        if bar is not None:
            self._last_bar_wall = now
            for w in self.watching.values():
                w["hi"] = max(w["hi"], bar.high)
                w["lo"] = min(w["lo"], bar.low)
                w["last"] = bar.close
                w["bars"] += 1
        for k in [k for k, w in self.watching.items() if now >= w["end"]]:
            self._finish(k, self.watching.pop(k))
        self.done = self.done[-500:]
        self.alerted = self.alerted[-500:]
        # สถานะพักเทรดจริงเพราะข่าว
        r = self.pause_reason()
        if r != self.paused_for:
            if r and not self.paused_for:
                a.log("risk", f"ผู้คุมความเสี่ยง: {r} พักเปิดออเดอร์เงินจริงชั่วคราว บอทยังฝึกเทรดต่อ")
            elif not r and self.paused_for:
                a.log("risk", "ผู้คุมความเสี่ยง: พ้นช่วงข่าวแรงแล้ว กลับมาเปิดออเดอร์เงินจริงได้")
            self.paused_for = r

    def _finish(self, k, w):
        self.done.append(k)
        e = w["ev"]
        if w["bars"] < max(5, self.measure_min // 3):
            return                       # ตลาดปิดหรือข้อมูลไม่พอ ไม่บันทึก
        rng = w["hi"] - w["lo"]
        move = w["last"] - w["p0"]
        normal = w["atr"] * math.sqrt(self.measure_min) if w["atr"] else 0
        ratio = round(rng / normal, 2) if normal > 0 else None
        res = {"title": e["title"], "country": e["country"], "impact": e["impact"], "ts": e["ts"],
               "forecast": e.get("forecast", ""), "previous": e.get("previous", ""),
               "range": round(rng, 2), "move": round(move, 2), "ratio": ratio, "desk": e["desk"]}
        self.results = (self.results + [res])[-60:]
        sk = f"{e['country']}|{e['title']}"
        st = self.stats.setdefault(sk, {"n": 0, "range": 0.0, "absmove": 0.0, "up": 0, "down": 0})
        st["n"] += 1
        st["range"] += (rng - st["range"]) / st["n"]
        st["absmove"] += (abs(move) - st["absmove"]) / st["n"]
        st["up" if move > 0 else "down"] += 1
        if self.folder:
            p = os.path.join(self.folder, "news_events.csv")
            first = not os.path.exists(p)
            try:
                with open(p, "a", newline="", encoding="utf-8-sig") as f:
                    wr = csv.writer(f)
                    if first:
                        wr.writerow(["time", "country", "event", "impact", "forecast", "previous",
                                     f"range_{self.measure_min}m", "move", "x_normal"])
                    wr.writerow([time.strftime("%Y-%m-%d %H:%M", time.localtime(e["ts"])), e["country"], e["title"],
                                 e["impact"], e.get("forecast", ""), e.get("previous", ""), res["range"], res["move"], ratio])
            except OSError:
                pass
        txt = (f"ผลหลังข่าว {e['title']}: ใน {self.measure_min} นาทีทองวิ่ง ${rng:.2f} "
               f"({'ขึ้น' if move > 0 else 'ลง'} {fmt(move)}" + (f", {ratio} เท่าของช่วงปกติ" if ratio else "") +
               f") บันทึกเป็นข้อมูลอ้างอิงแล้ว (ข่าวนี้วัดมา {st['n']} ครั้ง)")
        self._alert(e["desk"], txt, "info", notify=e["impact"] == "High")

    def _expect(self, e):
        st = self.stats.get(f"{e['country']}|{e['title']}")
        if st and st["n"]:
            return (f"ครั้งก่อนๆ ทองวิ่งเฉลี่ย ${st['range']:.2f} ใน {self.measure_min} นาที "
                    f"(ขึ้น {st['up']} ลง {st['down']} ครั้ง)")
        return ""

    def pause_reason(self):
        if not (self.enabled and self.pause_on):
            return None
        now = time.time()
        for e in self.calendar:
            if e["impact"] == "High" and e["country"] in self.pause_countries \
                    and e["ts"] - self.pause_before <= now <= e["ts"] + self.pause_after:
                return f"ช่วงข่าวแรง {e['title']} ({COUNTRY_TH.get(e['country'], e['country'])} {hm(e['ts'])})"
        return None

    # ================= สรุปให้ทุกคน =================
    def bias(self, desk=None, hours=12):
        now = time.time()
        s = w = 0.0
        for it in self.items:
            if desk is not None and desk not in it["desks"]:
                continue
            age = (now - it["ts"]) / 3600
            if age < 0 or age > hours:
                continue
            k = math.exp(-age / 6)
            s += it["score"] * k
            w += k
        return round(math.tanh(s / 3), 2), round(w, 1)

    def volatility_now(self):
        now = time.time()
        if self.pause_reason():
            return "high", self.pause_reason()
        for e in self.calendar:
            if e["impact"] == "High" and 0 < e["ts"] - now <= 3600:
                return "watch", f"อีก {int((e['ts'] - now) / 60)} นาที ประกาศ {e['title']} ({COUNTRY_TH.get(e['country'], e['country'])})"
            if e["impact"] == "High" and 0 <= now - e["ts"] <= 1800:
                return "high", f"เพิ่งประกาศ {e['title']} ราคามักยังแกว่งแรง"
        hot = [it for it in self.items if it["hot"] and 0 <= now - it["ts"] <= 1800]
        if hot:
            return "watch", f"มีข่าวแรงใน 30 นาทีที่ผ่านมา {len(hot)} ข่าว"
        return "calm", "ไม่มีข่าวแรงในชั่วโมงนี้"

    def sessions(self, hours=30):
        """เวลาตลาดใหญ่เปิด (ทองมักผันผวนเพิ่ม) คิดตามเวลาออมแสงของแต่ละประเทศ"""
        if ZoneInfo is None:
            return []
        out = []
        now = time.time()
        try:
            for name, tz, h, m in (("ตลาดยุโรป (ลอนดอน) เปิด", "Europe/London", 8, 0),
                                   ("ตลาดหุ้นสหรัฐ (นิวยอร์ก) เปิด", "America/New_York", 9, 30)):
                z = ZoneInfo(tz)
                d0 = dt.datetime.now(z).date()
                for k in range(3):
                    d = d0 + dt.timedelta(days=k)
                    if d.weekday() >= 5:
                        continue
                    ts = dt.datetime(d.year, d.month, d.day, h, m, tzinfo=z).timestamp()
                    if now - 1800 < ts < now + hours * 3600:
                        out.append({"title": name, "ts": ts, "kind": "session"})
        except Exception:
            return []
        return out

    def upcoming(self, hours=36, limit=14):
        now = time.time()
        out = []
        for e in self.calendar:
            if now - 1800 <= e["ts"] <= now + hours * 3600:
                st = self.stats.get(f"{e['country']}|{e['title']}")
                out.append({"title": e["title"], "country": e["country"], "ts": e["ts"], "impact": e["impact"],
                            "forecast": e.get("forecast", ""), "previous": e.get("previous", ""), "desk": e["desk"],
                            "kind": "event", "pause": self.pause_on and e["impact"] == "High" and e["country"] in self.pause_countries,
                            "hist": {"n": st["n"], "range": round(st["range"], 2), "up": st["up"], "down": st["down"]} if st else None})
        out += self.sessions(hours)
        out.sort(key=lambda x: x["ts"])
        return out[:limit]

    def text(self):
        lv, why = self.volatility_now()
        b, _ = self.bias()
        lines = [f"ห้องข่าว: ความผันผวนตอนนี้ {({'calm': 'ปกติ', 'watch': 'ระวัง', 'high': 'สูง'})[lv]} ({why}) | "
                 f"ภาพรวมข่าวต่อทอง {'บวก' if b > 0.15 else 'ลบ' if b < -0.15 else 'กลางๆ'} ({b:+.2f})"]
        for u in [x for x in self.upcoming(36, 8) if x["kind"] == "event"]:
            lines.append(f"- {time.strftime('%a %H:%M', time.localtime(u['ts']))} {u['title']} "
                         f"({COUNTRY_TH.get(u['country'], u['country'])}, {IMPACT_TH.get(u['impact'], u['impact'])})")
        if self.errors:
            lines.append("ดึงข่าวไม่ได้: " + ", ".join(self.errors))
        return "\n".join(lines)

    def dash(self):
        now = time.time()
        lv, why = self.volatility_now()
        desks = []
        for i, (nm, sj, code, col) in enumerate(DESKS):
            b, w = self.bias(i)
            its = [x for x in self.items if i in x["desks"]][-6:][::-1]
            desks.append({"name": nm, "desk": sj, "code": code, "color": col, "bias": b, "weight": w,
                          "items": [{k: x[k] for k in ("title", "link", "ts", "source", "score", "why", "hot")} for x in its],
                          "count": sum(1 for x in self.items if i in x["desks"] and now - x["ts"] < 86400)})
        b, w = self.bias()
        return {"enabled": self.enabled, "level": lv, "why": why, "bias": b, "weight": w, "desks": desks,
                "upcoming": self.upcoming(), "pause": self.pause_reason(), "pause_on": self.pause_on,
                "pause_before": int(self.pause_before / 60), "pause_after": int(self.pause_after / 60),
                "results": self.results[-12:][::-1], "alerts": self.alerts[-30:], "seq": self.seq,
                "stats_n": len(self.stats), "measured": sum(s["n"] for s in self.stats.values()),
                "headlines": len(self.seen) // 2, "last_cal": self.last_cal or None, "last_feed": self.last_feed or None,
                "errors": self.errors, "measure_min": self.measure_min,
                "watching": [w["ev"]["title"] for w in self.watching.values()]}

    def to_state(self):
        return {"calendar": self.calendar, "items": self.items[-200:], "seen": self.seen[-3000:], "stats": self.stats,
                "results": self.results, "done": self.done, "alerted": self.alerted, "alerts": self.alerts,
                "seq": self.seq}

    def load_state(self, st):
        for k in ("calendar", "items", "seen", "stats", "results", "done", "alerted", "alerts", "seq"):
            if k in st:
                setattr(self, k, st[k])
