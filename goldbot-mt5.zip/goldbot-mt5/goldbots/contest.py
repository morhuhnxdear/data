"""การแข่งขัน 2 รายการ
1) บอทเทรด 50 ตัวแข่งกันว่าใครทำกำไรได้มากที่สุด (นับทุกไม้ของบอท ทั้งไม้ฝึกและไม้เงินจริง ใช้ล็อตเท่ากัน)
2) ครูแข่งกันคิดสูตร: วัดจากกำไรของ "สูตรที่สอนอยู่" ที่ครูลองเทรดบนราคาจริงแบบไม่ใช้เงิน
   (สูตรที่ครูคิดได้ดีจริงต้องทำกำไรได้ในตลาดตอนนี้ ไม่ใช่แค่ทดสอบย้อนหลังได้ดี)
แต่ละรายการมี 3 ตาราง: วันนี้ / สัปดาห์นี้ / ทั้งหมด (นับตั้งแต่เริ่มฤดูกาล)
จบวัน: อันดับ 1 ของวันได้ถ้วยประจำวัน  จบสัปดาห์: อันดับ 1 ของสัปดาห์ได้ถ้วยประจำสัปดาห์
(ต้องมีกำไรด้วย ถ้าทั้งกลุ่มขาดทุน ไม่มีใครได้ถ้วย)"""
import datetime as dt

PERIODS = ("d", "w", "a")          # วันนี้ / สัปดาห์นี้ / ทั้งหมด
TOP = 10


def fmt(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def week_key(day):
    y, w, _ = day.isocalendar()
    return f"{y}-W{w:02d}"


class Board:
    """ตารางคะแนนของผู้แข่งขันกลุ่มหนึ่ง (บอท หรือ ครู)"""

    def __init__(self, n):
        self.n = n
        self.reset()

    def reset(self):
        self.s = {p: [[0.0, 0, 0] for _ in range(self.n)] for p in PERIODS}   # [กำไร, ไม้, ชนะ]
        self.cups = [0] * self.n       # ถ้วยประจำวัน
        self.wcups = [0] * self.n      # ถ้วยประจำสัปดาห์
        self.prev = {}                 # อันดับตอนเริ่มวัน (ไว้แสดงลูกศรขึ้น/ลง)

    def add(self, i, pnl):
        for p in PERIODS:
            r = self.s[p][i]
            r[0] += pnl
            r[1] += 1
            r[2] += 1 if pnl > 0 else 0

    def ranking(self, p):
        rows = [(i, r) for i, r in enumerate(self.s[p]) if r[1] > 0]
        rows.sort(key=lambda x: (-x[1][0], -(x[1][2] / x[1][1]), -x[1][1], x[0]))
        return [i for i, _ in rows]

    def snapshot(self):
        self.prev = {p: {i: k for k, i in enumerate(self.ranking(p))} for p in ("w", "a")}

    def clear(self, p):
        self.s[p] = [[0.0, 0, 0] for _ in range(self.n)]

    def top(self, p, k=TOP):
        out = []
        prev = self.prev.get(p, {})
        for rank, i in enumerate(self.ranking(p)[:k]):
            pnl, n, w = self.s[p][i]
            old = prev.get(i)
            out.append({"id": i, "pnl": round(pnl, 2), "trades": n, "wins": w,
                        "move": None if old is None else old - rank, "cups": self.cups[i], "wcups": self.wcups[i]})
        return out

    def to_state(self):
        return {"s": self.s, "cups": self.cups, "wcups": self.wcups,
                "prev": {p: {str(k): v for k, v in d.items()} for p, d in self.prev.items()}}

    def load_state(self, st):
        n = self.n
        for p in PERIODS:
            v = st.get("s", {}).get(p)
            if isinstance(v, list):
                self.s[p] = [list(x) for x in v[:n]] + [[0.0, 0, 0] for _ in range(n - len(v[:n]))]
        for k in ("cups", "wcups"):
            v = st.get(k)
            if isinstance(v, list):
                setattr(self, k, (v + [0] * n)[:n])
        self.prev = {p: {int(k): v for k, v in d.items() if int(k) < n} for p, d in st.get("prev", {}).items()}


class Contest:
    def __init__(self, arena):
        self.a = arena
        c = arena.cfg.get("contest", {})
        self.enabled = bool(c.get("enabled", True))
        self.bots = Board(len(arena.bots))
        self.teachers = Board(len(arena.teachers.teachers))
        self.week = None
        self.season_start = None
        self.days = []        # แชมป์ประจำวัน [วัน, บอท, กำไร, ครู, กำไร]
        self.weeks = []       # แชมป์ประจำสัปดาห์ [สัปดาห์, บอท, กำไร, ครู, กำไร]

    # ---------- เก็บคะแนน ----------
    def _on(self):
        return self.enabled and not self.a.qualifying

    def bot_trade(self, b, pnl):
        if self._on():
            self._start()
            self.bots.add(b.id, pnl)

    def teacher_trade(self, t, pnl):
        if self._on():
            self._start()
            self.teachers.add(t.id, pnl)

    def _start(self):
        if self.season_start is None and self.a.day is not None:
            self.season_start = str(self.a.day)
            self.week = week_key(self.a.day)

    # ---------- จบวัน / ขึ้นวันใหม่ ----------
    def end_day(self, day):
        """เรียกก่อนล้างตัวเลขรายวัน: ให้ถ้วยประจำวัน"""
        if not self._on() or day is None:
            return
        bw = self._winner(self.bots, "d")
        tw = self._winner(self.teachers, "d")
        if bw or tw:
            self.days.append([str(day), bw[0] if bw else None, bw[1] if bw else None,
                              tw[0] if tw else None, tw[1] if tw else None])
            self.days = self.days[-60:]
            a = self.a
            parts = []
            if bw:
                self.bots.cups[bw[0]] += 1
                parts.append(f"{a.bots[bw[0]].tag} {fmt(bw[1])}")
            if tw:
                self.teachers.cups[tw[0]] += 1
                parts.append(f"ครู {a.teachers.teachers[tw[0]].name} {fmt(tw[1])}")
            a.log("contest", f"🏆 ผลแข่งขันวันที่ {day}: " + " | ".join(parts))
        self.bots.clear("d")
        self.teachers.clear("d")

    def new_day(self, day):
        """เรียกเมื่อขึ้นวันใหม่: ถ้าข้ามสัปดาห์ ให้ถ้วยประจำสัปดาห์แล้วเริ่มสัปดาห์ใหม่"""
        if not self.enabled or day is None:
            return
        wk = week_key(day)
        if self.week is not None and wk != self.week and not self.a.qualifying:
            bw = self._winner(self.bots, "w")
            tw = self._winner(self.teachers, "w")
            if bw or tw:
                self.weeks.append([self.week, bw[0] if bw else None, bw[1] if bw else None,
                                   tw[0] if tw else None, tw[1] if tw else None])
                self.weeks = self.weeks[-20:]
                parts = []
                if bw:
                    self.bots.wcups[bw[0]] += 1
                    parts.append(f"{self.a.bots[bw[0]].tag} {fmt(bw[1])}")
                if tw:
                    self.teachers.wcups[tw[0]] += 1
                    parts.append(f"ครู {self.a.teachers.teachers[tw[0]].name} {fmt(tw[1])}")
                self.a.log("contest", f"🏆 แชมป์ประจำสัปดาห์ {self.week}: " + " | ".join(parts))
            self.bots.clear("w")
            self.teachers.clear("w")
        if self.week is not None:
            self.week = wk
        self.bots.snapshot()
        self.teachers.snapshot()

    @staticmethod
    def _winner(board, p):
        """อันดับ 1 ที่มีกำไร (ถ้าไม่มีใครกำไรเลย ไม่มีใครได้ถ้วย)"""
        r = board.ranking(p)
        if not r or board.s[p][r[0]][0] <= 0:
            return None
        i = r[0]
        return i, round(board.s[p][i][0], 2)

    def reset(self):
        self.bots.reset()
        self.teachers.reset()
        self.days, self.weeks = [], []
        self.season_start = None
        self.week = None
        self._start()
        self.a.log("contest", "เริ่มฤดูกาลแข่งขันใหม่ ล้างคะแนนและถ้วยทั้งหมด")

    # ---------- แสดงผล ----------
    def text(self):
        a = self.a
        out = []
        for title, board, name in (("บอทเทรด", self.bots, lambda i: a.bots[i].tag),
                                   ("ครูคิดสูตร", self.teachers, lambda i: a.teachers.teachers[i].name)):
            for p, lab in (("d", "วันนี้"), ("a", "ทั้งหมด")):
                top = board.top(p, 3)
                s = ", ".join(f"{k + 1}) {name(r['id'])} {fmt(r['pnl'])}" for k, r in enumerate(top)) or "ยังไม่มีผล"
                out.append(f"แข่ง{title} {lab}: {s}")
        return "\n".join(out)

    def dash(self):
        return {"enabled": self.enabled, "season_start": self.season_start, "week": self.week,
                "bots": {p: self.bots.top(p) for p in PERIODS},
                "teachers": {p: self.teachers.top(p) for p in PERIODS},
                "n_bots": {p: len(self.bots.ranking(p)) for p in PERIODS},
                "n_teachers": {p: len(self.teachers.ranking(p)) for p in PERIODS},
                "days": self.days[-14:], "weeks": self.weeks[-8:]}

    def to_state(self):
        return {"bots": self.bots.to_state(), "teachers": self.teachers.to_state(), "week": self.week,
                "season_start": self.season_start, "days": self.days, "weeks": self.weeks}

    def load_state(self, st):
        self.bots.load_state(st.get("bots", {}))
        self.teachers.load_state(st.get("teachers", {}))
        for k in ("week", "season_start", "days", "weeks"):
            if k in st:
                setattr(self, k, st[k])
