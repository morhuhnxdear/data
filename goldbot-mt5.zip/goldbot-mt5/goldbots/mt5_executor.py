"""ส่งคำสั่งจริงไปที่ MetaTrader 5 (ทุกออเดอร์มี SL/TP ฝั่งเซิร์ฟเวอร์โบรกเกอร์)"""
import time

RETRY_CODES = ("TRADE_RETCODE_REQUOTE", "TRADE_RETCODE_PRICE_CHANGED", "TRADE_RETCODE_PRICE_OFF")


class MT5Executor:
    def __init__(self, mt5, cfg, log):
        self.mt5 = mt5
        self.log = log
        self.sym = cfg["market"]["symbol"]
        self.magic_base = cfg["bots"]["magic_base"]
        self.n_bots = cfg["bots"]["count"]
        self.deviation = cfg["market"].get("deviation", 30)
        if not mt5.symbol_select(self.sym, True):
            raise RuntimeError(f"ไม่พบสัญลักษณ์ {self.sym} ในโบรกเกอร์นี้ ตรวจชื่อใน Market Watch แล้วแก้ใน config.toml")
        info = mt5.symbol_info(self.sym)
        if info is None:
            raise RuntimeError(f"อ่านข้อมูลสัญลักษณ์ {self.sym} ไม่ได้: {mt5.last_error()}")
        self.digits = info.digits
        self.point = info.point
        self.stops = info.trade_stops_level * info.point
        self.vmin, self.vstep, self.vmax = info.volume_min, info.volume_step, info.volume_max
        self.contract = info.trade_contract_size
        fm = info.filling_mode           # bit 1 = FOK, bit 2 = IOC
        if fm & 2:
            self.filling = mt5.ORDER_FILLING_IOC
        elif fm & 1:
            self.filling = mt5.ORDER_FILLING_FOK
        else:
            self.filling = mt5.ORDER_FILLING_RETURN
        self.retry = {getattr(mt5, c) for c in RETRY_CODES if hasattr(mt5, c)}
        self.pending_close = set()

    # ---------- ช่วยคำนวณ ----------
    def _vol(self, lot):
        v = round(lot / self.vstep) * self.vstep
        return round(max(self.vmin, min(self.vmax, v)), 8)

    def _r(self, p):
        return round(p, self.digits)

    def _magic(self, b):
        return self.magic_base + b.id

    # ---------- เปิดออเดอร์ ----------
    def open(self, arena, b, d, lot, sl_d, tp_d, bar):
        mt5 = self.mt5
        min_d = self.stops + 5 * self.point
        if sl_d < min_d or tp_d < min_d:
            self.log("warn", f"{b.tag}: ระยะ SL/TP ใกล้เกินที่โบรกเกอร์อนุญาต ปรับเป็นอย่างน้อย {min_d:.2f}")
            sl_d, tp_d = max(sl_d, min_d), max(tp_d, min_d)
        vol = self._vol(lot)
        if vol > lot + 1e-9:
            self.log("warn", f"ล็อตขั้นต่ำของโบรกเกอร์คือ {self.vmin} มากกว่าที่ตั้งไว้ ({lot}) ไม่ส่งออเดอร์")
            return None
        for _ in range(3):
            tick = mt5.symbol_info_tick(self.sym)
            if tick is None:
                return None
            price = tick.ask if d > 0 else tick.bid
            req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": self.sym, "volume": vol,
                   "type": mt5.ORDER_TYPE_BUY if d > 0 else mt5.ORDER_TYPE_SELL, "price": price,
                   "sl": self._r(price - d * sl_d), "tp": self._r(price + d * tp_d),
                   "deviation": self.deviation, "magic": self._magic(b), "comment": f"GB{b.id + 1:02d}",
                   "type_time": mt5.ORDER_TIME_GTC, "type_filling": self.filling}
            r = mt5.order_send(req)
            if r is not None and r.retcode == mt5.TRADE_RETCODE_DONE:
                return {"entry": r.price or price, "sl": req["sl"], "tp": req["tp"],
                        "ticket": self._find_ticket(b, r.order)}
            if r is not None and r.retcode in self.retry:
                time.sleep(0.3)
                continue
            why = f"{r.retcode} {r.comment}" if r is not None else str(mt5.last_error())
            self.log("warn", f"ส่งออเดอร์ของ {b.tag} ไม่สำเร็จ: {why}")
            return None
        return None

    def _find_ticket(self, b, order_ticket):
        ps = self.mt5.positions_get(ticket=order_ticket)
        if ps:
            return ps[0].ticket
        mine = [p for p in (self.mt5.positions_get(symbol=self.sym) or []) if p.magic == self._magic(b)]
        return max(mine, key=lambda p: p.time).ticket if mine else order_ticket

    # ---------- ออเดอร์ที่ปิดแล้ว ----------
    def _closed_pnl(self, ticket):
        mt5 = self.mt5
        deals = mt5.history_deals_get(position=ticket)
        if not deals:
            return None
        outs = [x for x in deals if x.entry in (mt5.DEAL_ENTRY_OUT, getattr(mt5, "DEAL_ENTRY_OUT_BY", 3))]
        if not outs:
            return None
        pnl = sum(x.profit + x.commission + x.swap + getattr(x, "fee", 0.0) for x in deals)
        reason = outs[-1].reason
        if reason == getattr(mt5, "DEAL_REASON_SL", 4):
            txt = "โดนตัดขาดทุน"
        elif reason == getattr(mt5, "DEAL_REASON_TP", 5):
            txt = "ถึงจุดทำกำไร"
        elif reason == getattr(mt5, "DEAL_REASON_SO", 6):
            txt = "ถูกบังคับปิด (Stop Out)"
        else:
            txt = "ปิดแล้ว"
        return pnl, txt

    def poll(self, arena, bar):
        ps = self.mt5.positions_get(symbol=self.sym)
        if ps is None:          # เชื่อมต่อมีปัญหา อย่าเพิ่งสรุปว่าปิด
            return []
        open_t = {p.ticket for p in ps}
        out = []
        for b in arena.bots:
            if b.pos and b.pos["live"] and b.pos["ticket"] not in open_t:
                r = self._closed_pnl(b.pos["ticket"])
                if r:
                    out.append((b, r[0], r[1]))
        return out

    # ---------- ปิดออเดอร์ ----------
    def close(self, arena, b, bar):
        mt5, t = self.mt5, b.pos["ticket"]
        ps = mt5.positions_get(ticket=t)
        if ps:
            p = ps[0]
            done = False
            for _ in range(3):
                tick = mt5.symbol_info_tick(self.sym)
                if tick is None:
                    break
                sell = p.type == mt5.POSITION_TYPE_BUY
                req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": self.sym, "volume": p.volume,
                       "type": mt5.ORDER_TYPE_SELL if sell else mt5.ORDER_TYPE_BUY, "position": t,
                       "price": tick.bid if sell else tick.ask, "deviation": self.deviation, "magic": p.magic,
                       "comment": f"GB{b.id + 1:02d} close", "type_time": mt5.ORDER_TIME_GTC,
                       "type_filling": self.filling}
                r = mt5.order_send(req)
                if r is not None and r.retcode == mt5.TRADE_RETCODE_DONE:
                    done = True
                    break
                if r is not None and r.retcode in self.retry:
                    time.sleep(0.3)
                    continue
                why = f"{r.retcode} {r.comment}" if r is not None else str(mt5.last_error())
                self.log("warn", f"ปิดออเดอร์ #{t} ของ {b.tag} ไม่สำเร็จ: {why}")
                break
            if not done:
                return None
        for _ in range(10):
            r = self._closed_pnl(t)
            if r:
                return r[0]
            time.sleep(0.3)
        self.log("warn", f"ปิดออเดอร์ #{t} แล้ว แต่ยังอ่านกำไรขาดทุนจากประวัติไม่ได้ บันทึกเป็น 0 ไว้ก่อน")
        return 0.0

    # ---------- เปิดระบบใหม่: จับคู่ออเดอร์ที่ค้างใน MT5 กับบอท ----------
    def reconcile(self, arena):
        mt5 = self.mt5
        ps = mt5.positions_get(symbol=self.sym) or []
        by_magic = {}
        for p in ps:
            if self.magic_base <= p.magic < self.magic_base + self.n_bots:
                by_magic.setdefault(p.magic, []).append(p)
        open_t = {p.ticket for p in ps}
        for b in arena.bots:
            mine = by_magic.get(self._magic(b), [])
            if b.pos and b.pos["live"]:
                if b.pos["ticket"] in open_t:
                    continue
                r = self._closed_pnl(b.pos["ticket"])   # ปิดไปตอนระบบดับ
                if r:
                    arena._closed(b, r[0], r[1] + " (ระหว่างระบบปิด)")
                else:
                    b.pos = None
            if mine and not b.pos:
                p = mine[0]
                b.pos = {"dir": 1 if p.type == mt5.POSITION_TYPE_BUY else -1, "entry": p.price_open, "sl": p.sl,
                         "tp": p.tp, "bar0": arena.bar_i, "live": True, "ticket": p.ticket,
                         "comps": {"t": 0.0, "m": 0.0, "b": 0.0}}
                self.log("team", f"พบออเดอร์ค้าง #{p.ticket} ของ {b.tag} ใน MT5 รับกลับมาดูแลต่อ")
            for extra in mine[1:]:
                self.log("warn", f"{b.tag} มีออเดอร์ค้างเกิน 1 ตัว (#{extra.ticket}) ตรวจสอบใน MT5")
