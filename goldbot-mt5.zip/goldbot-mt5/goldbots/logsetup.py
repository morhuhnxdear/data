import logging
import os
import sys

LEVEL = {"trade": logging.INFO, "team": logging.INFO, "jail": logging.INFO, "teach": logging.DEBUG,
         "day": logging.INFO, "save": logging.INFO, "warn": logging.WARNING, "info": logging.INFO, "cmd": logging.INFO}


def setup_logging(path, console_level=logging.INFO):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    lg = logging.getLogger("goldbots")
    lg.setLevel(logging.DEBUG)
    lg.handlers.clear()
    fh = logging.FileHandler(path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    lg.addHandler(fh)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(console_level)
    ch.setFormatter(logging.Formatter("%(asctime)s %(message)s", "%H:%M:%S"))
    lg.addHandler(ch)

    def log(kind, msg):
        lg.log(LEVEL.get(kind, logging.INFO), msg)
    return log
