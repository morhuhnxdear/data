"""หัวใจของระบบ: บอท 40 ตัว ผู้คุม เขตห้ามเทรด การสอน การจัดทีม เป้ารายวัน
ใช้ร่วมกันทั้ง backtest และการเทรดจริงผ่าน MT5"""
import datetime as dt
import random
import time
from collections import deque, namedtuple

from .bots import GENE, NAMES, Bot, configure as configure_ind, fix_genome, genome_dist, stop_keys, stops
from .bots import IND
from .indicators import Series
from .teachers import TeacherRoom

Bar = namedtuple("Bar", "time open high low close spread")  # ราคา = bid, spread = ดอลลาร์
WARMUP = 70


def money(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def bar_day(t):
    return dt.datetime.fromtimestamp(int(t), dt.timezone.utc).date()


class Arena:
    def __init__(self, cfg, executor=None, log=None, notify=None, storage=None, seed=None):
        self.cfg = cfg
        configure_ind(cfg)
        self.T, self.SV, self.B, self.L = cfg["team"], cfg["supervisor"], cfg["bots"], cfg["learning"]
        self.rng = random.Random(self.B["seed"] if seed is None else seed)
        self.ex = executor
        self._user_log = log or (lambda kind, msg: print(msg))
        self.events = deque(maxlen=200)      # เหตุการณ์ล่าสุด สำหรับหน้าจอแดชบอร์ด
        self.event_seq = 0
        self.notify = notify or (lambda msg: None)
        self.storage = storage
        self.bots = [Bot(i, NAMES[i % len(NAMES)], self.rng, self.T["recent_window"])
                     for i in range(self.B["count"])]
        self.s = Series()
        self.bar_i = 0
        self.day = None
        self.day_no = 1
        self.team_today = 0.0
        self.team_total = 0.0
        self.target_hit = False
        self.halted = False
        self.manual_halt = False
        self.days_hit = 0
        self.days_done = 0
        self.history = []
        self.qualifying = False
        self.last_bar = None
        self.contract = cfg["market"]["contract_size"]
        self.spread_blocked = 0        # จำนวนแท่งวันนี้ที่ spread กว้างจนห้ามเปิดออเดอร์เงินจริง
        self._spread_warned = -10**9
        self.vol_pause_until = 0       # ผู้คุมความเสี่ยงสั่งพักออเดอร์เงินจริงถึงแท่งนี้ (ราคากระชาก)
        self.risk_blocks = 0
        self.teachers = TeacherRoom(self)
        self.sig_hist = deque(maxlen=300)    # [bar_i, คะแนนสัญญาณรวม, จุดแนะนำ 1/-1/0] สำหรับกราฟ
        self.trade_marks = deque(maxlen=200) # [bar_i, ราคา, "open"/"close", ทิศ, บอท, กำไร]
        self._sig_prev = 0.0
        self.sig_open = []                   # จุดแนะนำที่ยังติดตามผลอยู่
        self.sig_log = deque(maxlen=200)     # จุดแนะนำล่าสุด (ทั้งที่รู้ผลแล้วและยังติดตาม) สำหรับแดชบอร์ด
        self.sig_seq = 0
        self.sig_stats = {"n": 0, "tp": 0, "sl": 0, "timeout": 0, "wins": 0, "pnl": 0.0,
                          "buy_n": 0, "buy_wins": 0, "sell_n": 0, "sell_wins": 0}
        self.bars = deque(maxlen=self.teachers.window + 70)
        self.comm = cfg["market"].get("commission_per_lot", 0.0)

    def log(self, kind, msg):
        self.event_seq += 1
        self.events.append([self.event_seq, time.strftime("%H:%M:%S"), kind, msg])
        self._user_log(kind, msg)

    # ================= คะแนนและเกณฑ์ =================
    def rank_score(self, b):
        return b.today + 0.25 * b.total

    def eligible(self, b):
        wr = b.recent_wr()
        return (b.jailed is None and not b.paused and len(b.recent) >= self.T["min_trades"]
                and wr is not None and wr * 100 > self.T["min_win_rate"]
                and (not self.T["require_profit"] or b.total > 0))

    def why_not(self, b):
        wr = b.recent_wr()
        if b.jailed:
            return "ถูกขังอยู่"
        if b.paused:
            return "ถูกสั่งพัก"
        if len(b.recent) < self.T["min_trades"]:
            return f"ไม้ยังไม่พอ ({len(b.recent)}/{self.T['min_trades']})"
        if not wr * 100 > self.T["min_win_rate"]:
            return f"ชนะ {wr * 100:.0f}% ใน {len(b.recent)} ไม้ล่าสุด ต้องเกิน {self.T['min_win_rate']}%"
        if self.T["require_profit"] and b.total <= 0:
            return f"กำไรสะสมยังไม่เป็นบวก ({money(b.total)})"
        return ""

    def best_bot(self, exclude=None):
        c = [b for b in self.bots if b.jailed is None and b.id != exclude]
        return max(c, key=self.rank_score) if c else None

    def champion(self):
        c = [b for b in self.bots if b.today_trades > 0]
        return max(c, key=lambda b: b.today) if c else None

    # ================= จัดทีม =================
    def set_live(self, b, on, why):
        if b.live == on:
            return
        b.live = on
        self.log("team", f"{b.tag} {'ขึ้นทีมเทรดจริง' if on else 'ลงไปกลุ่มเรียนรู้'} ({why})")

    def select_lineup(self, why):
        ranked = sorted([b for b in self.bots if self.eligible(b)], key=self.rank_score, reverse=True)
        want = {b.id for b in ranked[:self.T["size"]]}
        for b in self.bots:
            if b.live and b.id not in want:
                self.set_live(b, False, why)
        for b in self.bots:
            if not b.live and b.id in want:
                self.set_live(b, True, why)

    def fill_lineup(self, why):
        live = [b for b in self.bots if b.live]
        free = self.T["size"] - len(live)
        if free <= 0:
            return
        cand = sorted([b for b in self.bots if not b.live and self.eligible(b)], key=self.rank_score, reverse=True)
        for b in cand[:free]:
            self.set_live(b, True, why)

    def mid_day(self):
        for b in self.bots:
            if b.live and not self.eligible(b):
                self.set_live(b, False, f"หลุดเกณฑ์: {self.why_not(b)}")
        live = [b for b in self.bots if b.live]
        cand = sorted([b for b in self.bots if not b.live and self.eligible(b)], key=self.rank_score, reverse=True)
        if live and cand:
            weak = min(live, key=self.rank_score)
            best = cand[0]
            if self.rank_score(best) > self.rank_score(weak) + 20 * self.B["lot"] / 0.01:
                self.set_live(weak, False, f"ผลงานแพ้ {best.tag}")
                self.set_live(best, True, f"ทำผลงานแซง {weak.tag}")
        self.fill_lineup("ผ่านเกณฑ์")

    # ================= ราคาและกำไร =================
    def _pnl(self, pos, exit_price, lot):
        return (exit_price - pos["entry"]) * pos["dir"] * self.contract * lot - self.comm * lot

    def paper_exit(self, b, bar):
        """ตรวจว่าออเดอร์ (จำลอง) โดน SL/TP ในแท่งนี้ไหม ถ้าโดนทั้งคู่ถือว่าโดน SL ก่อน"""
        p, sp = b.pos, bar.spread
        if p["dir"] > 0:  # ถือซื้อ ปิดที่ bid
            if bar.low <= p["sl"]:
                return p["sl"], "โดนตัดขาดทุน"
            if bar.high >= p["tp"]:
                return p["tp"], "ถึงจุดทำกำไร"
        else:             # ถือขาย ปิดที่ ask = bid + spread
            if bar.high + sp >= p["sl"]:
                return p["sl"], "โดนตัดขาดทุน"
            if bar.low + sp <= p["tp"]:
                return p["tp"], "ถึงจุดทำกำไร"
        return None

    def market_exit_price(self, pos, bar):
        return bar.close if pos["dir"] > 0 else bar.close + bar.spread

    # ================= วงจรหลัก ต่อ 1 แท่ง =================
    def step(self, bar):
        d = bar_day(bar.time)
        if self.day is None:
            self.day = d
        elif d != self.day:
            self.end_day()
            self.day = d
        self.last_bar = bar
        self.s.push(bar.close, bar.high, bar.low)
        self.bars.append(bar)
        self.bar_i += 1
        if len(self.s) < WARMUP:
            return
        self._risk_watch(bar)
        self.teachers.on_bar(bar)

        # 1) ออเดอร์เงินจริงที่ปิดไปแล้ว (โดน SL/TP ฝั่งโบรกเกอร์)
        if self.ex is not None:
            for b, pnl, reason in self.ex.poll(self, bar):
                self._closed(b, pnl, reason)
        # 2) ออเดอร์ฝึก
        for b in self.bots:
            if b.pos and not b.pos["live"]:
                r = self.paper_exit(b, bar)
                if r:
                    self._closed(b, self._pnl(b.pos, r[0], self.B["lot"]), r[1])
        # 3) ถือนานเกิน
        for b in self.bots:
            if b.pos and self.bar_i - b.pos["bar0"] >= self.SV["max_hold_bars"]:
                self.close_bot(b, "ครบเวลาถือ")
        # 4) เขตห้ามเทรด: เรียนจากครู / พ้นโทษ
        for b in self.bots:
            if b.jailed:
                if b.jailed.get("teacher") is not None:
                    self.teachers.jail_lesson(b)
                else:
                    m = self.bots[b.jailed["mentor"]] if b.jailed.get("mentor") is not None else None
                    if m:
                        for k in GENE:
                            b.g[k] += (m.g[k] - b.g[k]) * 0.02
                if self.bar_i >= b.jailed["until"]:
                    self.release(b)
        # 5) หาจังหวะเข้า
        if bar.spread > self.SV["max_spread"]:
            self.spread_blocked += 1
            if not self.qualifying and self.bar_i - self._spread_warned >= 60:
                self._spread_warned = self.bar_i
                self.log("risk", f"ผู้คุมความเสี่ยง: spread ${bar.spread:.2f} กว้างกว่าที่อนุญาต (${self.SV['max_spread']:.2f}) "
                                 f"ห้ามเปิดออเดอร์เงินจริงชั่วคราว บอทยังฝึกเทรดและเรียนรู้ต่อ")
        for b in self.bots:
            if b.pos or b.jailed or b.paused:
                continue
            t, m, bk, score, h = b.signals(self.s)
            if abs(score) >= b.g["thr"]:
                self._open(b, 1 if score > 0 else -1, (t, m, bk, h), score, bar)
        self._track_signals(bar)
        self._team_signal()
        # 6) งานเป็นรอบ
        if self.bar_i % self.L["peer_talk_every"] == 0:
            self._peer_talk()
        if self.bar_i % self.teachers.study_every == 0:
            self.teachers.study()
        if self.bar_i % self.teachers.class_every == 0 and not self.qualifying:
            self.teachers.teach_class()
        if self.bar_i % 150 == 0:
            self.mid_day()
        elif self.bar_i % 30 == 0:
            self.fill_lineup("ผ่านเกณฑ์อัตราชนะ")

    # ================= สัญญาณรวมของทีม (สำหรับกราฟ) =================
    def signal_group(self):
        """บอทที่ใช้คำนวณสัญญาณแนะนำ: ทีมเทรดจริง ถ้ายังไม่มี ใช้ 5 ตัวที่ผลงานดีที่สุด"""
        live = [b for b in self.bots if b.live]
        if live:
            return live, "ทีมเทรดจริง"
        top = sorted([b for b in self.bots if b.jailed is None], key=self.rank_score, reverse=True)
        return top[:self.T["size"]], f"บอทผลงานดีที่สุด {self.T['size']} ตัว"

    def _team_signal(self):
        grp, _ = self.signal_group()
        if not grp:
            return
        sc = sum(b.signals(self.s)[3] for b in grp) / len(grp)
        thr = sum(b.g["thr"] for b in grp) / len(grp)
        mark = 0
        if abs(sc) >= thr and abs(self._sig_prev) < thr:
            mark = 1 if sc > 0 else -1
        elif abs(sc) >= thr and self._sig_prev * sc < 0:
            mark = 1 if sc > 0 else -1
        self._sig_prev = sc
        bar = self.last_bar
        self.sig_hist.append([bar.time, round(sc, 3), mark, round(thr, 3)])
        if mark and not self.qualifying:
            self._record_signal(grp, mark, sc, thr, bar)

    # ---------- เก็บจุดแนะนำและติดตามผล ----------
    def _group_levels(self, grp, d, bar):
        L = len(self.s.c)
        ds = sorted(stops(b.g, self.s, L) for b in grp)
        sl_d, tp_d = ds[len(ds) // 2]
        entry = bar.close + bar.spread if d > 0 else bar.close
        return entry, entry - d * sl_d, entry + d * tp_d

    def _record_signal(self, grp, d, sc, thr, bar):
        entry, sl, tp = self._group_levels(grp, d, bar)
        sigs = [b.signals(self.s)[3] for b in grp]
        agree = sum(1 for b, x in zip(grp, sigs) if abs(x) >= b.g["thr"] and (x > 0) == (d > 0))
        self.sig_seq += 1
        rec = {"id": self.sig_seq, "time": bar.time, "dir": d, "entry": round(entry, 3), "sl": round(sl, 3),
               "tp": round(tp, 3), "score": round(sc, 3), "thr": round(thr, 3), "agree": agree, "group": len(grp),
               "src": self.signal_group()[1], "bar0": self.bar_i, "status": "open",
               "result": None, "exit": None, "pnl": None, "minutes": None}
        self.sig_open.append(rec)
        self.sig_log.append(rec)

    def _track_signals(self, bar):
        """ติดตามผลจุดแนะนำ: ราคาไปถึง TP หรือโดน SL ก่อน (ถ้าแตะทั้งคู่ในแท่งเดียว ถือว่าโดน SL) หรือครบเวลาถือ"""
        if not self.sig_open:
            return
        keep = []
        lot = 0.01
        for r in self.sig_open:
            if r["bar0"] == self.bar_i:
                keep.append(r)
                continue
            d, ex, res = r["dir"], None, None
            if d > 0:
                if bar.low <= r["sl"]:
                    ex, res = r["sl"], "SL"
                elif bar.high >= r["tp"]:
                    ex, res = r["tp"], "TP"
            else:
                if bar.high + bar.spread >= r["sl"]:
                    ex, res = r["sl"], "SL"
                elif bar.low + bar.spread <= r["tp"]:
                    ex, res = r["tp"], "TP"
            if ex is None and self.bar_i - r["bar0"] >= self.SV["max_hold_bars"]:
                ex, res = (bar.close if d > 0 else bar.close + bar.spread), "หมดเวลา"
            if ex is None:
                keep.append(r)
                continue
            pnl = (ex - r["entry"]) * d * self.contract * lot - self.comm * lot
            r.update(status="done", result=res, exit=round(ex, 3), pnl=round(pnl, 2),
                     minutes=self.bar_i - r["bar0"])
            st = self.sig_stats
            st["n"] += 1
            st[{"TP": "tp", "SL": "sl"}.get(res, "timeout")] += 1
            st["wins"] += pnl > 0
            st["pnl"] = round(st["pnl"] + pnl, 2)
            side = "buy" if d > 0 else "sell"
            st[side + "_n"] += 1
            st[side + "_wins"] += pnl > 0
            if self.storage:
                self.storage.log_signal({
                    "id": r["id"], "time_server": dt.datetime.fromtimestamp(r["time"], dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
                    "direction": "ซื้อ" if d > 0 else "ขาย", "entry": r["entry"], "sl": r["sl"], "tp": r["tp"],
                    "score": r["score"], "threshold": r["thr"], "agree": f"{r['agree']}/{r['group']}", "source": r["src"],
                    "result": res, "exit": r["exit"], "pnl_per_0.01lot": r["pnl"], "minutes": r["minutes"]})
        self.sig_open = keep

    def signal_now(self):
        """สัญญาณตอนนี้: ทิศ ความแรง จำนวนบอทที่เห็นด้วย และระดับ SL/TP ที่สูตรของทีมจะตั้ง"""
        L = len(self.s.c)
        lb = self.last_bar
        if lb is None or L < WARMUP:
            return None
        grp, src = self.signal_group()
        if not grp:
            return None
        sigs = [b.signals(self.s) for b in grp]
        sc = sum(x[3] for x in sigs) / len(sigs)
        thr = sum(b.g["thr"] for b in grp) / len(grp)
        d = 1 if sc > 0 else -1
        agree = sum(1 for b, x in zip(grp, sigs) if abs(x[3]) >= b.g["thr"] and (x[3] > 0) == (d > 0))
        buy = sell = 0
        for b in self.bots:
            if b.jailed:
                continue
            x = b.signals(self.s)[3]
            if abs(x) >= b.g["thr"]:
                buy += x > 0
                sell += x < 0
        comp = {"t": 0.0, "m": 0.0, "b": 0.0}
        for b, x in zip(grp, sigs):
            W = b.g["wT"] + b.g["wM"] + b.g["wB"]
            comp["t"] += b.g["wT"] * x[0] * d / W
            comp["m"] += b.g["wM"] * x[1] * d / W
            comp["b"] += b.g["wB"] * x[2] * d / W
        entry, sl, tp = self._group_levels(grp, d, lb)
        return {"score": round(sc, 3), "thr": round(thr, 3), "dir": d, "active": abs(sc) >= thr, "src": src,
                "group": len(grp), "agree": agree, "buy": buy, "sell": sell,
                "neutral": sum(1 for b in self.bots if not b.jailed) - buy - sell,
                "comp": {k: round(v / len(grp), 3) for k, v in comp.items()},
                "htf": sum(x[4] for x in sigs), "entry": round(entry, 3),
                "sl": round(sl, 3), "tp": round(tp, 3)}

    # ================= เปิด/ปิดออเดอร์ =================
    def live_allowed(self):
        return (self.ex is not None and not self.qualifying and not self.halted and not self.manual_halt
                and not (self.target_hit and self.T["stop_at_target"]) and self.bar_i >= self.vol_pause_until)

    # ================= ผู้คุมคนที่ 2: ผู้คุมความเสี่ยง =================
    def _risk_watch(self, bar):
        """ดูแลความเสี่ยงของเงินจริงทั้งพอร์ต: ราคากระชากผิดปกติ, spread, ออเดอร์ในโบรกเกอร์ที่ไม่มี SL"""
        n = 60
        if len(self.bars) > n:
            rs = [x.high - x.low for x in list(self.bars)[-n - 1:-1]]
            avg = sum(rs) / n
            rng = bar.high - bar.low
            mult = self.SV.get("vol_spike_mult", 4.0)
            if avg > 0 and rng > mult * avg and self.bar_i >= self.vol_pause_until:
                self.vol_pause_until = self.bar_i + int(self.SV.get("vol_pause_bars", 15))
                self.risk_blocks += 1
                if not self.qualifying:
                    self.log("risk", f"ผู้คุมความเสี่ยง: ราคากระชากแรง (แท่งนี้วิ่ง ${rng:.2f} ปกติ ${avg:.2f}) "
                                     f"พักเปิดออเดอร์เงินจริง {self.SV.get('vol_pause_bars', 15)} นาที ออเดอร์ที่ถืออยู่ยังมี SL คุม")
        if self.ex is not None and not self.qualifying and hasattr(self.ex, "audit"):
            for msg in self.ex.audit(self):
                self.log("risk", "ผู้คุมความเสี่ยง: " + msg)

    def _open(self, b, d, comps, score, bar):
        lot = self.B["lot"]
        # ผู้คุมตรวจก่อนส่งทุกออเดอร์
        if lot > self.B["max_lot"] or abs(score) < b.g["thr"]:
            self.jail(b, "ออเดอร์ไม่ตรงสูตร")
            return
        sl_d, tp_d = stops(b.g, self.s, len(self.s.c))
        pos = {"dir": d, "bar0": self.bar_i, "live": False, "ticket": None,
               "comps": {"t": comps[0] * d, "m": comps[1] * d, "b": comps[2] * d, "h": comps[3] * d}}
        if b.live and self.live_allowed() and bar.spread <= self.SV["max_spread"]:
            res = self.ex.open(self, b, d, lot, sl_d, tp_d, bar)
            if not res:
                return
            pos.update(entry=res["entry"], sl=res["sl"], tp=res["tp"], ticket=res["ticket"], live=True)
            self.trade_marks.append([bar.time, round(res["entry"], 3), "open", d, b.id, None])
            self.log("trade", f"{b.tag} เปิด{'ซื้อ' if d > 0 else 'ขาย'} (เงินจริง) {lot} ล็อต ที่ {res['entry']:.2f} "
                              f"SL {res['sl']:.2f} TP {res['tp']:.2f}")
        else:
            entry = bar.close + bar.spread if d > 0 else bar.close
            pos.update(entry=entry, sl=entry - d * sl_d, tp=entry + d * tp_d)
        b.pos = pos

    def close_bot(self, b, reason):
        if not b.pos:
            return True
        if b.pos["live"]:
            pnl = self.ex.close(self, b, self.last_bar) if self.ex else None
            if pnl is None:
                self.log("warn", f"ปิดออเดอร์ของ {b.tag} ไม่สำเร็จ จะลองใหม่รอบหน้า")
                return False
        else:
            pnl = self._pnl(b.pos, self.market_exit_price(b.pos, self.last_bar), self.B["lot"])
        self._closed(b, pnl, reason)
        return True

    def _closed(self, b, pnl, reason):
        pos = b.pos
        if pos is None:
            return
        b.pos = None
        win = pnl > 0
        b.today += pnl
        b.total += pnl
        b.trades += 1
        b.today_trades += 1
        b.recent.append(1 if win else 0)
        if win:
            b.wins += 1
            b.today_wins += 1
            b.consec_losses = 0
        else:
            b.consec_losses += 1
        self._learn(b, pos, pnl)
        if pos["live"]:
            b.live_today += pnl
            b.live_total += pnl
            b.live_trades += 1
            b.live_wins += 1 if win else 0
            self.team_today += pnl
            self.team_total += pnl
            lb = self.last_bar
            if lb is not None:
                self.trade_marks.append([lb.time, round(lb.close, 3), "close", pos["dir"], b.id, round(pnl, 2)])
            self.log("trade", f"{b.tag} ปิดออเดอร์เงินจริง {reason} {money(pnl)} | ทีมวันนี้ {money(self.team_today)}")
        if self.storage:
            self.storage.log_trade({"day": str(self.day), "bar": self.bar_i, "bot": b.id + 1, "name": b.name,
                                    "live": int(pos["live"]), "dir": pos["dir"], "entry": round(pos["entry"], 3),
                                    "pnl": round(pnl, 2), "reason": reason})
        # ผู้คุม
        if b.consec_losses >= self.SV["max_consecutive_losses"]:
            self.jail(b, f"แพ้ติดกัน {b.consec_losses} ไม้ ผิดไปจากสูตร")
        elif b.today < -self.SV["bot_daily_loss_limit"]:
            self.jail(b, f"ขาดทุนวันนี้ {money(b.today)} เกินเพดาน")
        elif b.live and not self.eligible(b):
            self.set_live(b, False, f"หลุดเกณฑ์: {self.why_not(b)}")
            self.fill_lineup(f"แทนที่ {b.tag}")
        # เป้า / เพดานขาดทุนของทีม
        if pos["live"]:
            if not self.target_hit and self.team_today >= self.T["daily_target"]:
                self.target_hit = True
                msg = f"ทีมเทรดจริงถึงเป้า {money(self.T['daily_target'])} แล้ว ({money(self.team_today)})"
                if self.T["stop_at_target"]:
                    msg += " ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน"
                    self.log("day", msg)
                    self.notify(msg)
                    self.close_all_live("ถึงเป้า ปิดเก็บกำไร")
                else:
                    self.log("day", msg)
                    self.notify(msg)
            if not self.halted and self.team_today <= -self.T["max_daily_loss"]:
                self.halted = True
                msg = f"ผู้คุมความเสี่ยง: ทีมขาดทุนวันนี้ {money(self.team_today)} ถึงเพดาน ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน"
                self.log("risk", msg)
                self.notify(msg)
                self.close_all_live("ถึงเพดานขาดทุนทีม")

    def close_all_live(self, reason):
        for b in self.bots:
            if b.pos and b.pos["live"]:
                self.close_bot(b, reason)

    def _learn(self, b, pos, pnl):
        b.learn_count += 1
        b.learn_today += 1
        s = 1 if pnl > 0 else -1
        lr, g = b.g["lr"], b.g
        g["wT"] += lr * s * pos["comps"]["t"]
        g["wM"] += lr * s * pos["comps"]["m"]
        g["wB"] += lr * s * pos["comps"]["b"]
        g["thr"] += -0.004 if s > 0 else 0.008
        wr, goal = b.recent_wr(), self.T["min_win_rate"] / 100
        SL, TP = stop_keys()
        if wr is not None and wr <= goal:
            g[TP] *= 0.93 if s < 0 else 0.99
            if s < 0:
                g[SL] *= 1.02
        elif wr is not None and wr > goal + 0.05 and s > 0:
            g[TP] *= 1.01
        # เรียนรู้ว่าควรเคารพเทรนด์ใหญ่แค่ไหน
        h = pos["comps"].get("h", 0)
        if h < 0:                        # ไม้นี้เทรดสวนเทรนด์ใหญ่
            g["htfW"] += 0.05 if s < 0 else -0.03
        elif h > 0 and s > 0:            # ตามเทรนด์ใหญ่แล้วชนะ
            g["htfW"] += 0.01
        fix_genome(g)

    # ================= ผู้คุม / เขตห้ามเทรด =================
    def jail(self, b, reason, by_user=False):
        if b.jailed:
            return False
        if b.pos and not self.close_bot(b, "ผู้คุมปิดออเดอร์"):
            return False
        if b.jailed:       # ถูกขังระหว่างปิดออเดอร์ไปแล้ว
            return True
        t = self.teachers.best()
        m = None if t else self.best_bot(b.id)
        b.jailed = {"until": self.bar_i + self.SV["jail_bars"], "mentor": m.id if m else None,
                    "teacher": t.id if t else None, "reason": reason}
        b.violations += 1
        was_live = b.live
        b.live = False
        self.log("jail", f"{'สั่งขัง' if by_user else 'ผู้คุมวินัยจับ'} {b.tag}{' (ถูกถอดจากทีมเทรดจริง)' if was_live else ''}"
                         f" เข้าเขตห้ามเทรด: {reason}" + (f" ส่งไปเรียนกับ{t.name}" if t else f" ส่งไปเรียนกับ {m.tag}" if m else ""))
        if was_live:
            self.notify(f"ผู้คุมวินัยจับ {b.tag} ออกจากทีมเทรดจริง: {reason}")
            self.fill_lineup(f"แทนที่ {b.tag}")
        return True

    def release(self, b, by_user=False):
        if not b.jailed:
            return False
        b.jailed = None
        b.consec_losses = 0
        self.log("teach", f"{b.tag} {'ถูกปล่อยก่อนกำหนด' if by_user else 'พ้นเขตห้ามเทรด'}")
        return True

    def teach(self, m, s, rate, why):
        for k, (lo, hi) in GENE.items():
            s.g[k] += (m.g[k] - s.g[k]) * rate + self.rng.gauss(0, 0.02) * (hi - lo)
        fix_genome(s.g)
        s.taught += 1
        self.log("teach", f"{m.tag} สอนสูตรให้ {s.tag} ({why})")

    def _peer_talk(self):
        """บอทกลุ่มเรียนรู้เดินไปคุยกับตัวอื่น ถ้าอีกฝ่ายเก่งกว่าก็ได้เคล็ดลับกลับมา"""
        for b in self.bots:
            if b.live or b.jailed or b.paused or self.rng.random() > 0.3:
                continue
            others = [o for o in self.bots if o is not b and o.jailed is None]
            if not others:
                continue
            p = self.rng.choice(others)
            b.chats += 1
            if self.rank_score(p) > self.rank_score(b):
                # เรียนแค่บางส่วน และคิดต่อยอดเองเล็กน้อย เพื่อไม่ให้ทุกตัวกลายเป็นสูตรเดียวกันหมด
                for k, (lo, hi) in GENE.items():
                    b.g[k] += (p.g[k] - b.g[k]) * 0.01 + self.rng.gauss(0, 0.005) * (hi - lo)
                fix_genome(b.g)
                b.tips += 1

    # ================= สิ้นวัน =================
    def end_day(self):
        ranked = sorted(self.bots, key=lambda b: b.today, reverse=True)
        champ = ranked[0]
        hit = self.team_today >= self.T["daily_target"]
        live_names = ", ".join(f"{b.id + 1:02d}" for b in self.bots if b.live) or "-"
        if not self.qualifying:
            self.days_done += 1
            self.days_hit += 1 if hit else 0
            row = {"day": str(self.day), "team_pnl": round(self.team_today, 2), "hit_target": int(hit),
                   "halted": int(self.halted), "champion": champ.id + 1, "champion_pnl": round(champ.today, 2),
                   "live_bots": live_names}
            self.history.append(row)
            if self.storage:
                self.storage.log_day(row)
            msg = (f"จบวัน {self.day}: ทีมเทรดจริง {money(self.team_today)} "
                   f"{'ถึงเป้า' if hit else 'ไม่ถึงเป้า'} {money(self.T['daily_target'])} | "
                   f"แชมป์ {champ.tag} {money(champ.today)} | ถึงเป้า {self.days_hit}/{self.days_done} วัน")
            self.log("day", msg)
            self.notify(msg)
        if not self.qualifying:
            self.teachers.study()
            self.teachers.teach_class("คาบเรียนหลังจบวัน")
        if self.L["autosave_champion"] and champ.total > 0 and self.storage and not self.qualifying:
            self.save_strategy(champ, auto=True)
        for b in self.bots:
            b.today = 0.0
            b.today_trades = 0
            b.today_wins = 0
            b.live_today = 0.0
            b.learn_today = 0
        self.team_today = 0.0
        self.spread_blocked = 0
        self.risk_blocks = 0
        self.target_hit = False
        self.halted = False
        self.day_no += 1
        self.select_lineup("จัดทีมใหม่ตามผลงาน")

    def save_strategy(self, b, auto=False):
        if b.total <= 0:
            return f"{b.tag} ยังไม่มีกำไรสะสม ({money(b.total)}) จึงยังเซฟสูตรไม่ได้"
        wr = b.recent_wr()
        doc = {"name": f"สูตร{b.name} {self.day}", "bot": b.id + 1, "genome": {k: round(v, 4) for k, v in b.g.items()},
               "total": round(b.total, 2), "recent_win_rate": round((wr or 0) * 100, 1), "trades": b.trades,
               "day": str(self.day)}
        if self.storage:
            self.storage.save_strategy(doc)
        self.log("save", f"{'เซฟอัตโนมัติ' if auto else 'เซฟ'}สูตรของ {b.tag} กำไรสะสม {money(b.total)}")
        return f"เซฟสูตรของ {b.tag} แล้ว"

    # ================= เริ่มระบบ =================
    def qualify(self, bars):
        """รอบคัดเลือก: ทุกตัวฝึกเทรดกับข้อมูลย้อนหลัง แล้วเลือกตัวที่ผ่านเกณฑ์ขึ้นทีม"""
        self.qualifying = True
        for bar in bars:
            self.step(bar)
        for b in self.bots:     # ออเดอร์ฝึกที่ค้าง ปิดทิ้ง
            if b.pos and not b.pos["live"]:
                b.pos = None
            b.today = 0.0
            b.today_trades = 0
            b.today_wins = 0
        self.qualifying = False
        self.select_lineup("ผลงานรอบคัดเลือก")
        n = sum(b.live for b in self.bots)
        self.log("team", f"รอบคัดเลือกจบ มีบอทผ่านเกณฑ์ขึ้นทีม {n} ตัว" +
                 ("" if n else " ทีมเทรดจริงจะว่างจนกว่าจะมีตัวผ่านเกณฑ์"))

    def preload(self, bars):
        """ใช้ตอนเปิดระบบใหม่หลังจากเคยรันแล้ว: ใส่ราคาย้อนหลังโดยไม่เทรด"""
        for bar in bars:
            self.s.push(bar.close, bar.high, bar.low)
            self.bars.append(bar)
            self.last_bar = bar
        if self.day is None and bars:
            self.day = bar_day(bars[-1].time)

    # ================= บันทึก/โหลดสถานะ =================
    def to_state(self):
        return {"bar_i": self.bar_i, "day": str(self.day) if self.day else None, "day_no": self.day_no,
                "team_today": self.team_today, "team_total": self.team_total, "target_hit": self.target_hit,
                "halted": self.halted, "manual_halt": self.manual_halt, "days_hit": self.days_hit,
                "days_done": self.days_done, "bots": [b.to_dict() for b in self.bots],
                "teachers": self.teachers.to_state(),
                "signals": {"hist": list(self.sig_hist), "marks": list(self.trade_marks), "log": list(self.sig_log),
                            "open_ids": [r["id"] for r in self.sig_open], "seq": self.sig_seq, "stats": self.sig_stats},
                "dash": self.dash_info()}

    def dash_info(self):
        c = self.champion()
        lb = self.last_bar
        L = len(self.s.c)
        return {"price": lb.close if lb else None, "spread": lb.spread if lb else None,
                "atr": round(self.s.atr_at(int(IND["atr_period"]), L), 3) if L > 2 else None,
                "htf": ({"hours": 24, "dir": (1 if self.s.c[-1] > self.s.sma_at(1440, L) else -1)} if L > 1440 else None),
                "ind": {"atr_stops": bool(IND["atr_stops"]), "htf_filter": bool(IND["htf_filter"])},
                "bar_i": self.bar_i,
                "times": [b.time for b in list(self.bars)[-min(240, L):]],
                "sig": {"hist": list(self.sig_hist)[-240:], "marks": list(self.trade_marks)[-80:],
                        "now": self.signal_now(), "log": list(self.sig_log)[-40:], "stats": self.sig_stats},
                "bar_time": lb.time if lb else None, "prices": [round(x, 3) for x in self.s.c[-240:]],
                "events": list(self.events)[-120:], "history": self.history[-10:],
                "team": {k: self.T[k] for k in ("size", "min_win_rate", "recent_window", "min_trades",
                                                 "require_profit", "daily_target", "stop_at_target",
                                                 "max_daily_loss")},
                "elig": {str(b.id): [self.eligible(b), self.why_not(b)] for b in self.bots},
                "champion": c.id if c else None, "qualifying": self.qualifying,
                "jail_bars": self.SV["jail_bars"], "max_spread": self.SV["max_spread"],
                "spread_blocked": self.spread_blocked,
                "learn_today": sum(b.learn_today for b in self.bots),
                "learn_total": sum(b.learn_count for b in self.bots),
                "teachers": [t.to_dict() for t in self.teachers.teachers],
                "lessons": self.teachers.lessons[-40:],
                "risk": {"vol_pause": max(0, self.vol_pause_until - self.bar_i),
                         "spread_block": bool(lb and lb.spread > self.SV["max_spread"]),
                         "halted": self.halted, "blocks_today": self.risk_blocks}}

    def load_state(self, st):
        for k in ["bar_i", "day_no", "team_today", "team_total", "target_hit", "halted", "manual_halt",
                  "days_hit", "days_done"]:
            if k in st:
                setattr(self, k, st[k])
        if st.get("day"):
            self.day = dt.date.fromisoformat(st["day"])
        if st.get("teachers"):
            self.teachers.load_state(st["teachers"])
        sg = st.get("signals")
        if sg:
            self.sig_hist.extend(x for x in sg.get("hist", []) if x and x[0] > 10 ** 8)
            self.trade_marks.extend(x for x in sg.get("marks", []) if x and x[0] > 10 ** 8)
            self.sig_log.extend(sg.get("log", []))
            ids = set(sg.get("open_ids", []))
            old_bar = st.get("bar_i", self.bar_i)
            for r in self.sig_log:
                if r["id"] in ids:
                    r["bar0"] = self.bar_i - max(0, old_bar - r["bar0"])
                    self.sig_open.append(r)
            self.sig_seq = sg.get("seq", 0)
            self.sig_stats.update(sg.get("stats", {}))
        by_id = {d["id"]: d for d in st.get("bots", [])}
        for b in self.bots:
            if b.id in by_id:
                b.load_dict(by_id[b.id])
        # bar0 ของออเดอร์เดิม อ้างอิงตัวนับแท่งเดิม ให้เริ่มนับใหม่
        for b in self.bots:
            if b.pos:
                b.pos["bar0"] = self.bar_i
            if b.jailed:
                b.jailed["until"] = self.bar_i + max(0, b.jailed["until"] - st.get("bar_i", self.bar_i))

    # ================= สรุป / คำสั่ง =================
    def status_text(self):
        live = [b for b in self.bots if b.live]
        lines = [f"วันที่ {self.day} ทีมเทรดจริงวันนี้ {money(self.team_today)} / เป้า {money(self.T['daily_target'])}"
                 f" สะสม {money(self.team_total)}" + (" [ถึงเป้าแล้ว]" if self.target_hit else "")
                 + (" [หยุดเพราะถึงเพดานขาดทุน]" if self.halted else "") + (" [หยุดเทรดจริงตามคำสั่ง]" if self.manual_halt else ""),
                 f"ทีมเทรดจริง {len(live)}/{self.T['size']}: " + (", ".join(b.tag for b in live) or "ว่าง")]
        for b in sorted(self.bots, key=lambda x: (x.recent_wr() or -1), reverse=True):
            wr = b.recent_wr()
            state = "ถูกขัง" if b.jailed else "เทรดจริง" if b.live else "พัก" if b.paused else "เรียนรู้"
            lines.append(f"  {b.id + 1:02d} {b.name:<8} {state:<8} ชนะล่าสุด {('%.0f%%' % (wr * 100)) if wr is not None else '-':>5}"
                         f" ({sum(b.recent)}/{len(b.recent)})  วันนี้ {money(b.today):>10}  สะสม {money(b.total):>10}"
                         + ("  ✓" if self.eligible(b) else ""))
        return "\n".join(lines)

    def command(self, line):
        """คำสั่งควบคุม เช่น  pause 5 | resume 5 | jail 5 | release 5 | close 5 | teach 3 12 | save 5 |
        promote 5 | demote 5 | lineup | target 150 | minwr 85 | halt | unhalt | status"""
        parts = line.strip().split()
        if not parts:
            return ""
        cmd, args = parts[0].lower(), parts[1:]

        def bot(i=0):
            try:
                n = int(args[i])
            except (IndexError, ValueError):
                raise ValueError("ต้องระบุหมายเลขบอท 1-%d" % len(self.bots))
            if not 1 <= n <= len(self.bots):
                raise ValueError("ไม่มีบอทหมายเลข %d" % n)
            return self.bots[n - 1]
        try:
            if cmd == "status":
                return self.status_text()
            if cmd == "teachers":
                lines = []
                for t in self.teachers.teachers:
                    r = t.result or {}
                    lines.append(f"{t.name} วิชา{t.subject} [{'กำลังคิดสูตรใหม่' if t.mode == 'thinking' else 'พร้อมสอน'}] ลองเทรด {sum(x.trades for x in t.slots)} ไม้: ศึกษา {t.studies} รอบ เจอสูตรดีขึ้น {t.improved} ครั้ง สอนไป {t.taught} ครั้ง"
                                 + (f" | ผลทดสอบล่าสุด กำไร {money(r['pnl'])} ชนะ {r['wr'] * 100:.0f}% ({r['trades']} ไม้)"
                                    if r.get("wr") is not None else " | ยังไม่มีผลทดสอบ"))
                return "\n".join(lines)
            if cmd == "study":
                self.teachers.study()
                return "ครูทั้ง 5 คนทดสอบสูตรกับราคาย้อนหลังแล้ว"
            if cmd in ("tteach", "tthink"):
                who = int(args[0]) if args else 0
                if not 0 <= who <= len(self.teachers.teachers):
                    return "ครูมีหมายเลข 1-5 (0 = ครูทุกคน)"
                if cmd == "tteach":
                    n = self.teachers.order_teach(who)
                    return (("ครูทุกคน" if who == 0 else self.teachers.teachers[who - 1].name) +
                            f" เดินสอนแล้ว สอนบอทไป {n} ตัว" + ("" if n else " (สูตรของครูยังไม่ช่วยให้บอทตัวไหนดีขึ้นตอนนี้)"))
                names = self.teachers.order_think(who)
                return ", ".join(names) + f" กลับห้องครูไปคิดและลองเทรดสูตรใหม่แล้ว (นานสุด {self.teachers.think_bars} นาที)"
            if cmd == "class":
                n = self.teachers.teach_class("สั่งเปิดคาบเรียน")
                return f"เปิดคาบเรียนแล้ว ครูสอนบอทไป {n} ตัว" + ("" if n else " (ไม่มีสูตรของครูที่ทดสอบแล้วช่วยให้บอทตัวไหนดีขึ้นในตอนนี้)")
            if cmd == "lineup":
                self.select_lineup("สั่งจัดทีมใหม่")
                return "จัดทีมแล้ว: " + (", ".join(b.tag for b in self.bots if b.live) or "ยังไม่มีตัวผ่านเกณฑ์")
            if cmd == "target":
                self.T["daily_target"] = float(args[0])
                return f"ตั้งเป้ากำไรทีมเป็น {money(self.T['daily_target'])} ต่อวัน"
            if cmd == "minwr":
                v = float(args[0])
                if not 50 <= v <= 99:
                    return "เกณฑ์อัตราชนะต้องอยู่ระหว่าง 50 ถึง 99"
                self.T["min_win_rate"] = v
                self.mid_day()
                return f"ตั้งเกณฑ์ชนะเกิน {v:.0f}% แล้ว ผ่านเกณฑ์ {sum(self.eligible(b) for b in self.bots)} ตัว"
            if cmd == "halt":
                self.manual_halt = True
                self.close_all_live("หยุดตามคำสั่ง")
                return "ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงแล้ว (บอทยังฝึกต่อ) พิมพ์ unhalt เพื่อกลับมาเทรด"
            if cmd == "unhalt":
                self.manual_halt = False
                return "กลับมาเทรดจริงแล้ว"
            if cmd == "pause":
                b = bot()
                b.paused = True
                if b.live:
                    self.set_live(b, False, "ถูกสั่งพัก")
                    self.fill_lineup(f"แทนที่ {b.tag}")
                return f"สั่งพัก {b.tag} แล้ว (ออเดอร์ที่ค้างยังมี SL/TP คุมอยู่)"
            if cmd == "resume":
                b = bot()
                b.paused = False
                return f"{b.tag} กลับมาเทรดแล้ว"
            if cmd == "jail":
                b = bot()
                return f"ขัง {b.tag} แล้ว" if self.jail(b, "ผู้ใช้สั่งขัง", by_user=True) else f"{b.tag} ถูกขังอยู่แล้ว"
            if cmd == "release":
                b = bot()
                return f"ปล่อย {b.tag} แล้ว" if self.release(b, by_user=True) else f"{b.tag} ไม่ได้ถูกขัง"
            if cmd == "close":
                b = bot()
                if not b.pos:
                    return f"{b.tag} ไม่มีออเดอร์ค้าง"
                return f"ปิดออเดอร์ {b.tag} แล้ว" if self.close_bot(b, "ปิดตามคำสั่ง") else "ปิดไม่สำเร็จ"
            if cmd == "teach":
                m, s = bot(0), bot(1)
                if m is s:
                    return "บอทสอนตัวเองไม่ได้"
                self.teach(m, s, 0.4, "สั่งจากผู้ใช้")
                return f"{m.tag} สอน {s.tag} แล้ว"
            if cmd == "save":
                return self.save_strategy(bot())
            if cmd == "promote":
                b = bot()
                if b.live:
                    return f"{b.tag} อยู่ในทีมแล้ว"
                if not self.eligible(b):
                    return f"{b.tag} ยังขึ้นทีมไม่ได้: {self.why_not(b)}"
                live = [x for x in self.bots if x.live]
                if len(live) >= self.T["size"]:
                    w = min(live, key=self.rank_score)
                    self.set_live(w, False, f"เปิดที่ให้ {b.tag}")
                self.set_live(b, True, "สั่งจากผู้ใช้")
                return f"{b.tag} ขึ้นทีมเทรดจริงแล้ว"
            if cmd == "demote":
                b = bot()
                if not b.live:
                    return f"{b.tag} อยู่ในกลุ่มเรียนรู้อยู่แล้ว"
                b.paused = True
                self.set_live(b, False, "สั่งจากผู้ใช้")
                self.fill_lineup(f"แทนที่ {b.tag}")
                b.paused = False
                return f"ถอน {b.tag} ไปกลุ่มเรียนรู้แล้ว"
        except (ValueError, IndexError) as e:
            return f"คำสั่งไม่ถูกต้อง: {e}"
        return "ไม่รู้จักคำสั่งนี้ ดูรายการคำสั่งใน README"
