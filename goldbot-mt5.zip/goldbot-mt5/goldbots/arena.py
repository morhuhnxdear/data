"""หัวใจของระบบ: บอท 20 ตัว ผู้คุม เขตห้ามเทรด การสอน การจัดทีม เป้ารายวัน
ใช้ร่วมกันทั้ง backtest และการเทรดจริงผ่าน MT5"""
import datetime as dt
import random
import time
from collections import deque, namedtuple

from .bots import GENE, NAMES, Bot, fix_genome, genome_dist
from .indicators import Series

Bar = namedtuple("Bar", "time open high low close spread")  # ราคา = bid, spread = ดอลลาร์
WARMUP = 70


def money(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def bar_day(t):
    return dt.datetime.fromtimestamp(int(t), dt.timezone.utc).date()


class Arena:
    def __init__(self, cfg, executor=None, log=None, notify=None, storage=None, seed=None):
        self.cfg = cfg
        self.T, self.SV, self.B, self.L = cfg["team"], cfg["supervisor"], cfg["bots"], cfg["learning"]
        self.rng = random.Random(self.B["seed"] if seed is None else seed)
        self.ex = executor
        self._user_log = log or (lambda kind, msg: print(msg))
        self.events = deque(maxlen=200)      # เหตุการณ์ล่าสุด สำหรับหน้าจอแดชบอร์ด
        self.event_seq = 0
        self.notify = notify or (lambda msg: None)
        self.storage = storage
        self.bots = [Bot(i, NAMES[i % len(NAMES)], self.rng, self.T["recent_window"])
                     for i in range(self.B["count"])]
        self.s = Series()
        self.bar_i = 0
        self.day = None
        self.day_no = 1
        self.team_today = 0.0
        self.team_total = 0.0
        self.target_hit = False
        self.halted = False
        self.manual_halt = False
        self.days_hit = 0
        self.days_done = 0
        self.history = []
        self.qualifying = False
        self.last_bar = None
        self.contract = cfg["market"]["contract_size"]
        self.comm = cfg["market"].get("commission_per_lot", 0.0)

    def log(self, kind, msg):
        self.event_seq += 1
        self.events.append([self.event_seq, time.strftime("%H:%M:%S"), kind, msg])
        self._user_log(kind, msg)

    # ================= คะแนนและเกณฑ์ =================
    def rank_score(self, b):
        return b.today + 0.25 * b.total

    def eligible(self, b):
        wr = b.recent_wr()
        return (b.jailed is None and not b.paused and len(b.recent) >= self.T["min_trades"]
                and wr is not None and wr * 100 > self.T["min_win_rate"]
                and (not self.T["require_profit"] or b.total > 0))

    def why_not(self, b):
        wr = b.recent_wr()
        if b.jailed:
            return "ถูกขังอยู่"
        if b.paused:
            return "ถูกสั่งพัก"
        if len(b.recent) < self.T["min_trades"]:
            return f"ไม้ยังไม่พอ ({len(b.recent)}/{self.T['min_trades']})"
        if not wr * 100 > self.T["min_win_rate"]:
            return f"ชนะ {wr * 100:.0f}% ใน {len(b.recent)} ไม้ล่าสุด ต้องเกิน {self.T['min_win_rate']}%"
        if self.T["require_profit"] and b.total <= 0:
            return f"กำไรสะสมยังไม่เป็นบวก ({money(b.total)})"
        return ""

    def best_bot(self, exclude=None):
        c = [b for b in self.bots if b.jailed is None and b.id != exclude]
        return max(c, key=self.rank_score) if c else None

    def champion(self):
        c = [b for b in self.bots if b.today_trades > 0]
        return max(c, key=lambda b: b.today) if c else None

    # ================= จัดทีม =================
    def set_live(self, b, on, why):
        if b.live == on:
            return
        b.live = on
        self.log("team", f"{b.tag} {'ขึ้นทีมเทรดจริง' if on else 'ลงไปกลุ่มเรียนรู้'} ({why})")

    def select_lineup(self, why):
        ranked = sorted([b for b in self.bots if self.eligible(b)], key=self.rank_score, reverse=True)
        want = {b.id for b in ranked[:self.T["size"]]}
        for b in self.bots:
            if b.live and b.id not in want:
                self.set_live(b, False, why)
        for b in self.bots:
            if not b.live and b.id in want:
                self.set_live(b, True, why)

    def fill_lineup(self, why):
        live = [b for b in self.bots if b.live]
        free = self.T["size"] - len(live)
        if free <= 0:
            return
        cand = sorted([b for b in self.bots if not b.live and self.eligible(b)], key=self.rank_score, reverse=True)
        for b in cand[:free]:
            self.set_live(b, True, why)

    def mid_day(self):
        for b in self.bots:
            if b.live and not self.eligible(b):
                self.set_live(b, False, f"หลุดเกณฑ์: {self.why_not(b)}")
        live = [b for b in self.bots if b.live]
        cand = sorted([b for b in self.bots if not b.live and self.eligible(b)], key=self.rank_score, reverse=True)
        if live and cand:
            weak = min(live, key=self.rank_score)
            best = cand[0]
            if self.rank_score(best) > self.rank_score(weak) + 20 * self.B["lot"] / 0.01:
                self.set_live(weak, False, f"ผลงานแพ้ {best.tag}")
                self.set_live(best, True, f"ทำผลงานแซง {weak.tag}")
        self.fill_lineup("ผ่านเกณฑ์")

    # ================= ราคาและกำไร =================
    def _pnl(self, pos, exit_price, lot):
        return (exit_price - pos["entry"]) * pos["dir"] * self.contract * lot - self.comm * lot

    def paper_exit(self, b, bar):
        """ตรวจว่าออเดอร์ (จำลอง) โดน SL/TP ในแท่งนี้ไหม ถ้าโดนทั้งคู่ถือว่าโดน SL ก่อน"""
        p, sp = b.pos, bar.spread
        if p["dir"] > 0:  # ถือซื้อ ปิดที่ bid
            if bar.low <= p["sl"]:
                return p["sl"], "โดนตัดขาดทุน"
            if bar.high >= p["tp"]:
                return p["tp"], "ถึงจุดทำกำไร"
        else:             # ถือขาย ปิดที่ ask = bid + spread
            if bar.high + sp >= p["sl"]:
                return p["sl"], "โดนตัดขาดทุน"
            if bar.low + sp <= p["tp"]:
                return p["tp"], "ถึงจุดทำกำไร"
        return None

    def market_exit_price(self, pos, bar):
        return bar.close if pos["dir"] > 0 else bar.close + bar.spread

    # ================= วงจรหลัก ต่อ 1 แท่ง =================
    def step(self, bar):
        d = bar_day(bar.time)
        if self.day is None:
            self.day = d
        elif d != self.day:
            self.end_day()
            self.day = d
        self.last_bar = bar
        self.s.push(bar.close)
        self.bar_i += 1
        if len(self.s) < WARMUP:
            return

        # 1) ออเดอร์เงินจริงที่ปิดไปแล้ว (โดน SL/TP ฝั่งโบรกเกอร์)
        if self.ex is not None:
            for b, pnl, reason in self.ex.poll(self, bar):
                self._closed(b, pnl, reason)
        # 2) ออเดอร์ฝึก
        for b in self.bots:
            if b.pos and not b.pos["live"]:
                r = self.paper_exit(b, bar)
                if r:
                    self._closed(b, self._pnl(b.pos, r[0], self.B["lot"]), r[1])
        # 3) ถือนานเกิน
        for b in self.bots:
            if b.pos and self.bar_i - b.pos["bar0"] >= self.SV["max_hold_bars"]:
                self.close_bot(b, "ครบเวลาถือ")
        # 4) เขตห้ามเทรด: เรียนจากครู / พ้นโทษ
        for b in self.bots:
            if b.jailed:
                m = self.bots[b.jailed["mentor"]] if b.jailed.get("mentor") is not None else None
                if m:
                    for k in GENE:
                        b.g[k] += (m.g[k] - b.g[k]) * 0.02
                if self.bar_i >= b.jailed["until"]:
                    self.release(b)
        # 5) หาจังหวะเข้า
        for b in self.bots:
            if b.pos or b.jailed or b.paused:
                continue
            t, m, bk, score = b.signals(self.s)
            if abs(score) >= b.g["thr"]:
                self._open(b, 1 if score > 0 else -1, (t, m, bk), score, bar)
        # 6) งานเป็นรอบ
        if self.bar_i % self.L["peer_talk_every"] == 0:
            self._peer_talk()
        if self.bar_i % 150 == 0:
            self.mid_day()
        elif self.bar_i % 30 == 0:
            self.fill_lineup("ผ่านเกณฑ์อัตราชนะ")

    # ================= เปิด/ปิดออเดอร์ =================
    def live_allowed(self):
        return (self.ex is not None and not self.qualifying and not self.halted and not self.manual_halt
                and not (self.target_hit and self.T["stop_at_target"]))

    def _open(self, b, d, comps, score, bar):
        lot = self.B["lot"]
        # ผู้คุมตรวจก่อนส่งทุกออเดอร์
        if bar.spread > self.SV["max_spread"]:
            return
        if lot > self.B["max_lot"] or abs(score) < b.g["thr"]:
            self.jail(b, "ออเดอร์ไม่ตรงสูตร")
            return
        sl_d, tp_d = b.g["sl"], b.g["tp"]
        pos = {"dir": d, "bar0": self.bar_i, "live": False, "ticket": None,
               "comps": {"t": comps[0] * d, "m": comps[1] * d, "b": comps[2] * d}}
        if b.live and self.live_allowed():
            res = self.ex.open(self, b, d, lot, sl_d, tp_d, bar)
            if not res:
                return
            pos.update(entry=res["entry"], sl=res["sl"], tp=res["tp"], ticket=res["ticket"], live=True)
            self.log("trade", f"{b.tag} เปิด{'ซื้อ' if d > 0 else 'ขาย'} (เงินจริง) {lot} ล็อต ที่ {res['entry']:.2f} "
                              f"SL {res['sl']:.2f} TP {res['tp']:.2f}")
        else:
            entry = bar.close + bar.spread if d > 0 else bar.close
            pos.update(entry=entry, sl=entry - d * sl_d, tp=entry + d * tp_d)
        b.pos = pos

    def close_bot(self, b, reason):
        if not b.pos:
            return True
        if b.pos["live"]:
            pnl = self.ex.close(self, b, self.last_bar) if self.ex else None
            if pnl is None:
                self.log("warn", f"ปิดออเดอร์ของ {b.tag} ไม่สำเร็จ จะลองใหม่รอบหน้า")
                return False
        else:
            pnl = self._pnl(b.pos, self.market_exit_price(b.pos, self.last_bar), self.B["lot"])
        self._closed(b, pnl, reason)
        return True

    def _closed(self, b, pnl, reason):
        pos = b.pos
        if pos is None:
            return
        b.pos = None
        win = pnl > 0
        b.today += pnl
        b.total += pnl
        b.trades += 1
        b.today_trades += 1
        b.recent.append(1 if win else 0)
        if win:
            b.wins += 1
            b.today_wins += 1
            b.consec_losses = 0
        else:
            b.consec_losses += 1
        self._learn(b, pos, pnl)
        if pos["live"]:
            b.live_today += pnl
            b.live_total += pnl
            b.live_trades += 1
            b.live_wins += 1 if win else 0
            self.team_today += pnl
            self.team_total += pnl
            self.log("trade", f"{b.tag} ปิดออเดอร์เงินจริง {reason} {money(pnl)} | ทีมวันนี้ {money(self.team_today)}")
        if self.storage:
            self.storage.log_trade({"day": str(self.day), "bar": self.bar_i, "bot": b.id + 1, "name": b.name,
                                    "live": int(pos["live"]), "dir": pos["dir"], "entry": round(pos["entry"], 3),
                                    "pnl": round(pnl, 2), "reason": reason})
        # ผู้คุม
        if b.consec_losses >= self.SV["max_consecutive_losses"]:
            self.jail(b, f"แพ้ติดกัน {b.consec_losses} ไม้ ผิดไปจากสูตร")
        elif b.today < -self.SV["bot_daily_loss_limit"]:
            self.jail(b, f"ขาดทุนวันนี้ {money(b.today)} เกินเพดาน")
        elif b.live and not self.eligible(b):
            self.set_live(b, False, f"หลุดเกณฑ์: {self.why_not(b)}")
            self.fill_lineup(f"แทนที่ {b.tag}")
        # เป้า / เพดานขาดทุนของทีม
        if pos["live"]:
            if not self.target_hit and self.team_today >= self.T["daily_target"]:
                self.target_hit = True
                msg = f"ทีมเทรดจริงถึงเป้า {money(self.T['daily_target'])} แล้ว ({money(self.team_today)})"
                if self.T["stop_at_target"]:
                    msg += " ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน"
                    self.log("day", msg)
                    self.notify(msg)
                    self.close_all_live("ถึงเป้า ปิดเก็บกำไร")
                else:
                    self.log("day", msg)
                    self.notify(msg)
            if not self.halted and self.team_today <= -self.T["max_daily_loss"]:
                self.halted = True
                msg = f"ทีมขาดทุนวันนี้ {money(self.team_today)} ถึงเพดาน ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน"
                self.log("warn", msg)
                self.notify(msg)
                self.close_all_live("ถึงเพดานขาดทุนทีม")

    def close_all_live(self, reason):
        for b in self.bots:
            if b.pos and b.pos["live"]:
                self.close_bot(b, reason)

    def _learn(self, b, pos, pnl):
        s = 1 if pnl > 0 else -1
        lr, g = b.g["lr"], b.g
        g["wT"] += lr * s * pos["comps"]["t"]
        g["wM"] += lr * s * pos["comps"]["m"]
        g["wB"] += lr * s * pos["comps"]["b"]
        g["thr"] += -0.004 if s > 0 else 0.008
        wr, goal = b.recent_wr(), self.T["min_win_rate"] / 100
        if wr is not None and wr <= goal:
            g["tp"] *= 0.93 if s < 0 else 0.99
            if s < 0:
                g["sl"] *= 1.02
        elif wr is not None and wr > goal + 0.05 and s > 0:
            g["tp"] *= 1.01
        fix_genome(g)

    # ================= ผู้คุม / เขตห้ามเทรด =================
    def jail(self, b, reason, by_user=False):
        if b.jailed:
            return False
        if b.pos and not self.close_bot(b, "ผู้คุมปิดออเดอร์"):
            return False
        if b.jailed:       # ถูกขังระหว่างปิดออเดอร์ไปแล้ว
            return True
        m = self.best_bot(b.id)
        b.jailed = {"until": self.bar_i + self.SV["jail_bars"], "mentor": m.id if m else None, "reason": reason}
        b.violations += 1
        was_live = b.live
        b.live = False
        self.log("jail", f"{'สั่งขัง' if by_user else 'ผู้คุมจับ'} {b.tag}{' (ถูกถอดจากทีมเทรดจริง)' if was_live else ''}"
                         f" เข้าเขตห้ามเทรด: {reason}" + (f" ส่งไปเรียนกับ {m.tag}" if m else ""))
        if was_live:
            self.notify(f"ผู้คุมจับ {b.tag} ออกจากทีมเทรดจริง: {reason}")
            self.fill_lineup(f"แทนที่ {b.tag}")
        return True

    def release(self, b, by_user=False):
        if not b.jailed:
            return False
        b.jailed = None
        b.consec_losses = 0
        self.log("teach", f"{b.tag} {'ถูกปล่อยก่อนกำหนด' if by_user else 'พ้นเขตห้ามเทรด'}")
        return True

    def teach(self, m, s, rate, why):
        for k, (lo, hi) in GENE.items():
            s.g[k] += (m.g[k] - s.g[k]) * rate + self.rng.gauss(0, 0.02) * (hi - lo)
        fix_genome(s.g)
        self.log("teach", f"{m.tag} สอนสูตรให้ {s.tag} ({why})")

    def _peer_talk(self):
        """บอทกลุ่มเรียนรู้เดินไปคุยกับตัวอื่น ถ้าอีกฝ่ายเก่งกว่าก็ได้เคล็ดลับกลับมา"""
        for b in self.bots:
            if b.live or b.jailed or b.paused or self.rng.random() > 0.3:
                continue
            others = [o for o in self.bots if o is not b and o.jailed is None]
            if not others:
                continue
            p = self.rng.choice(others)
            b.chats += 1
            if self.rank_score(p) > self.rank_score(b):
                # เรียนแค่บางส่วน และคิดต่อยอดเองเล็กน้อย เพื่อไม่ให้ทุกตัวกลายเป็นสูตรเดียวกันหมด
                for k, (lo, hi) in GENE.items():
                    b.g[k] += (p.g[k] - b.g[k]) * 0.01 + self.rng.gauss(0, 0.005) * (hi - lo)
                fix_genome(b.g)
                b.tips += 1

    # ================= สิ้นวัน =================
    def end_day(self):
        ranked = sorted(self.bots, key=lambda b: b.today, reverse=True)
        champ = ranked[0]
        hit = self.team_today >= self.T["daily_target"]
        live_names = ", ".join(f"{b.id + 1:02d}" for b in self.bots if b.live) or "-"
        if not self.qualifying:
            self.days_done += 1
            self.days_hit += 1 if hit else 0
            row = {"day": str(self.day), "team_pnl": round(self.team_today, 2), "hit_target": int(hit),
                   "halted": int(self.halted), "champion": champ.id + 1, "champion_pnl": round(champ.today, 2),
                   "live_bots": live_names}
            self.history.append(row)
            if self.storage:
                self.storage.log_day(row)
            msg = (f"จบวัน {self.day}: ทีมเทรดจริง {money(self.team_today)} "
                   f"{'ถึงเป้า' if hit else 'ไม่ถึงเป้า'} {money(self.T['daily_target'])} | "
                   f"แชมป์ {champ.tag} {money(champ.today)} | ถึงเป้า {self.days_hit}/{self.days_done} วัน")
            self.log("day", msg)
            self.notify(msg)
        for s in [b for b in ranked if b.jailed is None and b is not champ][-self.L["teach_bottom_n"]:]:
            self.teach(champ, s, 0.35, "คาบเรียนหลังตลาดปิด")
        if self.L["autosave_champion"] and champ.total > 0 and self.storage and not self.qualifying:
            self.save_strategy(champ, auto=True)
        for b in self.bots:
            b.today = 0.0
            b.today_trades = 0
            b.today_wins = 0
            b.live_today = 0.0
        self.team_today = 0.0
        self.target_hit = False
        self.halted = False
        self.day_no += 1
        self.select_lineup("จัดทีมใหม่ตามผลงาน")

    def save_strategy(self, b, auto=False):
        if b.total <= 0:
            return f"{b.tag} ยังไม่มีกำไรสะสม ({money(b.total)}) จึงยังเซฟสูตรไม่ได้"
        wr = b.recent_wr()
        doc = {"name": f"สูตร{b.name} {self.day}", "bot": b.id + 1, "genome": {k: round(v, 4) for k, v in b.g.items()},
               "total": round(b.total, 2), "recent_win_rate": round((wr or 0) * 100, 1), "trades": b.trades,
               "day": str(self.day)}
        if self.storage:
            self.storage.save_strategy(doc)
        self.log("save", f"{'เซฟอัตโนมัติ' if auto else 'เซฟ'}สูตรของ {b.tag} กำไรสะสม {money(b.total)}")
        return f"เซฟสูตรของ {b.tag} แล้ว"

    # ================= เริ่มระบบ =================
    def qualify(self, bars):
        """รอบคัดเลือก: ทุกตัวฝึกเทรดกับข้อมูลย้อนหลัง แล้วเลือกตัวที่ผ่านเกณฑ์ขึ้นทีม"""
        self.qualifying = True
        for bar in bars:
            self.step(bar)
        for b in self.bots:     # ออเดอร์ฝึกที่ค้าง ปิดทิ้ง
            if b.pos and not b.pos["live"]:
                b.pos = None
            b.today = 0.0
            b.today_trades = 0
            b.today_wins = 0
        self.qualifying = False
        self.select_lineup("ผลงานรอบคัดเลือก")
        n = sum(b.live for b in self.bots)
        self.log("team", f"รอบคัดเลือกจบ มีบอทผ่านเกณฑ์ขึ้นทีม {n} ตัว" +
                 ("" if n else " ทีมเทรดจริงจะว่างจนกว่าจะมีตัวผ่านเกณฑ์"))

    def preload(self, bars):
        """ใช้ตอนเปิดระบบใหม่หลังจากเคยรันแล้ว: ใส่ราคาย้อนหลังโดยไม่เทรด"""
        for bar in bars:
            self.s.push(bar.close)
            self.last_bar = bar
        if self.day is None and bars:
            self.day = bar_day(bars[-1].time)

    # ================= บันทึก/โหลดสถานะ =================
    def to_state(self):
        return {"bar_i": self.bar_i, "day": str(self.day) if self.day else None, "day_no": self.day_no,
                "team_today": self.team_today, "team_total": self.team_total, "target_hit": self.target_hit,
                "halted": self.halted, "manual_halt": self.manual_halt, "days_hit": self.days_hit,
                "days_done": self.days_done, "bots": [b.to_dict() for b in self.bots],
                "dash": self.dash_info()}

    def dash_info(self):
        c = self.champion()
        lb = self.last_bar
        return {"price": lb.close if lb else None, "spread": lb.spread if lb else None,
                "bar_time": lb.time if lb else None, "prices": [round(x, 3) for x in self.s.c[-240:]],
                "events": list(self.events)[-120:], "history": self.history[-10:],
                "team": {k: self.T[k] for k in ("size", "min_win_rate", "recent_window", "min_trades",
                                                 "require_profit", "daily_target", "stop_at_target",
                                                 "max_daily_loss")},
                "elig": {str(b.id): [self.eligible(b), self.why_not(b)] for b in self.bots},
                "champion": c.id if c else None, "qualifying": self.qualifying,
                "jail_bars": self.SV["jail_bars"]}

    def load_state(self, st):
        for k in ["bar_i", "day_no", "team_today", "team_total", "target_hit", "halted", "manual_halt",
                  "days_hit", "days_done"]:
            if k in st:
                setattr(self, k, st[k])
        if st.get("day"):
            self.day = dt.date.fromisoformat(st["day"])
        by_id = {d["id"]: d for d in st.get("bots", [])}
        for b in self.bots:
            if b.id in by_id:
                b.load_dict(by_id[b.id])
        # bar0 ของออเดอร์เดิม อ้างอิงตัวนับแท่งเดิม ให้เริ่มนับใหม่
        for b in self.bots:
            if b.pos:
                b.pos["bar0"] = self.bar_i
            if b.jailed:
                b.jailed["until"] = self.bar_i + max(0, b.jailed["until"] - st.get("bar_i", self.bar_i))

    # ================= สรุป / คำสั่ง =================
    def status_text(self):
        live = [b for b in self.bots if b.live]
        lines = [f"วันที่ {self.day} ทีมเทรดจริงวันนี้ {money(self.team_today)} / เป้า {money(self.T['daily_target'])}"
                 f" สะสม {money(self.team_total)}" + (" [ถึงเป้าแล้ว]" if self.target_hit else "")
                 + (" [หยุดเพราะถึงเพดานขาดทุน]" if self.halted else "") + (" [หยุดเทรดจริงตามคำสั่ง]" if self.manual_halt else ""),
                 f"ทีมเทรดจริง {len(live)}/{self.T['size']}: " + (", ".join(b.tag for b in live) or "ว่าง")]
        for b in sorted(self.bots, key=lambda x: (x.recent_wr() or -1), reverse=True):
            wr = b.recent_wr()
            state = "ถูกขัง" if b.jailed else "เทรดจริง" if b.live else "พัก" if b.paused else "เรียนรู้"
            lines.append(f"  {b.id + 1:02d} {b.name:<8} {state:<8} ชนะล่าสุด {('%.0f%%' % (wr * 100)) if wr is not None else '-':>5}"
                         f" ({sum(b.recent)}/{len(b.recent)})  วันนี้ {money(b.today):>10}  สะสม {money(b.total):>10}"
                         + ("  ✓" if self.eligible(b) else ""))
        return "\n".join(lines)

    def command(self, line):
        """คำสั่งควบคุม เช่น  pause 5 | resume 5 | jail 5 | release 5 | close 5 | teach 3 12 | save 5 |
        promote 5 | demote 5 | lineup | target 150 | minwr 85 | halt | unhalt | status"""
        parts = line.strip().split()
        if not parts:
            return ""
        cmd, args = parts[0].lower(), parts[1:]

        def bot(i=0):
            try:
                n = int(args[i])
            except (IndexError, ValueError):
                raise ValueError("ต้องระบุหมายเลขบอท 1-%d" % len(self.bots))
            if not 1 <= n <= len(self.bots):
                raise ValueError("ไม่มีบอทหมายเลข %d" % n)
            return self.bots[n - 1]
        try:
            if cmd == "status":
                return self.status_text()
            if cmd == "lineup":
                self.select_lineup("สั่งจัดทีมใหม่")
                return "จัดทีมแล้ว: " + (", ".join(b.tag for b in self.bots if b.live) or "ยังไม่มีตัวผ่านเกณฑ์")
            if cmd == "target":
                self.T["daily_target"] = float(args[0])
                return f"ตั้งเป้ากำไรทีมเป็น {money(self.T['daily_target'])} ต่อวัน"
            if cmd == "minwr":
                v = float(args[0])
                if not 50 <= v <= 99:
                    return "เกณฑ์อัตราชนะต้องอยู่ระหว่าง 50 ถึง 99"
                self.T["min_win_rate"] = v
                self.mid_day()
                return f"ตั้งเกณฑ์ชนะเกิน {v:.0f}% แล้ว ผ่านเกณฑ์ {sum(self.eligible(b) for b in self.bots)} ตัว"
            if cmd == "halt":
                self.manual_halt = True
                self.close_all_live("หยุดตามคำสั่ง")
                return "ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงแล้ว (บอทยังฝึกต่อ) พิมพ์ unhalt เพื่อกลับมาเทรด"
            if cmd == "unhalt":
                self.manual_halt = False
                return "กลับมาเทรดจริงแล้ว"
            if cmd == "pause":
                b = bot()
                b.paused = True
                if b.live:
                    self.set_live(b, False, "ถูกสั่งพัก")
                    self.fill_lineup(f"แทนที่ {b.tag}")
                return f"สั่งพัก {b.tag} แล้ว (ออเดอร์ที่ค้างยังมี SL/TP คุมอยู่)"
            if cmd == "resume":
                b = bot()
                b.paused = False
                return f"{b.tag} กลับมาเทรดแล้ว"
            if cmd == "jail":
                b = bot()
                return f"ขัง {b.tag} แล้ว" if self.jail(b, "ผู้ใช้สั่งขัง", by_user=True) else f"{b.tag} ถูกขังอยู่แล้ว"
            if cmd == "release":
                b = bot()
                return f"ปล่อย {b.tag} แล้ว" if self.release(b, by_user=True) else f"{b.tag} ไม่ได้ถูกขัง"
            if cmd == "close":
                b = bot()
                if not b.pos:
                    return f"{b.tag} ไม่มีออเดอร์ค้าง"
                return f"ปิดออเดอร์ {b.tag} แล้ว" if self.close_bot(b, "ปิดตามคำสั่ง") else "ปิดไม่สำเร็จ"
            if cmd == "teach":
                m, s = bot(0), bot(1)
                if m is s:
                    return "บอทสอนตัวเองไม่ได้"
                self.teach(m, s, 0.4, "สั่งจากผู้ใช้")
                return f"{m.tag} สอน {s.tag} แล้ว"
            if cmd == "save":
                return self.save_strategy(bot())
            if cmd == "promote":
                b = bot()
                if b.live:
                    return f"{b.tag} อยู่ในทีมแล้ว"
                if not self.eligible(b):
                    return f"{b.tag} ยังขึ้นทีมไม่ได้: {self.why_not(b)}"
                live = [x for x in self.bots if x.live]
                if len(live) >= self.T["size"]:
                    w = min(live, key=self.rank_score)
                    self.set_live(w, False, f"เปิดที่ให้ {b.tag}")
                self.set_live(b, True, "สั่งจากผู้ใช้")
                return f"{b.tag} ขึ้นทีมเทรดจริงแล้ว"
            if cmd == "demote":
                b = bot()
                if not b.live:
                    return f"{b.tag} อยู่ในกลุ่มเรียนรู้อยู่แล้ว"
                b.paused = True
                self.set_live(b, False, "สั่งจากผู้ใช้")
                self.fill_lineup(f"แทนที่ {b.tag}")
                b.paused = False
                return f"ถอน {b.tag} ไปกลุ่มเรียนรู้แล้ว"
        except (ValueError, IndexError) as e:
            return f"คำสั่งไม่ถูกต้อง: {e}"
        return "ไม่รู้จักคำสั่งนี้ ดูรายการคำสั่งใน README"
