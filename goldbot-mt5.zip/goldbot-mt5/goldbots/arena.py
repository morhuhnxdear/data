"""หัวใจของระบบ: บอท 100 ตัว ผู้คุม เขตห้ามเทรด การสอน การจัดทีม เป้ารายวัน
ใช้ร่วมกันทั้ง backtest และการเทรดจริงผ่าน MT5"""
import datetime as dt
import os
import random
import time
from collections import deque, namedtuple

from .bots import GENE, NAMES, Bot, configure as configure_ind, fix_genome, genome_dist, stop_keys, stops
from .bots import IND, TF, family_of, hold_bars, market_ctx, min_bars, tf_close, trail
from .indicators import Series
from .teachers import TeacherRoom, robustness, shadow_test_fast
from .rows import Rows
from .contest import Contest
from .news import NewsRoom
from .guards import Guards
from .guests import Guests

Bar = namedtuple("Bar", "time open high low close spread")  # ราคา = bid, spread = ดอลลาร์
WARMUP = 70


def money(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


def bar_day(t):
    return dt.datetime.fromtimestamp(int(t), dt.timezone.utc).date()


class Arena:
    def __init__(self, cfg, executor=None, log=None, notify=None, storage=None, seed=None):
        self.cfg = cfg
        configure_ind(cfg)
        self.T, self.SV, self.B, self.L = cfg["team"], cfg["supervisor"], cfg["bots"], cfg["learning"]
        self.rng = random.Random(self.B["seed"] if seed is None else seed)
        self.xrng = random.Random((self.B["seed"] if seed is None else seed) + 7919)   # ใช้กับการสอบ (ไม่รบกวนลำดับสุ่มเดิม)
        # ข้อ 1-4: กันบอทที่เก่งแบบฟลุ๊ค (สอบหลายช่วง, เกณฑ์สถิติ, ทดสอบความทนทาน, ต้นทุนจริง)
        X = cfg.get("exam", {})
        self.X = {"on": bool(X.get("enabled", True)), "holdout": float(X.get("holdout", 0.3)),
                  "days": float(X.get("exam_days", 3)), "segs": int(X.get("exam_segments", 3)),
                  "seg_min": int(X.get("min_segments_profit", 2)), "min_trades": int(X.get("min_exam_trades", 15)),
                  "every": int(X.get("exam_every", 240)), "stat_n": int(X.get("stat_trades", 50)),
                  "stat_win": int(X.get("stat_window", 100)), "t_min": float(X.get("min_t_stat", 1.5)),
                  "robust_tests": int(X.get("robust_tests", 6)), "robust_pct": float(X.get("robust_pct", 10)),
                  "robust_share": float(X.get("robust_min_share", 0.67)), "slip": float(X.get("slippage", 0.05)),
                  "calib": bool(X.get("calibrate_costs", True)), "streak": int(X.get("pass_streak", 2))}
        self.cost_obs = {"slip_n": 0, "slip": 0.0, "comm_n": 0, "comm": 0.0}   # ต้นทุนที่วัดได้จากออเดอร์จริง
        self.exam_stats = {"taken": 0, "passed": 0, "fail_trades": 0, "fail_seg": 0, "fail_robust": 0}
        self._exam_W = None
        self.ex = executor
        self._user_log = log or (lambda kind, msg: print(msg))
        self.events = deque(maxlen=200)      # เหตุการณ์ล่าสุด สำหรับหน้าจอแดชบอร์ด
        self.event_seq = 0
        self.notify = notify or (lambda msg: None)
        self.storage = storage
        self.bots = [Bot(i, NAMES[i % len(NAMES)], self.rng, self.T["recent_window"])
                     for i in range(self.B["count"])]
        for b in self.bots:
            b.hist_pnl = deque(maxlen=max(self.X["stat_win"], self.X["stat_n"]))
        self.s = Series()
        self.bar_i = 0
        self.day = None
        self.day_no = 1
        self.team_today = 0.0
        self.team_total = 0.0
        self.target_hit = False
        self.halted = False
        self.manual_halt = False
        self.days_hit = 0
        self.days_done = 0
        self.history = []
        self.qualifying = False
        self.last_bar = None
        self.contract = cfg["market"]["contract_size"]
        self.spread_blocked = 0        # จำนวนแท่งวันนี้ที่ spread กว้างจนห้ามเปิดออเดอร์เงินจริง
        self._spread_warned = -10**9
        self.vol_pause_until = 0       # ผู้คุมความเสี่ยงสั่งพักออเดอร์เงินจริงถึงแท่งนี้ (ราคากระชาก)
        self.risk_blocks = 0
        self.teachers = TeacherRoom(self)
        self.sig_hist = deque(maxlen=300)    # [bar_i, คะแนนสัญญาณรวม, จุดแนะนำ 1/-1/0] สำหรับกราฟ
        self.trade_marks = deque(maxlen=200) # [bar_i, ราคา, "open"/"close", ทิศ, บอท, กำไร]
        self._sig_prev = 0.0
        self.sig_open = []                   # จุดแนะนำที่ยังติดตามผลอยู่
        self.sig_log = deque(maxlen=200)     # จุดแนะนำล่าสุด (ทั้งที่รู้ผลแล้วและยังติดตาม) สำหรับแดชบอร์ด
        self.sig_seq = 0
        # เซฟสูตรอัตโนมัติเมื่อชนะถึงเกณฑ์ (ปรับได้จากแดชบอร์ด ค่าที่ปรับแล้วจำไว้ใน state)
        self.autosave = {"on": bool(self.L.get("auto_save", True)),
                         "wr": float(self.L.get("auto_save_win_rate", 75)),
                         "profit": bool(self.L.get("auto_save_require_profit", True))}
        self.autosave_n = 0
        self._autosaved = {}                 # บอท -> สูตรที่เซฟอัตโนมัติล่าสุด (กันเซฟสูตรเดิมซ้ำ)
        self._was_qual = set()               # บอทที่ผ่านเกณฑ์เซฟอยู่แล้วตอนเช็กครั้งก่อน
        self.day_stat = {"n": 0, "w": 0, "gain": 0.0, "loss": 0.0}   # ผลเทรดทุกบอทของวันนี้ (เส้นการเรียนรู้)
        R = cfg.get("rest", {})
        self.rest_on = bool(R.get("enabled", True))
        self.rest_stress = float(R.get("stress_to_rest", 70))
        self.rest_bars = int(R.get("rest_bars", 15))
        self.team_override = {}              # ค่าที่ตั้งผ่านคำสั่ง/แดชบอร์ด (เป้า เพดานขาดทุน เกณฑ์ชนะ) จำไว้แม้ปิดโปรแกรม
        self.learn_hist = []                 # เส้นการเรียนรู้รายวัน
        self.evolved_today = []
        self.teach_min = float(self.L.get("teach_min_win_rate", 75))   # บอทสอนกันเองได้เมื่อสูตรชนะถึงเกณฑ์นี้
        self.rows = Rows(self)
        self.contest = Contest(self)
        self.news = NewsRoom(self)
        self.guards = Guards(self)
        self.guests = Guests(self)
        if storage is not None:
            try:
                self.rows.load_library(storage.load_strategies())
            except Exception:
                pass
        self.sig_stats = {"n": 0, "tp": 0, "sl": 0, "timeout": 0, "wins": 0, "pnl": 0.0,
                          "buy_n": 0, "buy_wins": 0, "sell_n": 0, "sell_wins": 0}
        # เก็บแท่งราคาไว้ 7 วัน ให้อาจารย์ใช้ทดสอบว่าสูตรใหม่ยังดีเมื่อมองทั้งสัปดาห์ ไม่ใช่ดีแค่ช่วงสั้นๆ
        self.bars = deque(maxlen=max(self.teachers.max_window, self.teachers.window, 240, self.teachers.long_window) + 70)
        self.comm_cfg = cfg["market"].get("commission_per_lot", 0.0)

    # ================= ต้นทุนการเทรด (ข้อ 4) =================
    @property
    def slip(self):
        """slippage ต่อครั้ง (ดอลลาร์ต่อออนซ์) ที่ใช้คิดในไม้ฝึก/การทดสอบ: ค่าใน config หรือค่าที่วัดได้จริง ถ้าแย่กว่า"""
        if not self.X["on"]:
            return 0.0
        v = self.X["slip"]
        o = self.cost_obs
        if self.X["calib"] and o["slip_n"] >= 5:
            v = max(v, o["slip"])
        return v

    @property
    def comm(self):
        v = self.comm_cfg
        o = self.cost_obs
        if self.X["on"] and self.X["calib"] and o["comm_n"] >= 3:
            v = max(v, o["comm"])
        return v

    def observe_cost(self, slip=None, comm_per_lot=None):
        """ตัวส่งคำสั่ง MT5 รายงานต้นทุนจริงที่เจอ: slippage (ราคาแย่กว่าที่ขอ) และค่าคอมต่อล็อต
        ใช้ค่าเฉลี่ยเคลื่อนที่ ให้การฝึกและการสอบคิดต้นทุนใกล้ของจริง"""
        o = self.cost_obs
        if slip is not None:
            o["slip_n"] += 1
            k = 1 / min(o["slip_n"], 50)
            o["slip"] += (max(0.0, slip) - o["slip"]) * k
        if comm_per_lot is not None:
            o["comm_n"] += 1
            k = 1 / min(o["comm_n"], 50)
            o["comm"] += (max(0.0, comm_per_lot) - o["comm"]) * k

    # ================= สอบก่อนขึ้นทีม (ข้อ 1 + 3) และเกณฑ์สถิติ (ข้อ 2) =================
    def stat_ok(self, b):
        if not self.X["on"]:
            return True
        t = b.t_stat()
        return len(b.hist_pnl) >= self.X["stat_n"] and t is not None and t >= self.X["t_min"]

    def _exam_window(self):
        n = int(self.X["days"] * 1440)
        W = self._exam_W
        if W is None or self.bar_i - W[0] >= 60:
            bars = list(self.bars)[-n:]
            if len(bars) < max(720, n // 3):
                self._exam_W = (self.bar_i, None)
            else:
                from .fastsig import Window
                self._exam_W = (self.bar_i, Window(self.s, bars, len(self.s.c) - len(bars)))
        return self._exam_W[1]

    def _xtest(self, g, W, segs=0):
        return shadow_test_fast(g, W, self.B["lot"], self.contract, self.comm, self.SV["max_hold_bars"], self.slip, segs)

    def exam_ok(self, b, force=False):
        """สูตรปัจจุบันของบอทต้องได้กำไร (หลังหักต้นทุน) เมื่อทดสอบกับราคาย้อนหลังหลายวัน โดยได้กำไรในหลายช่วงแยกกัน
        ไม่ใช่กำไรมาจากช่วงเดียว และเมื่อขยับค่าในสูตร ±10% ส่วนใหญ่ต้องยังได้กำไร ผลสอบใช้ได้ exam_every นาที"""
        X = self.X
        if not X["on"]:
            return True
        e = b.exam
        if e and not force and 0 <= self.bar_i - e["bar"] < X["every"]:
            return e["ok"]
        W = self._exam_window()
        if W is None:
            b.exam = {"bar": self.bar_i, "ok": False, "why": "ราคาย้อนหลังยังไม่พอสอบ"}
            return False
        st = self.exam_stats
        st["taken"] += 1
        r = self._xtest(b.g, W, X["segs"])
        segs = [round(x, 2) for x in r["seg"]]
        seg_ok = sum(1 for x in r["seg"] if x > 0)
        res = {"bar": self.bar_i, "ok": False, "pnl": round(r["pnl"], 2), "trades": r["trades"], "segs": segs,
               "seg_ok": seg_ok, "robust": None, "days": X["days"]}
        if r["trades"] < X["min_trades"]:
            st["fail_trades"] += 1
            res["why"] = f"สอบย้อนหลัง {X['days']:g} วัน เทรดแค่ {r['trades']} ไม้ (ต้อง {X['min_trades']} ไม้ขึ้นไป)"
        elif r["pnl"] <= 0 or seg_ok < X["seg_min"]:
            st["fail_seg"] += 1
            res["why"] = (f"สอบย้อนหลัง {X['days']:g} วัน กำไร {money(r['pnl'])} ได้กำไร {seg_ok} จาก {X['segs']} ช่วง "
                          f"(ต้องกำไรรวมเป็นบวกและได้กำไรอย่างน้อย {X['seg_min']} ช่วง)")
        else:
            share = 1.0
            if X["robust_tests"] > 0:
                share, _ = robustness(b.g, W, self.xrng, lambda g, WW: self._xtest(g, WW), X["robust_tests"], X["robust_pct"])
            res["robust"] = round(share, 2)
            if share < X["robust_share"]:
                st["fail_robust"] += 1
                res["why"] = (f"ขยับค่าในสูตร ±{X['robust_pct']:g}% แล้วยังได้กำไรแค่ {share * 100:.0f}% ของแบบที่ลอง "
                              f"(ต้อง {X['robust_share'] * 100:.0f}%) สูตรอาจดีเพราะบังเอิญ")
            else:
                res["ok"] = True
                res["why"] = ""
                st["passed"] += 1
        # ต้องสอบผ่านติดกันหลายรอบ (คนละช่วงเวลา) ถึงนับว่าผ่าน กันสูตรที่บังเอิญดีแค่ช่วงเดียว
        streak = ((b.exam or {}).get("streak", 0) + 1) if res["ok"] else 0
        res["streak"] = streak
        if res["ok"] and streak < X["streak"]:
            res["ok"] = False
            res["why"] = f"สอบผ่าน {streak} รอบติดกัน ต้องผ่าน {X['streak']} รอบ (สอบรอบถัดไปใน {X['every'] // 60} ชม.)"
        b.exam = res
        return res["ok"]

    def log(self, kind, msg):
        self.event_seq += 1
        self.events.append([self.event_seq, time.strftime("%H:%M:%S"), kind, msg])
        self._user_log(kind, msg)

    # ================= คะแนนและเกณฑ์ =================
    def rank_score(self, b):
        return b.today + 0.25 * b.total

    def profit_ok(self, b):
        """ไม้ล่าสุดได้กำไรจริงไหม: กำไรเฉลี่ยต่อไม้และ profit factor ถึงเกณฑ์"""
        e, pf = b.recent_exp(), b.recent_pf()
        return (len(b.recent_pnl) >= self.T["min_trades"] and e is not None and e > self.T.get("min_avg_pnl", 0.0)
                and pf is not None and pf >= self.T.get("min_profit_factor", 1.3))

    def eligible(self, b):
        wr = b.recent_wr()
        return (b.jailed is None and not b.paused and len(b.recent) >= self.T["min_trades"]
                and wr is not None and wr * 100 > self.T["min_win_rate"] and self.profit_ok(b)
                and (not self.T["require_profit"] or b.total > 0) and not self.guards.is_benched(b)
                and self.rows.fam_ok(b.fam) and self.stat_ok(b) and self.exam_ok(b))

    def why_not(self, b):
        wr = b.recent_wr()
        if b.jailed:
            return "ถูกขังอยู่"
        if b.paused:
            return "ถูกสั่งพัก"
        if len(b.recent) < self.T["min_trades"]:
            return f"ไม้ยังไม่พอ ({len(b.recent)}/{self.T['min_trades']})"
        if not wr * 100 > self.T["min_win_rate"]:
            return f"ชนะ {wr * 100:.0f}% ใน {len(b.recent)} ไม้ล่าสุด ต้องเกิน {self.T['min_win_rate']}%"
        if not self.profit_ok(b):
            e, pf = b.recent_exp(), b.recent_pf()
            if len(b.recent_pnl) < self.T["min_trades"]:
                return f"ยังเก็บผลกำไรไม่ครบ ({len(b.recent_pnl)}/{self.T['min_trades']} ไม้)"
            return (f"กำไรเฉลี่ย {money(e)}/ไม้ profit factor {pf:.2f} "
                    f"(ต้องเกิน {money(self.T.get('min_avg_pnl', 0.0))} และ PF {self.T.get('min_profit_factor', 1.3)} ขึ้นไป)")
        if self.T["require_profit"] and b.total <= 0:
            return f"กำไรสะสมยังไม่เป็นบวก ({money(b.total)})"
        if self.guards.is_benched(b):
            return "ผู้คุมเทรดถี่สั่งพักจากทีมเงินจริงถึงสิ้นวัน"
        if not self.rows.fam_ok(b.fam):
            from .bots import FAMILIES
            return f"หัวหน้าสายสั่งพัก{FAMILIES[b.fam][1]}จากทีมเงินจริง (ไม้ล่าสุดของสายขาดทุนเฉลี่ย)"
        if not self.stat_ok(b):
            t = b.t_stat()
            if len(b.hist_pnl) < self.X["stat_n"]:
                return f"ไม้ยังไม่พอวัดทางสถิติ ({len(b.hist_pnl)}/{self.X['stat_n']} ไม้)"
            return (f"กำไรต่อไม้ยังไม่ชัดว่าไม่ใช่ดวง (ค่า t = {t:.2f} จาก {len(b.hist_pnl)} ไม้ ต้องถึง {self.X['t_min']:g})")
        if not self.exam_ok(b):
            return "สอบไม่ผ่าน: " + ((b.exam or {}).get("why") or "")
        return ""

    def can_teach(self, b):
        """บอทจะสอนบอทตัวอื่นได้ เฉพาะเมื่อสูตรที่เทรดอยู่ชนะถึงเกณฑ์ (ค่าเริ่มต้น 75%) ในไม้ล่าสุดที่มีไม้พอ"""
        wr = b.recent_wr()
        e = b.recent_exp()
        return (b.jailed is None and len(b.recent) >= self.T["min_trades"] and wr is not None
                and wr * 100 >= self.teach_min and e is not None and e > 0)

    def why_cant_teach(self, b):
        if b.jailed:
            return "ถูกขังอยู่"
        if len(b.recent) < self.T["min_trades"]:
            return f"ไม้ยังไม่พอ ({len(b.recent)}/{self.T['min_trades']})"
        if b.recent_wr() * 100 < self.teach_min:
            return f"สูตรชนะ {b.recent_wr() * 100:.0f}% ใน {len(b.recent)} ไม้ล่าสุด ต้องถึง {self.teach_min:.0f}% ถึงจะสอนตัวอื่นได้"
        return "ชนะถึงเกณฑ์แต่กำไรเฉลี่ยต่อไม้ยังไม่เป็นบวก (ชนะบ่อยแต่แพ้ทีละมาก) ยังสอนตัวอื่นไม่ได้"

    def best_bot(self, exclude=None):
        c = [b for b in self.bots if self.can_teach(b) and b.id != exclude]
        return max(c, key=self.rank_score) if c else None

    def champion(self):
        c = [b for b in self.bots if b.today_trades > 0]
        return max(c, key=lambda b: b.today) if c else None

    # ================= จัดทีม =================
    def set_live(self, b, on, why):
        if b.live == on:
            return
        b.live = on
        self.log("team", f"{b.tag} {'ขึ้นทีมเทรดจริง' if on else 'ลงไปกลุ่มเรียนรู้'} ({why})")

    def _one_per_family(self, ranked, taken=None, room=None):
        """เลือกตัวแทนสายละไม่เกิน max_per_family ตัว (ทีมมาจากหลายสาย ไม่แพ้พร้อมกันทั้งทีมเมื่อตลาดเปลี่ยน)"""
        per = int(self.T.get("max_per_family", 1) or 0)
        from .bots import FAM_COUNTS
        # สายที่มีบอทมากกว่า ส่งตัวแทนได้มากกว่า: max_per_family ตัว ต่อบอท 20 ตัวของสาย
        caps = {f: per * max(1, round(n / 20)) for f, n in enumerate(FAM_COUNTS)} if per else {}
        cnt = {}
        for b in taken or []:
            cnt[b.fam] = cnt.get(b.fam, 0) + 1
        out = []
        for b in ranked:
            if room is not None and len(out) >= room:
                break
            if caps and cnt.get(b.fam, 0) >= caps.get(b.fam, per):
                continue
            cnt[b.fam] = cnt.get(b.fam, 0) + 1
            out.append(b)
        return out

    def select_lineup(self, why):
        ranked = sorted([b for b in self.bots if self.eligible(b)], key=self.rank_score, reverse=True)
        want = {b.id for b in self._one_per_family(ranked, room=self.T["size"])}
        for b in self.bots:
            if b.live and b.id not in want:
                self.set_live(b, False, why)
        for b in self.bots:
            if not b.live and b.id in want:
                self.set_live(b, True, why)

    def fill_lineup(self, why):
        live = [b for b in self.bots if b.live]
        free = self.T["size"] - len(live)
        if free <= 0:
            return
        cand = sorted([b for b in self.bots if not b.live and self.eligible(b)], key=self.rank_score, reverse=True)
        for b in self._one_per_family(cand, taken=live, room=free):
            self.set_live(b, True, why)

    def mid_day(self):
        for b in self.bots:
            if b.live and not self.eligible(b):
                self.set_live(b, False, f"หลุดเกณฑ์: {self.why_not(b)}")
        live = [b for b in self.bots if b.live]
        cand = sorted([b for b in self.bots if not b.live and self.eligible(b)], key=self.rank_score, reverse=True)
        if live and cand:
            weak = min(live, key=self.rank_score)
            others = [b for b in live if b is not weak]
            pool = self._one_per_family(cand, taken=others, room=1)
            best = pool[0] if pool else None
            if best is not None and self.rank_score(best) > self.rank_score(weak) + 20 * self.B["lot"] / 0.01:
                self.set_live(weak, False, f"ผลงานแพ้ {best.tag}")
                self.set_live(best, True, f"ทำผลงานแซง {weak.tag}")
        self.fill_lineup("ผ่านเกณฑ์")

    # ================= ราคาและกำไร =================
    def _pnl(self, pos, exit_price, lot):
        return (exit_price - pos["entry"]) * pos["dir"] * self.contract * lot - self.comm * lot

    def paper_exit(self, b, bar):
        """ตรวจว่าออเดอร์ (จำลอง) โดน SL/TP ในแท่งนี้ไหม ถ้าโดนทั้งคู่ถือว่าโดน SL ก่อน"""
        p, sp = b.pos, bar.spread
        if p["dir"] > 0:  # ถือซื้อ ปิดที่ bid
            if bar.low <= p["sl"]:
                return p["sl"] - self.slip, "โดนตัดขาดทุน"     # SL ปิดด้วยราคาตลาด มัก slip
            if bar.high >= p["tp"]:
                return p["tp"], "ถึงจุดทำกำไร"
        else:             # ถือขาย ปิดที่ ask = bid + spread
            if bar.high + sp >= p["sl"]:
                return p["sl"] + self.slip, "โดนตัดขาดทุน"
            if bar.low + sp <= p["tp"]:
                return p["tp"], "ถึงจุดทำกำไร"
        return None

    def market_exit_price(self, pos, bar):
        return (bar.close if pos["dir"] > 0 else bar.close + bar.spread) - pos["dir"] * self.slip

    # ================= วงจรหลัก ต่อ 1 แท่ง =================
    def step(self, bar):
        d = bar_day(bar.time)
        if self.day is None:
            self.day = d
            self.guards.new_day(d)
        elif d != self.day:
            self.end_day()
            self.day = d
            self.contest.new_day(d)
            self.guards.new_day(d)
        self.last_bar = bar
        self.s.push(bar.close, bar.high, bar.low, bar.time)
        self.bars.append(bar)
        self.bar_i += 1
        if len(self.s) < WARMUP:
            return
        self._risk_watch(bar)
        if not self.qualifying:
            self.news.tick(bar)
        self.teachers.on_bar(bar)

        self.guests.tick(bar)                # EA รับเชิญ (อ่านอย่างเดียว)
        # 1) ออเดอร์เงินจริงที่ปิดไปแล้ว (โดน SL/TP ฝั่งโบรกเกอร์)
        if self.ex is not None:
            for b, pnl, reason in self.ex.poll(self, bar):
                self._closed(b, pnl, reason)
        # 2) ออเดอร์ฝึก
        for b in self.bots:
            if b.pos and not b.pos["live"]:
                r = self.paper_exit(b, bar)
                if r:
                    self._closed(b, self._pnl(b.pos, r[0], self.B["lot"]), r[1])
        # 3) ถือนานเกิน
        for b in self.bots:
            if b.pos and self.bar_i - b.pos["bar0"] >= hold_bars(b.g, self.SV["max_hold_bars"]):
                self.close_bot(b, "ครบเวลาถือ")
        # 3.1) วิธีออกของสูตร: เลื่อน SL มาคุ้มทุน / เลื่อนตามราคา (ใช้กับแท่งถัดไป)
        for b in self.bots:
            if b.pos:
                self._trail(b, bar)
        # มุมพักผ่อน: ความเครียดค่อยๆ ลด บอทที่พักครบเวลากลับมาเทรด
        for b in self.bots:
            if b.rest_until is not None:
                b.stress = max(0.0, b.stress - 3.0)
                if self.bar_i >= b.rest_until or b.live or b.jailed:
                    b.rest_until = None
                    b.stress = min(b.stress, 20.0)
            elif b.stress > 0:
                b.stress = max(0.0, b.stress - 0.05)
        # 4) เขตห้ามเทรด: เรียนจากอาจารย์ / พ้นโทษ
        for b in self.bots:
            if b.jailed:
                if b.jailed.get("teacher") is not None:
                    self.teachers.jail_lesson(b)
                else:
                    m = self.bots[b.jailed["mentor"]] if b.jailed.get("mentor") is not None else None
                    if m and self.can_teach(m):            # พี่เลี้ยงต้องยังชนะถึงเกณฑ์ ถึงจะสอนต่อ
                        for k in GENE:
                            b.g[k] += (m.g[k] - b.g[k]) * 0.02
                if self.bar_i >= b.jailed["until"]:
                    self.release(b)
        # 5) หาจังหวะเข้า
        if bar.spread > self.SV["max_spread"]:
            self.spread_blocked += 1
            if not self.qualifying and self.bar_i - self._spread_warned >= 60:
                self._spread_warned = self.bar_i
                self.log("risk", f"ผู้คุมความเสี่ยง: spread ${bar.spread:.2f} กว้างกว่าที่อนุญาต (${self.SV['max_spread']:.2f}) "
                                 f"ห้ามเปิดออเดอร์เงินจริงชั่วคราว บอทยังฝึกเทรดและเรียนรู้ต่อ")
        decide = len(self.s) >= min_bars() and tf_close(bar.time, len(self.s))   # ตัดสินใจเฉพาะตอนแท่ง TF ปิด
        for b in self.bots:
            if not decide or b.pos or b.jailed or b.paused or b.rest_until is not None:
                continue
            t, m, bk, score, h = b.signals(self.s)
            score = self.news.adjust(score)       # รับข่าวด่วน: สัญญาณที่สวนทางข่าวถูกลดน้ำหนัก
            if abs(score) >= b.g["thr"]:
                self._open(b, 1 if score > 0 else -1, (t, m, bk, h), score, bar)
        self._track_signals(bar)
        if decide:
            self._team_signal()
        # 6) งานเป็นรอบ
        if self.bar_i % self.L["peer_talk_every"] == 0:
            self._peer_talk()
        if self.bar_i % self.teachers.study_every == 0:
            self.teachers.study()
        if self.bar_i % self.teachers.class_every == 0 and not self.qualifying:
            self.teachers.teach_class()
        if self.rows.every and self.bar_i % self.rows.every == 0 and not self.qualifying:
            self.rows.meet()
        if self.rows.push_every and self.bar_i % self.rows.push_every == 45 % self.rows.push_every and not self.qualifying:
            self.rows.push()             # แข่งขันระหว่างแถว: แถวอันดับท้ายขออาจารย์ช่วยสอน
        if self.bar_i % 30 == 0:
            self.rows.guard_families()      # หัวหน้าสายดูว่าสายไหนควรพักจากทีมเงินจริง
        if self.bar_i % 150 == 0:
            self.mid_day()
        elif self.bar_i % 30 == 0:
            self.fill_lineup("ผ่านเกณฑ์อัตราชนะ")

    # ================= สัญญาณรวมของทีม (สำหรับกราฟ) =================
    def signal_group(self):
        """บอทที่ใช้คำนวณสัญญาณแนะนำ: ทีมเทรดจริง ถ้ายังไม่มี ใช้ 5 ตัวที่ผลงานดีที่สุด"""
        live = [b for b in self.bots if b.live]
        if live:
            return live, "ทีมเทรดจริง"
        top = sorted([b for b in self.bots if b.jailed is None], key=self.rank_score, reverse=True)
        return top[:self.T["size"]], f"บอทผลงานดีที่สุด {self.T['size']} ตัว"

    def _team_signal(self):
        grp, _ = self.signal_group()
        if not grp:
            return
        sc = sum(b.signals(self.s)[3] for b in grp) / len(grp)
        thr = sum(b.g["thr"] for b in grp) / len(grp)
        mark = 0
        if abs(sc) >= thr and abs(self._sig_prev) < thr:
            mark = 1 if sc > 0 else -1
        elif abs(sc) >= thr and self._sig_prev * sc < 0:
            mark = 1 if sc > 0 else -1
        self._sig_prev = sc
        bar = self.last_bar
        self.sig_hist.append([bar.time, round(sc, 3), mark, round(thr, 3)])
        if mark and not self.qualifying:
            self._record_signal(grp, mark, sc, thr, bar)

    # ---------- เก็บจุดแนะนำและติดตามผล ----------
    def _group_levels(self, grp, d, bar):
        L = len(self.s.c)
        ds = sorted(stops(b.g, self.s, L) for b in grp)
        sl_d, tp_d = ds[len(ds) // 2]
        entry = bar.close + bar.spread if d > 0 else bar.close
        return entry, entry - d * sl_d, entry + d * tp_d

    def _record_signal(self, grp, d, sc, thr, bar):
        entry, sl, tp = self._group_levels(grp, d, bar)
        sigs = [b.signals(self.s)[3] for b in grp]
        agree = sum(1 for b, x in zip(grp, sigs) if abs(x) >= b.g["thr"] and (x > 0) == (d > 0))
        self.sig_seq += 1
        rec = {"id": self.sig_seq, "time": bar.time, "dir": d, "entry": round(entry, 3), "sl": round(sl, 3),
               "tp": round(tp, 3), "score": round(sc, 3), "thr": round(thr, 3), "agree": agree, "group": len(grp),
               "src": self.signal_group()[1], "bar0": self.bar_i, "status": "open",
               "result": None, "exit": None, "pnl": None, "minutes": None}
        self.sig_open.append(rec)
        self.sig_log.append(rec)

    def _track_signals(self, bar):
        """ติดตามผลจุดแนะนำ: ราคาไปถึง TP หรือโดน SL ก่อน (ถ้าแตะทั้งคู่ในแท่งเดียว ถือว่าโดน SL) หรือครบเวลาถือ"""
        if not self.sig_open:
            return
        keep = []
        lot = 0.01
        for r in self.sig_open:
            if r["bar0"] == self.bar_i:
                keep.append(r)
                continue
            d, ex, res = r["dir"], None, None
            if d > 0:
                if bar.low <= r["sl"]:
                    ex, res = r["sl"], "SL"
                elif bar.high >= r["tp"]:
                    ex, res = r["tp"], "TP"
            else:
                if bar.high + bar.spread >= r["sl"]:
                    ex, res = r["sl"], "SL"
                elif bar.low + bar.spread <= r["tp"]:
                    ex, res = r["tp"], "TP"
            if ex is None and self.bar_i - r["bar0"] >= self.SV["max_hold_bars"]:
                ex, res = (bar.close if d > 0 else bar.close + bar.spread), "หมดเวลา"
            if ex is None:
                keep.append(r)
                continue
            pnl = (ex - r["entry"]) * d * self.contract * lot - self.comm * lot
            r.update(status="done", result=res, exit=round(ex, 3), pnl=round(pnl, 2),
                     minutes=self.bar_i - r["bar0"])
            st = self.sig_stats
            st["n"] += 1
            st[{"TP": "tp", "SL": "sl"}.get(res, "timeout")] += 1
            st["wins"] += pnl > 0
            st["pnl"] = round(st["pnl"] + pnl, 2)
            side = "buy" if d > 0 else "sell"
            st[side + "_n"] += 1
            st[side + "_wins"] += pnl > 0
            if self.storage:
                self.storage.log_signal({
                    "id": r["id"], "time_server": dt.datetime.fromtimestamp(r["time"], dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
                    "direction": "ซื้อ" if d > 0 else "ขาย", "entry": r["entry"], "sl": r["sl"], "tp": r["tp"],
                    "score": r["score"], "threshold": r["thr"], "agree": f"{r['agree']}/{r['group']}", "source": r["src"],
                    "result": res, "exit": r["exit"], "pnl_per_0.01lot": r["pnl"], "minutes": r["minutes"]})
        self.sig_open = keep

    def signal_now(self):
        """สัญญาณตอนนี้: ทิศ ความแรง จำนวนบอทที่เห็นด้วย และระดับ SL/TP ที่สูตรของทีมจะตั้ง"""
        L = len(self.s.c)
        lb = self.last_bar
        if lb is None or L < min_bars():
            return None
        grp, src = self.signal_group()
        if not grp:
            return None
        sigs = [b.signals(self.s) for b in grp]
        sc = sum(x[3] for x in sigs) / len(sigs)
        thr = sum(b.g["thr"] for b in grp) / len(grp)
        d = 1 if sc > 0 else -1
        agree = sum(1 for b, x in zip(grp, sigs) if abs(x[3]) >= b.g["thr"] and (x[3] > 0) == (d > 0))
        buy = sell = 0
        for b in self.bots:
            if b.jailed:
                continue
            x = b.signals(self.s)[3]
            if abs(x) >= b.g["thr"]:
                buy += x > 0
                sell += x < 0
        comp = {"t": 0.0, "m": 0.0, "b": 0.0}
        for b, x in zip(grp, sigs):
            W = b.g["wT"] + b.g["wM"] + b.g["wB"]
            comp["t"] += b.g["wT"] * x[0] * d / W
            comp["m"] += b.g["wM"] * x[1] * d / W
            comp["b"] += b.g["wB"] * x[2] * d / W
        entry, sl, tp = self._group_levels(grp, d, lb)
        return {"score": round(sc, 3), "thr": round(thr, 3), "dir": d, "active": abs(sc) >= thr, "src": src,
                "group": len(grp), "agree": agree, "buy": buy, "sell": sell,
                "neutral": sum(1 for b in self.bots if not b.jailed) - buy - sell,
                "comp": {k: round(v / len(grp), 3) for k, v in comp.items()},
                "htf": sum(x[4] for x in sigs), "entry": round(entry, 3),
                "sl": round(sl, 3), "tp": round(tp, 3)}

    # ================= เปิด/ปิดออเดอร์ =================
    def live_allowed(self):
        return (self.ex is not None and not self.qualifying and not self.halted and not self.manual_halt
                and not (self.target_hit and self.T["stop_at_target"]) and self.bar_i >= self.vol_pause_until
                and not self.news.pause_reason() and not self.guards.block_reason() and not self.guests.block)

    # ================= ผู้คุมคนที่ 2: ผู้คุมความเสี่ยง =================
    def _risk_watch(self, bar):
        """ดูแลความเสี่ยงของเงินจริงทั้งพอร์ต: ราคากระชากผิดปกติ, spread, ออเดอร์ในโบรกเกอร์ที่ไม่มี SL"""
        n = 60
        if len(self.bars) > n:
            rs = [x.high - x.low for x in list(self.bars)[-n - 1:-1]]
            avg = sum(rs) / n
            rng = bar.high - bar.low
            mult = self.SV.get("vol_spike_mult", 4.0)
            if avg > 0 and rng > mult * avg and self.bar_i >= self.vol_pause_until:
                self.vol_pause_until = self.bar_i + int(self.SV.get("vol_pause_bars", 15))
                self.risk_blocks += 1
                self.guards.count["risk"] = self.guards.count.get("risk", 0) + 1
                if not self.qualifying:
                    self.log("risk", f"ผู้คุมความเสี่ยง: ราคากระชากแรง (แท่งนี้วิ่ง ${rng:.2f} ปกติ ${avg:.2f}) "
                                     f"พักเปิดออเดอร์เงินจริง {self.SV.get('vol_pause_bars', 15)} นาที ออเดอร์ที่ถืออยู่ยังมี SL คุม")
        # เพดานขาดทุนทีมนับรวมขาดทุนที่ยังไม่ปิด (ไม่รอให้โดน SL ก่อน)
        if not self.halted and not self.qualifying:
            fl = self.live_floating(bar)
            if fl < 0 and self.team_today + fl <= -self.T["max_daily_loss"]:
                self.halted = True
                msg = (f"ผู้คุมความเสี่ยง: ทีมขาดทุนวันนี้ {money(self.team_today)} + ขาดทุนที่ยังไม่ปิด {money(fl)} "
                       f"ถึงเพดาน {money(-self.T['max_daily_loss'])} ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน")
                self.log("risk", msg)
                self.notify(msg)
                self.close_all_live("ถึงเพดานขาดทุนทีม")
        if self.ex is not None and not self.qualifying and hasattr(self.ex, "audit"):
            for msg in self.ex.audit(self):
                self.log("risk", "ผู้คุมความเสี่ยง: " + msg)

    def live_floating(self, bar):
        """กำไร/ขาดทุนที่ยังไม่ปิดของออเดอร์เงินจริงทั้งหมด (ประมาณจากราคาแท่งล่าสุด)"""
        lot = self.B["lot"]
        return sum(self._pnl(b.pos, self.market_exit_price(b.pos, bar), lot)
                   for b in self.bots if b.pos and b.pos["live"])

    def risk_ok(self, sl_d, lot):
        """ไม้เงินจริงใหม่: ขาดทุนสูงสุดต่อไม้ (ถ้าโดน SL) ต้องไม่เกิน max_risk_per_trade
        และขาดทุนสูงสุดของทุกไม้ที่ถืออยู่รวมกัน ต้องไม่เกินงบที่เหลือของวัน (เพดานขาดทุน + กำไร/ขาดทุนวันนี้)"""
        per = float(self.T.get("max_risk_per_trade", 0) or 0)
        risk = sl_d * self.contract * lot + self.comm * lot
        if per > 0 and risk > per:
            return False
        open_risk = sum(abs(b.pos["entry"] - b.pos["sl"]) * self.contract * lot
                        for b in self.bots if b.pos and b.pos["live"] and (b.pos["entry"] - b.pos["sl"]) * b.pos["dir"] > 0)
        budget = self.T["max_daily_loss"] + min(0.0, self.team_today)
        return open_risk + risk <= budget

    def _open(self, b, d, comps, score, bar):
        lot = self.B["lot"]
        # ผู้คุมตรวจก่อนส่งทุกออเดอร์
        if lot > self.B["max_lot"] or abs(score) < b.g["thr"]:
            self.jail(b, "ออเดอร์ไม่ตรงสูตร")
            return
        sl_d, tp_d = stops(b.g, self.s, len(self.s.c))
        ses, hv = market_ctx(self.s, len(self.s.c))
        pos = {"dir": d, "bar0": self.bar_i, "live": False, "ticket": None, "ses": ses, "hv": hv, "risk": sl_d,
               "comps": {"t": comps[0] * d, "m": comps[1] * d, "b": comps[2] * d, "h": comps[3] * d}}
        if (b.live and self.live_allowed() and bar.spread <= self.SV["max_spread"] and not self.guards.open_check(b, d)
                and self.risk_ok(sl_d, lot)):
            res = self.ex.open(self, b, d, lot, sl_d, tp_d, bar)
            if not res:
                return
            pos.update(entry=res["entry"], sl=res["sl"], tp=res["tp"], ticket=res["ticket"], live=True, best=res["entry"])
            self.guards.on_live_open(b)
            self.trade_marks.append([bar.time, round(res["entry"], 3), "open", d, b.id, None])
            self.log("trade", f"{b.tag} เปิด{'ซื้อ' if d > 0 else 'ขาย'} (เงินจริง) {lot} ล็อต ที่ {res['entry']:.2f} "
                              f"SL {res['sl']:.2f} TP {res['tp']:.2f}")
        else:
            entry = (bar.close + bar.spread if d > 0 else bar.close) + d * self.slip   # ข้อ 4: คิด slippage ตอนเข้า
            pos.update(entry=entry, sl=entry - d * sl_d, tp=entry + d * tp_d, best=entry)
        b.pos = pos

    def _trail(self, b, bar):
        p = b.pos
        d = p["dir"]
        best = p.get("best", p["entry"])
        best = max(best, bar.high) if d > 0 else min(best, bar.low + bar.spread)
        p["best"] = best
        risk = p.get("risk") or abs(p["entry"] - p["sl"])
        new = trail(b.g, d, p["entry"], p["sl"], risk, best)
        if (new - p["sl"]) * d < 0.01:
            return
        if p["live"]:
            mod = getattr(self.ex, "modify_sl", None)
            if mod is None or not mod(self, b, new):
                return
        old = p["sl"]
        p["sl"] = new
        if p["live"]:
            self.log("trade", f"{b.tag} เลื่อน SL ออเดอร์จริงจาก {old:.2f} เป็น {new:.2f} "
                              f"({'คุ้มทุน' if abs(new - p['entry']) < 1e-6 else 'เลื่อนตามราคา'})")

    def close_bot(self, b, reason):
        if not b.pos:
            return True
        if b.pos["live"]:
            pnl = self.ex.close(self, b, self.last_bar) if self.ex else None
            if pnl is None:
                self.log("warn", f"ปิดออเดอร์ของ {b.tag} ไม่สำเร็จ จะลองใหม่รอบหน้า")
                return False
        else:
            pnl = self._pnl(b.pos, self.market_exit_price(b.pos, self.last_bar), self.B["lot"])
        self._closed(b, pnl, reason)
        return True

    def _closed(self, b, pnl, reason):
        pos = b.pos
        if pos is None:
            return
        b.pos = None
        win = pnl > 0
        b.today += pnl
        b.total += pnl
        b.trades += 1
        b.today_trades += 1
        b.recent.append(1 if win else 0)
        b.recent_pnl.append(pnl)
        b.hist_pnl.append(pnl)
        self.rows.on_trade(b, pnl)
        if not self.qualifying:
            self.day_stat["n"] += 1
            self.day_stat["w"] += 1 if win else 0
            self.day_stat["gain" if pnl > 0 else "loss"] += abs(pnl)
        if win:
            b.wins += 1
            b.today_wins += 1
            b.consec_losses = 0
        else:
            b.consec_losses += 1
        self._learn(b, pos, pnl)
        self._stress(b, win)
        self.contest.bot_trade(b, pnl)
        if pos["live"]:
            b.live_today += pnl
            b.live_total += pnl
            b.live_trades += 1
            b.live_wins += 1 if win else 0
            self.team_today += pnl
            self.team_total += pnl
            self.guards.on_live_close(b, pnl)
            lb = self.last_bar
            if lb is not None:
                self.trade_marks.append([lb.time, round(lb.close, 3), "close", pos["dir"], b.id, round(pnl, 2)])
            self.log("trade", f"{b.tag} ปิดออเดอร์เงินจริง {reason} {money(pnl)} | ทีมวันนี้ {money(self.team_today)}")
        if self.storage:
            self.storage.log_trade({"day": str(self.day), "bar": self.bar_i, "bot": b.id + 1, "name": b.name,
                                    "live": int(pos["live"]), "dir": pos["dir"], "entry": round(pos["entry"], 3),
                                    "pnl": round(pnl, 2), "reason": reason, "bar0": pos.get("bar0"),
                                    "risk": round(pos.get("risk") or 0.0, 3), "ses": pos.get("ses") or "",
                                    "hv": int(bool(pos.get("hv"))), "fam": b.fam,
                                    **{"c_" + k: round(v, 3) for k, v in (pos.get("comps") or {}).items()}})
        self._check_autosave(b)
        # ผู้คุม
        if b.consec_losses >= self.SV["max_consecutive_losses"]:
            self.jail(b, f"แพ้ติดกัน {b.consec_losses} ไม้ ผิดไปจากสูตร")
        elif b.today < -self.SV["bot_daily_loss_limit"]:
            self.jail(b, f"ขาดทุนวันนี้ {money(b.today)} เกินเพดาน")
        elif b.live and not self.eligible(b):
            self.set_live(b, False, f"หลุดเกณฑ์: {self.why_not(b)}")
            self.fill_lineup(f"แทนที่ {b.tag}")
        # เป้า / เพดานขาดทุนของทีม
        if pos["live"]:
            if not self.target_hit and self.team_today >= self.T["daily_target"]:
                self.target_hit = True
                msg = f"ทีมเทรดจริงถึงเป้า {money(self.T['daily_target'])} แล้ว ({money(self.team_today)})"
                if self.T["stop_at_target"]:
                    msg += " ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน"
                    self.log("day", msg)
                    self.notify(msg)
                    self.close_all_live("ถึงเป้า ปิดเก็บกำไร")
                else:
                    self.log("day", msg)
                    self.notify(msg)
            if not self.halted and self.team_today <= -self.T["max_daily_loss"]:
                self.halted = True
                msg = f"ผู้คุมความเสี่ยง: ทีมขาดทุนวันนี้ {money(self.team_today)} ถึงเพดาน ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน"
                self.log("risk", msg)
                self.notify(msg)
                self.close_all_live("ถึงเพดานขาดทุนทีม")

    def close_all_live(self, reason):
        for b in self.bots:
            if b.pos and b.pos["live"]:
                self.close_bot(b, reason)

    def _stress(self, b, win):
        """แพ้แล้วเครียด ชนะแล้วผ่อนคลาย เครียดถึงเกณฑ์ (บอทกลุ่มเรียนรู้) ไปพักที่มุมพักผ่อน ไม่เปิดไม้ใหม่ชั่วคราว
        กันการเทรดตามอารมณ์ตอนแพ้ติดกัน (บอทในทีมเงินจริงอยู่ในความดูแลของผู้คุมแทน)"""
        b.stress = max(0.0, min(100.0, b.stress + (-10.0 if win else 12.0 + 6.0 * b.consec_losses)))
        if (self.rest_on and not self.qualifying and not b.live and b.jailed is None and b.rest_until is None
                and b.stress >= self.rest_stress):
            b.rest_until = self.bar_i + self.rest_bars
            b.rests += 1
            self.log("rest", f"{b.tag} เครียด ({b.stress:.0f}/100 แพ้ติดกัน {b.consec_losses} ไม้) ไปพักที่มุมพักผ่อน "
                             f"{self.rest_bars} นาที ไม่เปิดไม้ใหม่ระหว่างพัก")

    def _learn(self, b, pos, pnl):
        b.learn_count += 1
        b.learn_today += 1
        s = 1 if pnl > 0 else -1
        lr, g = b.g["lr"], b.g
        g["wT"] += lr * s * pos["comps"]["t"]
        g["wM"] += lr * s * pos["comps"]["m"]
        g["wB"] += lr * s * pos["comps"]["b"]
        g["thr"] += -0.004 if s > 0 else 0.008
        # เรียนรู้จากกำไรต่อไม้ (ไม่ใช่แค่อัตราชนะ) เพื่อไม่ให้สูตรไล่ชนะบ่อยด้วยการตั้ง TP แคบ SL กว้าง
        SL, TP = stop_keys()
        wr, e = b.recent_wr(), b.recent_exp()
        if e is not None and len(b.recent_pnl) >= 5:
            wins = [x for x in b.recent_pnl if x > 0]
            losses = [-x for x in b.recent_pnl if x < 0]
            aw = sum(wins) / len(wins) if wins else 0.0
            al = sum(losses) / len(losses) if losses else 0.0
            if e <= 0:
                if wr is not None and wr < 0.45:
                    g[TP] *= 0.97              # ชนะน้อยเกิน: เป้ากำไรใกล้ขึ้น
                elif al > aw:
                    g[SL] *= 0.97              # ชนะบ่อยแต่แพ้ทีละมาก: ตัดขาดทุนเร็วขึ้น
                else:
                    g["thr"] += 0.004          # สัญญาณยังไม่ดีพอ: เข้าเทรดเฉพาะจังหวะชัดขึ้น
            elif s > 0 and aw < 1.2 * al:
                g[TP] *= 1.005                 # ได้กำไรแล้ว ค่อยๆ ปล่อยกำไรให้วิ่งยาวขึ้น
        # เรียนรู้ว่าช่วงตลาดไหน / ตอนผันผวนแรง เทรดแล้วได้ผล
        if pos.get("ses"):
            g[pos["ses"]] += 0.03 * s
        if pos.get("hv"):
            g["vH"] += 0.04 * s
        # เรียนรู้ว่าควรเคารพเทรนด์ใหญ่แค่ไหน
        h = pos["comps"].get("h", 0)
        if h < 0:                        # ไม้นี้เทรดสวนเทรนด์ใหญ่
            g["htfW"] += 0.05 if s < 0 else -0.03
        elif h > 0 and s > 0:            # ตามเทรนด์ใหญ่แล้วชนะ
            g["htfW"] += 0.01
        fix_genome(g)

    # ================= ผู้คุม / เขตห้ามเทรด =================
    def jail(self, b, reason, by_user=False):
        if b.jailed:
            return False
        if b.pos and not self.close_bot(b, "ผู้คุมปิดออเดอร์"):
            return False
        if b.jailed:       # ถูกขังระหว่างปิดออเดอร์ไปแล้ว
            return True
        t = self.teachers.best()
        m = None if t else self.best_bot(b.id)
        b.jailed = {"until": self.bar_i + self.SV["jail_bars"], "mentor": m.id if m else None,
                    "teacher": t.id if t else None, "reason": reason}
        b.violations += 1
        if not by_user:
            self.guards.count["discipline"] = self.guards.count.get("discipline", 0) + 1
        was_live = b.live
        b.live = False
        self.log("jail", f"{'สั่งขัง' if by_user else 'ผู้คุมวินัยจับ'} {b.tag}{' (ถูกถอดจากทีมเทรดจริง)' if was_live else ''}"
                         f" เข้าเขตห้ามเทรด: {reason}" + (f" ส่งไปเรียนกับ{t.name}" if t else f" ส่งไปเรียนกับ {m.tag}" if m else ""))
        if was_live:
            self.notify(f"ผู้คุมวินัยจับ {b.tag} ออกจากทีมเทรดจริง: {reason}")
            self.fill_lineup(f"แทนที่ {b.tag}")
        return True

    def release(self, b, by_user=False):
        if not b.jailed:
            return False
        b.jailed = None
        b.consec_losses = 0
        self.log("teach", f"{b.tag} {'ถูกปล่อยก่อนกำหนด' if by_user else 'พ้นเขตห้ามเทรด'}")
        return True

    def teach(self, m, s, rate, why):
        if s.explorer or m.fam != s.fam:
            return                                # บอทนักสำรวจไม่ลอกสูตร / ลอกได้เฉพาะสายเดียวกัน
        for k, (lo, hi) in GENE.items():
            s.g[k] += (m.g[k] - s.g[k]) * rate + self.rng.gauss(0, 0.02) * (hi - lo)
        fix_genome(s.g)
        s.taught += 1
        self.log("teach", f"{m.tag} สอนสูตรให้ {s.tag} ({why})")

    def _peer_talk(self):
        """บอทกลุ่มเรียนรู้เดินไปคุยกับตัวอื่น ถ้าอีกฝ่ายเก่งกว่าก็ได้เคล็ดลับกลับมา"""
        for b in self.bots:
            if b.live or b.jailed or b.paused or b.rest_until is not None or self.rng.random() > 0.3:
                continue
            if b.explorer:
                b.chats += 1
                continue                          # นักสำรวจคุยได้ แต่ไม่ลอกสูตรเพื่อน
            others = [o for o in self.bots if o is not b and o.jailed is None]
            if not others:
                continue
            p = self.rng.choice(others)
            b.chats += 1
            if p.fam != b.fam:
                continue                          # คุยข้ามสายได้ แต่ลอกสูตรได้เฉพาะเพื่อนสายเดียวกัน
            # เรียนจากเพื่อนได้เฉพาะเมื่อสูตรของเพื่อนชนะถึงเกณฑ์ (75%) และเพื่อนทำผลงานดีกว่า
            if self.can_teach(p) and self.rank_score(p) > self.rank_score(b):
                # เรียนแค่บางส่วน และคิดต่อยอดเองเล็กน้อย เพื่อไม่ให้ทุกตัวกลายเป็นสูตรเดียวกันหมด
                for k, (lo, hi) in GENE.items():
                    b.g[k] += (p.g[k] - b.g[k]) * 0.01 + self.rng.gauss(0, 0.005) * (hi - lo)
                fix_genome(b.g)
                b.tips += 1

    # ================= สิ้นวัน =================
    def end_day(self):
        ranked = sorted(self.bots, key=lambda b: b.today, reverse=True)
        champ = ranked[0]
        hit = self.team_today >= self.T["daily_target"]
        live_names = ", ".join(f"{b.id + 1:02d}" for b in self.bots if b.live) or "-"
        if not self.qualifying:
            self.days_done += 1
            self.days_hit += 1 if hit else 0
            row = {"day": str(self.day), "team_pnl": round(self.team_today, 2), "hit_target": int(hit),
                   "halted": int(self.halted), "champion": champ.id + 1, "champion_pnl": round(champ.today, 2),
                   "live_bots": live_names}
            self.history.append(row)
            if self.storage:
                self.storage.log_day(row)
            msg = (f"จบวัน {self.day}: ทีมเทรดจริง {money(self.team_today)} "
                   f"{'ถึงเป้า' if hit else 'ไม่ถึงเป้า'} {money(self.T['daily_target'])} | "
                   f"แชมป์ {champ.tag} {money(champ.today)} | ถึงเป้า {self.days_hit}/{self.days_done} วัน")
            self.log("day", msg)
            self.notify(msg)
        if not self.qualifying:
            self.teachers.study()
            self.teachers.teach_class("คาบเรียนหลังจบวัน")
            self.rows.meet("ประชุมหัวแถวหลังจบวัน")
        self.contest.end_day(self.day)
        self.guards.end_day()
        if not self.qualifying:
            self.evolve()
            self.decrowd()
            for b in self.bots:                  # สายของบอทคงที่เสมอ (กันสูตรที่ลอกมาเปลี่ยนสาย)
                b.g["fam"] = b.fam
            self._learning_snapshot()
        self.day_stat = {"n": 0, "w": 0, "gain": 0.0, "loss": 0.0}
        if self.L["autosave_champion"] and champ.total > 0 and self.storage and not self.qualifying:
            self.save_strategy(champ, auto=True, why="แชมป์ประจำวัน")
        for b in self.bots:
            b.today = 0.0
            b.today_trades = 0
            b.today_wins = 0
            b.live_today = 0.0
            b.learn_today = 0
        self.team_today = 0.0
        self.spread_blocked = 0
        self.risk_blocks = 0
        self.target_hit = False
        self.halted = False
        self.day_no += 1
        self.select_lineup("จัดทีมใหม่ตามผลงาน")

    # ================= วิวัฒนาการ: บอทแย่สุดถูกแทนด้วยสูตรลูกของบอทเก่ง =================
    def evolve(self):
        self.evolved_today = []
        if not self.L.get("evolve", True):
            return []
        need = int(self.L.get("evolve_min_trades", self.T["min_trades"]))
        judged = [b for b in self.bots if len(b.recent_pnl) >= need and b.jailed is None]
        if len(judged) < 10:
            return []
        score = lambda b: b.recent_exp()
        parents = [b for b in sorted(judged, key=score, reverse=True) if score(b) > 0][:max(5, len(self.bots) // 10)]
        k = max(1, int(len(self.bots) * float(self.L.get("evolve_pct", 10)) / 100))
        if len(parents) < 2:
            # ยังไม่มีบอทที่กำไรต่อไม้เป็นบวกพอเป็นพ่อแม่: แทนบอทที่แย่ที่สุดด้วย "สูตรหน้าใหม่" แบบสุ่ม เพื่อค้นหาต่อ
            losers = [b for b in sorted(judged, key=score) if not b.live and b.pos is None][:k]
            out = []
            for b in losers:
                old = score(b)
                b.g = fix_genome({key: self.rng.uniform(lo, hi) for key, (lo, hi) in GENE.items()})
                b.g["fam"] = b.fam
                self._reborn(b, None)
                out.append(b.id)
                self.log("evolve", f"วิวัฒนาการ: {b.tag} (กำไรเฉลี่ย {money(old)}/ไม้) เปลี่ยนเป็นสูตรหน้าใหม่แบบสุ่ม รุ่นที่ {b.generation}")
            if out:
                self.log("evolve", f"วิวัฒนาการ: ยังไม่มีบอทที่กำไรต่อไม้เป็นบวกพอเป็นพ่อแม่ จึงแทนบอทที่แย่ที่สุด {len(out)} ตัว"
                                   " ด้วยสูตรหน้าใหม่เพื่อค้นหาสูตรใหม่")
            self.evolved_today = out
            return out
        # ถ้าสูตรของบอทเริ่มเหมือนกันหมด ให้สูตรลูกกลายพันธุ์มากขึ้น เพื่อไม่ให้แพ้พร้อมกันทั้งระบบเมื่อตลาดเปลี่ยน
        div = self.diversity() or 0
        sigma = 0.05 if div >= float(self.L.get("min_diversity", 8)) else 0.15
        losers = [b for b in sorted(judged, key=score) if score(b) < 0 and not b.live and b.pos is None
                  and b not in parents][:k]
        out = []
        for b in losers:
            same = [p for p in parents if p.fam == b.fam]
            if len(same) < 2:                     # สายนี้ยังไม่มีพ่อแม่ที่กำไร: ให้สูตรหน้าใหม่ในสายเดิม
                old = score(b)
                b.g = fix_genome({key: self.rng.uniform(lo, hi) for key, (lo, hi) in GENE.items()})
                b.g["fam"] = b.fam
                self._reborn(b, None)
                out.append(b.id)
                self.log("evolve", f"วิวัฒนาการ: {b.tag} (กำไรเฉลี่ย {money(old)}/ไม้) ได้สูตรหน้าใหม่ในสายเดิม รุ่นที่ {b.generation}")
                continue
            p1, p2 = self.rng.sample(same, 2)
            child = {}
            for key, (lo, hi) in GENE.items():
                child[key] = (p1.g if self.rng.random() < 0.5 else p2.g)[key] + self.rng.gauss(0, sigma) * (hi - lo)
            fix_genome(child)
            # รักษาความหลากหลาย: ถ้าลูกเหมือนบอทตัวอื่นเกินไป ให้กลายพันธุ์เพิ่ม
            for _ in range(3):
                near = min(genome_dist(child, o.g) for o in self.bots if o is not b) / len(GENE)
                if near >= 0.03:
                    break
                for key, (lo, hi) in GENE.items():
                    child[key] += self.rng.gauss(0, 0.06) * (hi - lo)
                fix_genome(child)
            old = score(b)
            b.g = child
            b.g["fam"] = b.fam
            self._reborn(b, [p1.id, p2.id])
            out.append(b.id)
            self.log("evolve", f"วิวัฒนาการ: {b.tag} (กำไรเฉลี่ย {money(old)}/ไม้) ได้สูตรใหม่รุ่นที่ {b.generation} "
                               f"ลูกของ {p1.tag} กับ {p2.tag}")
        if out:
            self.log("evolve", f"วิวัฒนาการ: แทนที่สูตรบอทที่แย่ที่สุด {len(out)} ตัวด้วยสูตรลูกของบอทที่ได้กำไรต่อไม้ดีที่สุด"
                               + (f" (ความหลากหลายเหลือ {div}% ให้สูตรลูกกลายพันธุ์มากขึ้น)" if sigma > 0.05 else ""))
        self.evolved_today = out
        return out

    def _reborn(self, b, parents):
        """บอทได้สูตรใหม่: ล้างผลเทรดเก่าที่เป็นของสูตรเดิม"""
        b.g0 = dict(b.g)
        b.recent.clear()
        b.recent_pnl.clear()
        b.hist_pnl.clear()
        b.exam = None
        b.consec_losses = 0
        b.generation = (b.generation or 0) + 1
        b.parents = parents

    def decrowd(self):
        """กันบอทลอกสูตรกันจนเหมือนกันหมด: ถ้าความหลากหลายต่ำกว่าเกณฑ์ บอทที่สูตร "เหมือนคนอื่นที่สุด"
        (ใกล้ค่าเฉลี่ยของทั้งกลุ่ม) จะถูกขยับสูตรออกไปแบบสุ่ม ยกเว้นทีมเงินจริงและบอทที่ถือออเดอร์"""
        lim = float(self.L.get("min_diversity", 8))
        div = self.diversity() or 0
        if div >= lim:
            return 0
        keys = list(GENE)
        mean = {k: sum(b.g[k] for b in self.bots) / len(self.bots) for k in keys}
        cand = sorted([b for b in self.bots if not b.live and b.pos is None and b.jailed is None],
                      key=lambda b: genome_dist(b.g, mean))
        n = max(1, len(self.bots) // 5)
        for b in cand[:n]:
            for k, (lo, hi) in GENE.items():
                b.g[k] += self.rng.gauss(0, 0.12) * (hi - lo)
            fix_genome(b.g)
        self.log("evolve", f"ความหลากหลายของสูตรเหลือ {div}% (ต่ำกว่า {lim:g}%) ขยับสูตรของบอท {n} ตัวที่เหมือนคนอื่นที่สุดออกไป"
                           f" ให้ทีมมีหลายแนวคิด → เหลือ {self.diversity()}%")
        return n

    def diversity(self):
        """ความหลากหลายของสูตร (0-100): ระยะห่างเฉลี่ยระหว่างสูตรของบอท สุ่มเทียบ 200 คู่"""
        n = len(self.bots)
        if n < 2:
            return None
        r = random.Random(7)
        pairs = [r.sample(range(n), 2) for _ in range(200)]
        return round(100 * sum(genome_dist(self.bots[i].g, self.bots[j].g) for i, j in pairs) / len(pairs) / len(GENE), 1)

    def _learning_snapshot(self):
        """เส้นการเรียนรู้: ผลของทั้งระบบในวันนี้ เก็บไว้ดูว่าบอทเก่งขึ้นจริงไหม"""
        d = self.day_stat
        exps = [b.recent_exp() for b in self.bots if len(b.recent_pnl) >= self.T["min_trades"]]
        wrs = [b.recent_wr() for b in self.bots if len(b.recent) >= self.T["min_trades"]]
        row = {"day": str(self.day), "trades": d["n"],
               "win_rate": round(d["w"] / d["n"] * 100, 1) if d["n"] else None,
               "avg_pnl": round((d["gain"] - d["loss"]) / d["n"], 3) if d["n"] else None,
               "profit_factor": round(min(9.99, d["gain"] / d["loss"]), 2) if d["loss"] > 0 else None,
               "recent_wr": round(sum(wrs) / len(wrs) * 100, 1) if wrs else None,
               "recent_avg_pnl": round(sum(exps) / len(exps), 3) if exps else None,
               "positive_bots": sum(1 for e in exps if e > 0), "eligible": sum(1 for b in self.bots if self.eligible(b)),
               "can_teach": sum(1 for b in self.bots if self.can_teach(b)), "evolved": len(self.evolved_today),
               "diversity": self.diversity(), "team_pnl": round(self.team_today, 2)}
        self.learn_hist = (self.learn_hist + [row])[-400:]
        if self.storage:
            try:
                self.storage._append_csv(os.path.join(self.storage.folder, "learning.csv"), row)
            except OSError:
                pass
        if row["avg_pnl"] is not None:
            self.log("evolve", f"เส้นการเรียนรู้ {row['day']}: บอททุกตัวเทรด {row['trades']} ไม้ ชนะ {row['win_rate']}% "
                               f"กำไรเฉลี่ย {money(row['avg_pnl'])}/ไม้ PF {row['profit_factor']} "
                               f"บอทที่กำไรต่อไม้เป็นบวก {row['positive_bots']} ตัว")

    def autosave_ok(self, b):
        """ผ่านเกณฑ์เซฟอัตโนมัติไหม: ชนะถึงเกณฑ์ในไม้ล่าสุด (มีไม้พอ) และมีกำไรสะสมถ้าเปิดเงื่อนไขนี้"""
        wr = b.recent_wr()
        return (len(b.recent) >= self.T["min_trades"] and wr is not None and wr * 100 >= self.autosave["wr"]
                and (not self.autosave["profit"] or b.total > 0))

    def _check_autosave(self, b):
        if not self.autosave["on"] or self.qualifying:
            return
        ok = self.autosave_ok(b)
        if ok and b.id not in self._was_qual:
            last = self._autosaved.get(b.id)
            # เซฟเมื่อเพิ่งผ่านเกณฑ์ และสูตรต่างจากที่เคยเซฟอัตโนมัติไว้ (ไม่เซฟสูตรเดิมซ้ำ)
            if last is None or genome_dist(b.g, last) / len(GENE) > 0.02:
                self.save_strategy(b, auto=True, why=f"ชนะ {b.recent_wr() * 100:.0f}% ใน {len(b.recent)} ไม้ล่าสุด")
                self._autosaved[b.id] = dict(b.g)
                self.autosave_n += 1
        if ok:
            self._was_qual.add(b.id)
        else:
            self._was_qual.discard(b.id)

    def set_autosave(self, on=None, wr=None, profit=None):
        if on is not None:
            self.autosave["on"] = on
        if wr is not None:
            self.autosave["wr"] = wr
        if profit is not None:
            self.autosave["profit"] = profit
        self._was_qual = set()
        a = self.autosave
        msg = (f"เซฟสูตรอัตโนมัติ: {'เปิด' if a['on'] else 'ปิด'} | เกณฑ์ชนะ {a['wr']:.0f}% ขึ้นไป"
               f"{' และต้องมีกำไรสะสม' if a['profit'] else ''}")
        self.log("save", msg)
        if a["on"]:   # เปิดแล้ว เช็กบอทที่ผ่านเกณฑ์อยู่แล้วทันที
            for b in self.bots:
                self._check_autosave(b)
        return msg

    def save_strategy(self, b, auto=False, why=""):
        if b.total <= 0 and not (auto and not self.autosave["profit"]):
            return f"{b.tag} ยังไม่มีกำไรสะสม ({money(b.total)}) จึงยังเซฟสูตรไม่ได้"
        wr = b.recent_wr()
        doc = {"name": f"สูตร{b.name} {self.day}", "bot": b.id + 1, "genome": {k: round(v, 4) for k, v in b.g.items()},
               "total": round(b.total, 2), "recent_win_rate": round((wr or 0) * 100, 1), "trades": b.trades,
               "recent_trades": len(b.recent), "day": str(self.day), "auto": bool(auto),
               "reason": why or ("เซฟอัตโนมัติ" if auto else "เซฟด้วยมือ"),
               "time": dt.datetime.fromtimestamp(self.last_bar.time, dt.timezone.utc).strftime("%Y-%m-%d %H:%M")
               if self.last_bar else ""}
        if self.storage:
            self.storage.save_strategy(doc)
        self.rows.add_saved(doc)
        self.log("save", f"{'เซฟอัตโนมัติ' if auto else 'เซฟ'}สูตรของ {b.tag}{' (' + why + ')' if why else ''} "
                         f"กำไรสะสม {money(b.total)}")
        return f"เซฟสูตรของ {b.tag} แล้ว"

    # ================= เริ่มระบบ =================
    def qualify(self, bars):
        """รอบคัดเลือก: ทุกตัวฝึกเทรดกับข้อมูลย้อนหลัง แล้วเลือกตัวที่ผ่านเกณฑ์ขึ้นทีม"""
        self.qualifying = True
        for bar in bars:
            self.step(bar)
        for b in self.bots:     # ออเดอร์ฝึกที่ค้าง ปิดทิ้ง
            if b.pos and not b.pos["live"]:
                b.pos = None
            b.today = 0.0
            b.today_trades = 0
            b.today_wins = 0
        self.qualifying = False
        self.select_lineup("ผลงานรอบคัดเลือก")
        n = sum(b.live for b in self.bots)
        self.log("team", f"รอบคัดเลือกจบ มีบอทผ่านเกณฑ์ขึ้นทีม {n} ตัว" +
                 ("" if n else " ทีมเทรดจริงจะว่างจนกว่าจะมีตัวผ่านเกณฑ์"))

    def preload(self, bars):
        """ใช้ตอนเปิดระบบใหม่หลังจากเคยรันแล้ว: ใส่ราคาย้อนหลังโดยไม่เทรด"""
        for bar in bars:
            self.s.push(bar.close, bar.high, bar.low, bar.time)
            self.bars.append(bar)
            self.last_bar = bar
        if self.day is None and bars:
            self.day = bar_day(bars[-1].time)

    # ================= บันทึก/โหลดสถานะ =================
    def to_state(self):
        return {"bar_i": self.bar_i, "day": str(self.day) if self.day else None, "day_no": self.day_no,
                "team_today": self.team_today, "team_total": self.team_total, "target_hit": self.target_hit,
                "halted": self.halted, "manual_halt": self.manual_halt, "days_hit": self.days_hit,
                "days_done": self.days_done, "bots": [b.to_dict() for b in self.bots],
                "teachers": self.teachers.to_state(),
                "signals": {"hist": list(self.sig_hist), "marks": list(self.trade_marks), "log": list(self.sig_log),
                            "open_ids": [r["id"] for r in self.sig_open], "seq": self.sig_seq, "stats": self.sig_stats},
                "autosave": dict(self.autosave, saved={str(k): v for k, v in self._autosaved.items()}),
                "rows": self.rows.to_state(),
                "contest": self.contest.to_state(),
                "news": self.news.to_state(),
                "guards": self.guards.to_state(),
                "learn_hist": self.learn_hist, "day_stat": self.day_stat, "team_override": self.team_override,
                "cost_obs": self.cost_obs, "exam_stats": self.exam_stats, "guests": self.guests.to_state(),
                "dash": self.dash_info()}

    def dash_info(self):
        c = self.champion()
        lb = self.last_bar
        L = len(self.s.c)
        return {"price": lb.close if lb else None, "spread": lb.spread if lb else None,
                "atr": round(self.s.atr_at(int(IND["atr_period"]), L), 3) if L > 2 else None,
                "htf": ({"hours": 24, "dir": (1 if self.s.c[-1] > self.s.sma_at(1440, L) else -1)} if L > 1440 else None),
                "ind": {"atr_stops": bool(IND["atr_stops"]), "htf_filter": bool(IND["htf_filter"]), "tf": TF()},
                "bar_i": self.bar_i,
                "times": [b.time for b in list(self.bars)[-min(240, L):]],
                "sig": {"hist": list(self.sig_hist)[-240:], "marks": list(self.trade_marks)[-80:],
                        "now": self.signal_now(), "log": list(self.sig_log)[-40:], "stats": self.sig_stats},
                "bar_time": lb.time if lb else None, "prices": [round(x, 3) for x in self.s.c[-240:]],
                "events": list(self.events)[-120:], "history": self.history[-10:],
                "team": {k: self.T[k] for k in ("size", "min_win_rate", "recent_window", "min_trades",
                                                 "require_profit", "daily_target", "stop_at_target",
                                                 "max_daily_loss")},
                "elig": {str(b.id): [self.eligible(b), self.why_not(b)] for b in self.bots},
                "champion": c.id if c else None, "qualifying": self.qualifying,
                "jail_bars": self.SV["jail_bars"], "max_spread": self.SV["max_spread"],
                "rows": self.rows.dash(),
                "contest": self.contest.dash(),
                "news": self.news.dash(),
                "guards": self.guards.dash(),
                "guests": self.guests.dash(),
                "learn_hist": self.learn_hist[-180:], "diversity": self.diversity(),
                "team_rule": {"min_profit_factor": self.T.get("min_profit_factor", 1.3), "min_avg_pnl": self.T.get("min_avg_pnl", 0.0)},
                "exam": {"on": self.X["on"], "stat_n": self.X["stat_n"], "t_min": self.X["t_min"], "days": self.X["days"],
                         "segs": self.X["segs"], "seg_min": self.X["seg_min"], "robust_pct": self.X["robust_pct"],
                         "robust_share": self.X["robust_share"], "holdout": self.X["holdout"],
                         "slip": round(self.slip, 3), "slip_cfg": self.X["slip"], "comm": round(self.comm, 3),
                         "cost_obs": self.cost_obs, "stats": self.exam_stats,
                         "wf_rejected": self.teachers.wf_rejected, "robust_rejected": self.teachers.robust_rejected,
                         "stat_pass": sum(1 for b in self.bots if self.stat_ok(b)),
                         "exam_pass": sum(1 for b in self.bots if b.exam and b.exam.get("ok"))},
                "autosave": dict(self.autosave, count=self.autosave_n,
                                 ready=[b.id for b in self.bots if self.autosave_ok(b)]),
                "spread_blocked": self.spread_blocked,
                "can_teach": [b.id for b in self.bots if self.can_teach(b)], "teach_min": self.teach_min,
                "rest": {"on": self.rest_on, "stress": self.rest_stress, "bars": self.rest_bars,
                         "resting": [b.id for b in self.bots if b.rest_until is not None]},
                "learn_today": sum(b.learn_today for b in self.bots),
                "learn_total": sum(b.learn_count for b in self.bots),
                "teachers": [t.to_dict() for t in self.teachers.teachers],
                "lessons": self.teachers.lessons[-40:],
                "risk": {"vol_pause": max(0, self.vol_pause_until - self.bar_i),
                         "spread_block": bool(lb and lb.spread > self.SV["max_spread"]),
                         "halted": self.halted, "blocks_today": self.risk_blocks}}

    def load_state(self, st):
        for k in ["bar_i", "day_no", "team_today", "team_total", "target_hit", "halted", "manual_halt",
                  "days_hit", "days_done"]:
            if k in st:
                setattr(self, k, st[k])
        if st.get("day"):
            self.day = dt.date.fromisoformat(st["day"])
        if st.get("teachers"):
            self.teachers.load_state(st["teachers"])
        sg = st.get("signals")
        if sg:
            self.sig_hist.extend(x for x in sg.get("hist", []) if x and x[0] > 10 ** 8)
            self.trade_marks.extend(x for x in sg.get("marks", []) if x and x[0] > 10 ** 8)
            self.sig_log.extend(sg.get("log", []))
            ids = set(sg.get("open_ids", []))
            old_bar = st.get("bar_i", self.bar_i)
            for r in self.sig_log:
                if r["id"] in ids:
                    r["bar0"] = self.bar_i - max(0, old_bar - r["bar0"])
                    self.sig_open.append(r)
            self.sig_seq = sg.get("seq", 0)
            self.sig_stats.update(sg.get("stats", {}))
        if st.get("rows"):
            self.rows.load_state(st["rows"])
        if st.get("contest"):
            self.contest.load_state(st["contest"])
        self.learn_hist = st.get("learn_hist", self.learn_hist)
        for k, v in (st.get("team_override") or {}).items():
            if k in ("daily_target", "max_daily_loss", "min_win_rate"):
                self.T[k] = v
                self.team_override[k] = v
        if st.get("day_stat"):
            self.day_stat = st["day_stat"]
        if st.get("guests"):
            self.guests.load_state(st["guests"])
        if st.get("cost_obs"):
            self.cost_obs.update(st["cost_obs"])
        if st.get("exam_stats"):
            self.exam_stats.update(st["exam_stats"])
        if st.get("guards"):
            self.guards.load_state(st["guards"])
        if st.get("news"):
            self.news.load_state(st["news"])
        au = st.get("autosave")
        if au:
            for k in ("on", "wr", "profit"):
                if k in au:
                    self.autosave[k] = au[k]
            self._autosaved = {int(k): v for k, v in au.get("saved", {}).items()}
        by_id = {d["id"]: d for d in st.get("bots", [])}
        for b in self.bots:
            if b.id in by_id:
                b.load_dict(by_id[b.id])
        # bar0 ของออเดอร์เดิม อ้างอิงตัวนับแท่งเดิม ให้เริ่มนับใหม่
        for b in self.bots:
            if b.pos:
                b.pos["bar0"] = self.bar_i
            if b.jailed:
                b.jailed["until"] = self.bar_i + max(0, b.jailed["until"] - st.get("bar_i", self.bar_i))

    # ================= สรุป / คำสั่ง =================
    def status_text(self):
        live = [b for b in self.bots if b.live]
        lines = [f"วันที่ {self.day} ทีมเทรดจริงวันนี้ {money(self.team_today)} / เป้า {money(self.T['daily_target'])}"
                 f" สะสม {money(self.team_total)}" + (" [ถึงเป้าแล้ว]" if self.target_hit else "")
                 + (" [หยุดเพราะถึงเพดานขาดทุน]" if self.halted else "") + (" [หยุดเทรดจริงตามคำสั่ง]" if self.manual_halt else ""),
                 f"ทีมเทรดจริง {len(live)}/{self.T['size']}: " + (", ".join(b.tag for b in live) or "ว่าง")]
        for b in sorted(self.bots, key=lambda x: (x.recent_wr() or -1), reverse=True):
            wr = b.recent_wr()
            state = "ถูกขัง" if b.jailed else "เทรดจริง" if b.live else "พัก" if b.paused else "เรียนรู้"
            lines.append(f"  {b.id + 1:02d} {b.name:<8} {state:<8} ชนะล่าสุด {('%.0f%%' % (wr * 100)) if wr is not None else '-':>5}"
                         f" ({sum(b.recent)}/{len(b.recent)})  วันนี้ {money(b.today):>10}  สะสม {money(b.total):>10}"
                         + ("  ✓" if self.eligible(b) else ""))
        return "\n".join(lines)

    def command(self, line):
        """คำสั่งควบคุม เช่น  pause 5 | resume 5 | jail 5 | release 5 | close 5 | teach 3 12 | save 5 |
        promote 5 | demote 5 | lineup | target 150 | minwr 85 | halt | unhalt | status"""
        parts = line.strip().split()
        if not parts:
            return ""
        cmd, args = parts[0].lower(), parts[1:]

        def bot(i=0):
            try:
                n = int(args[i])
            except (IndexError, ValueError):
                raise ValueError("ต้องระบุหมายเลขบอท 1-%d" % len(self.bots))
            if not 1 <= n <= len(self.bots):
                raise ValueError("ไม่มีบอทหมายเลข %d" % n)
            return self.bots[n - 1]
        try:
            if cmd == "autosave":
                v = (args[0] if args else "").lower()
                if v in ("on", "off"):
                    return self.set_autosave(on=v == "on")
                if v == "profit" and len(args) > 1 and args[1] in ("on", "off"):
                    return self.set_autosave(profit=args[1] == "on")
                try:
                    wr = float(v)
                except ValueError:
                    return "ใช้ autosave on | off | 75 | profit on | profit off"
                if not 50 <= wr <= 100:
                    return "เกณฑ์ชนะต้องอยู่ระหว่าง 50 ถึง 100"
                return self.set_autosave(wr=wr)
            if cmd == "rows":
                self.rows.pick_leaders()
                out = [f"คลังสูตรที่ชนะ {self.rows.min_wr:.0f}% ขึ้นไป: {len(self.rows.library)} สูตร | ประชุมไปแล้ว {self.rows.meetings} ครั้ง"]
                for r in range(self.rows.n_rows):
                    lid, ls = self.rows.leaders[r], self.rows.lesson[r]
                    out.append(f"แถว {r + 1}: หัวแถว {self.bots[lid].tag if lid is not None else '(ยังไม่มี ไม้ยังไม่พอ)'}"
                               f" | สูตรประจำแถว {ls['name'] if ls else '-'} | สอนไป {self.rows.taught[r]} ครั้ง")
                return "\n".join(out)
            if cmd == "meeting":
                n = self.rows.meet("สั่งประชุมหัวแถว")
                if not self.rows.library:
                    return f"ยังไม่มีสูตรที่เซฟไว้ซึ่งชนะ {self.rows.min_wr:.0f}% ขึ้นไป หัวแถวยังไม่มีสูตรให้สอน"
                return f"ประชุมหัวแถวแล้ว หัวแถวสอนคนในแถวไป {n} ตัว"
            if cmd == "status":
                return self.status_text()
            if cmd == "news":
                if args and args[0].lower() == "refresh":
                    self.news.refresh()
                    return "สั่งห้องข่าวดึงข่าวและปฏิทินเศรษฐกิจใหม่แล้ว ผลจะขึ้นภายในไม่กี่วินาที"
                return self.news.text()
            if cmd == "contest":
                if args and args[0].lower() == "reset":
                    self.contest.reset()
                    return "เริ่มฤดูกาลแข่งขันใหม่แล้ว คะแนนและถ้วยถูกล้างทั้งหมด"
                return self.contest.text()
            if cmd == "teachers":
                lines = []
                for t in self.teachers.teachers:
                    r = t.result or {}
                    lines.append(f"{t.name} วิชา{t.subject} [{'กำลังคิดสูตรใหม่' if t.mode == 'thinking' else 'พร้อมสอน'}] ลองเทรด {sum(x.trades for x in t.slots)} ไม้: ศึกษา {t.studies} รอบ เจอสูตรดีขึ้น {t.improved} ครั้ง สอนไป {t.taught} ครั้ง"
                                 + (f" | ผลทดสอบล่าสุด กำไร {money(r['pnl'])} ชนะ {r['wr'] * 100:.0f}% ({r['trades']} ไม้)"
                                    if r.get("wr") is not None else " | ยังไม่มีผลทดสอบ"))
                return "\n".join(lines)
            if cmd == "study":
                self.teachers.study()
                return f"อาจารย์ทั้ง {len(self.teachers.teachers)} คนทดสอบสูตรกับราคาย้อนหลังแล้ว"
            if cmd in ("tteach", "tthink"):
                who = int(args[0]) if args else 0
                if not 0 <= who <= len(self.teachers.teachers):
                    return f"อาจารย์มีหมายเลข 1-{len(self.teachers.teachers)} (0 = อาจารย์ทุกคน)"
                if cmd == "tteach":
                    n = self.teachers.order_teach(who)
                    return (("อาจารย์ทุกคน" if who == 0 else self.teachers.teachers[who - 1].name) +
                            f" เดินสอนแล้ว สอนบอทไป {n} ตัว" + ("" if n else " (สูตรของอาจารย์ยังไม่ช่วยให้บอทตัวไหนดีขึ้นตอนนี้)"))
                names = self.teachers.order_think(who)
                return ", ".join(names) + f" กลับห้องอาจารย์ไปคิดและลองเทรดสูตรใหม่แล้ว (นานสุด {self.teachers.think_bars} นาที)"
            if cmd == "class":
                n = self.teachers.teach_class("สั่งเปิดคาบเรียน")
                return f"เปิดคาบเรียนแล้ว อาจารย์สอนบอทไป {n} ตัว" + ("" if n else " (ไม่มีสูตรของอาจารย์ที่ทดสอบแล้วช่วยให้บอทตัวไหนดีขึ้นในตอนนี้)")
            if cmd == "lineup":
                self.select_lineup("สั่งจัดทีมใหม่")
                return "จัดทีมแล้ว: " + (", ".join(b.tag for b in self.bots if b.live) or "ยังไม่มีตัวผ่านเกณฑ์")
            if cmd == "target":
                self.T["daily_target"] = float(args[0])
                self.team_override["daily_target"] = self.T["daily_target"]
                return f"ตั้งเป้ากำไรทีมเป็น {money(self.T['daily_target'])} ต่อวัน"
            if cmd == "maxloss":
                v = abs(float(args[0]))
                if not 5 <= v <= 100000:
                    return "เพดานขาดทุนต้องอยู่ระหว่าง 5 ถึง 100,000 ดอลลาร์"
                self.T["max_daily_loss"] = v
                self.team_override["max_daily_loss"] = v
                msg = f"ตั้งเพดานขาดทุนทีมเงินจริงเป็น {money(-v)} ต่อวัน"
                if not self.halted and self.team_today <= -v:
                    self.halted = True
                    self.close_all_live("ถึงเพดานขาดทุนทีม")
                    msg += f" (วันนี้ขาดทุนแล้ว {money(self.team_today)} ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงถึงสิ้นวัน)"
                self.log("risk", "ผู้คุมความเสี่ยง: " + msg)
                return msg
            if cmd == "minwr":
                v = float(args[0])
                if not 50 <= v <= 99:
                    return "เกณฑ์อัตราชนะต้องอยู่ระหว่าง 50 ถึง 99"
                self.T["min_win_rate"] = v
                self.team_override["min_win_rate"] = v
                self.mid_day()
                return f"ตั้งเกณฑ์ชนะเกิน {v:.0f}% แล้ว ผ่านเกณฑ์ {sum(self.eligible(b) for b in self.bots)} ตัว"
            if cmd == "halt":
                self.manual_halt = True
                self.close_all_live("หยุดตามคำสั่ง")
                return "ปิดออเดอร์จริงทั้งหมดและหยุดเทรดจริงแล้ว (บอทยังฝึกต่อ) พิมพ์ unhalt เพื่อกลับมาเทรด"
            if cmd == "unhalt":
                self.manual_halt = False
                return "กลับมาเทรดจริงแล้ว"
            if cmd == "pause":
                b = bot()
                b.paused = True
                if b.live:
                    self.set_live(b, False, "ถูกสั่งพัก")
                    self.fill_lineup(f"แทนที่ {b.tag}")
                return f"สั่งพัก {b.tag} แล้ว (ออเดอร์ที่ค้างยังมี SL/TP คุมอยู่)"
            if cmd == "resume":
                b = bot()
                b.paused = False
                return f"{b.tag} กลับมาเทรดแล้ว"
            if cmd == "jail":
                b = bot()
                return f"ขัง {b.tag} แล้ว" if self.jail(b, "ผู้ใช้สั่งขัง", by_user=True) else f"{b.tag} ถูกขังอยู่แล้ว"
            if cmd == "release":
                b = bot()
                return f"ปล่อย {b.tag} แล้ว" if self.release(b, by_user=True) else f"{b.tag} ไม่ได้ถูกขัง"
            if cmd == "close":
                b = bot()
                if not b.pos:
                    return f"{b.tag} ไม่มีออเดอร์ค้าง"
                return f"ปิดออเดอร์ {b.tag} แล้ว" if self.close_bot(b, "ปิดตามคำสั่ง") else "ปิดไม่สำเร็จ"
            if cmd == "teach":
                m, s = bot(0), bot(1)
                if m is s:
                    return "บอทสอนตัวเองไม่ได้"
                if not self.can_teach(m):
                    return f"{m.tag} ยังสอนตัวอื่นไม่ได้: {self.why_cant_teach(m)}"
                self.teach(m, s, 0.4, "สั่งจากผู้ใช้")
                return f"{m.tag} สอน {s.tag} แล้ว"
            if cmd == "save":
                return self.save_strategy(bot())
            if cmd == "promote":
                b = bot()
                if b.live:
                    return f"{b.tag} อยู่ในทีมแล้ว"
                if not self.eligible(b):
                    return f"{b.tag} ยังขึ้นทีมไม่ได้: {self.why_not(b)}"
                live = [x for x in self.bots if x.live]
                if len(live) >= self.T["size"]:
                    w = min(live, key=self.rank_score)
                    self.set_live(w, False, f"เปิดที่ให้ {b.tag}")
                self.set_live(b, True, "สั่งจากผู้ใช้")
                return f"{b.tag} ขึ้นทีมเทรดจริงแล้ว"
            if cmd == "demote":
                b = bot()
                if not b.live:
                    return f"{b.tag} อยู่ในกลุ่มเรียนรู้อยู่แล้ว"
                b.paused = True
                self.set_live(b, False, "สั่งจากผู้ใช้")
                self.fill_lineup(f"แทนที่ {b.tag}")
                b.paused = False
                return f"ถอน {b.tag} ไปกลุ่มเรียนรู้แล้ว"
        except (ValueError, IndexError) as e:
            return f"คำสั่งไม่ถูกต้อง: {e}"
        return "ไม่รู้จักคำสั่งนี้ ดูรายการคำสั่งใน README"
