"""อ่านรายงาน MT5 (Strategy Tester / ประวัติบัญชี) แล้วตรวจพฤติกรรมเสี่ยงของ EA

รองรับไฟล์:
  - รายงาน Strategy Tester: คลิกขวาแท็บ Backtest → Report → Open XML (.xlsx) หรือ HTML (.html)
  - รายงานประวัติบัญชี: แท็บ History → คลิกขวา → Report → Open XML / HTML
ควรตั้งภาษาโปรแกรม MT5 เป็น English ก่อนเซฟรายงาน (หัวตารางภาษาอื่นอาจอ่านไม่ออก)

พฤติกรรมเสี่ยงที่ตรวจ (ใช้ร่วมกับระบบติดตาม EA รับเชิญ):
  - เบิ้ลไม้ (Martingale): แพ้แล้วไม้ถัดไปใหญ่ขึ้น
  - วางไม้ซ้อน (Grid): ถือหลายไม้ทิศเดียวกันพร้อมกัน
  - ล็อกไม้ (Lock/Hedge): ถือไม้ซื้อและขายพร้อมกัน แทนการตัดขาดทุน
  - ไม่มี SL
  - ขาดทุนไม้เดียวกินกำไรหลายไม้
"""
import datetime as dt
import html
import os
import re
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser


# ======================= อ่านไฟล์เป็นตาราง (แถว x คอลัมน์) =======================
class _Rows(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows, self.cur, self.cell, self.in_cell = [], None, [], False

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self.cur = []
        elif tag in ("td", "th") and self.cur is not None:
            self.in_cell, self.cell = True, []
            span = dict(attrs).get("colspan")
            self._span = int(span) if span and span.isdigit() else 1

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self.cur is not None and self.in_cell:
            txt = " ".join("".join(self.cell).split())
            self.cur.append(txt)
            self.cur.extend([""] * (getattr(self, "_span", 1) - 1))
            self.in_cell = False
        elif tag == "tr" and self.cur is not None:
            if any(c for c in self.cur):
                self.rows.append(self.cur)
            self.cur = None

    def handle_data(self, data):
        if self.in_cell:
            self.cell.append(data)


def _read_html(path):
    raw = open(path, "rb").read()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        text = raw.decode("utf-16")
    else:
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("utf-16", errors="ignore") if raw.count(b"\x00") > len(raw) // 4 else raw.decode("latin-1")
    p = _Rows()
    p.feed(text)
    return p.rows


def _read_xlsx(path):
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    z = zipfile.ZipFile(path)
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", ns):
            shared.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["m"])))
    sheets = sorted(n for n in z.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", n))
    rows = []
    for sh in sheets:
        root = ET.fromstring(z.read(sh))
        for r in root.iter("{%s}row" % ns["m"]):
            out = {}
            for c in r.findall("m:c", ns):
                ref = c.get("r", "")
                col = 0
                for ch in re.match(r"[A-Z]*", ref).group(0):
                    col = col * 26 + ord(ch) - 64
                t = c.get("t")
                v = c.find("m:v", ns)
                if t == "s" and v is not None:
                    val = shared[int(v.text)]
                elif t == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter("{%s}t" % ns["m"]))
                else:
                    val = v.text if v is not None else ""
                out[max(col, 1) - 1] = (val or "").strip()
            if out and any(out.values()):
                rows.append([out.get(i, "") for i in range(max(out) + 1)])
    return rows


def read_rows(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return _read_xlsx(path)
    if ext == ".csv":
        import csv
        with open(path, encoding="utf-8-sig") as f:
            return [r for r in csv.reader(f) if any(r)]
    return _read_html(path)


# ======================= แปลงค่า =======================
def num(s):
    if s is None:
        return None
    s = str(s).replace("\xa0", "").replace(" ", "").replace(",", "")
    try:
        return float(s)
    except ValueError:
        return None


def ts(s):
    s = str(s).strip()
    if not s:
        return None
    try:                       # xlsx อาจเก็บวันเป็นตัวเลข (วันนับจาก 1899-12-30)
        f = float(s)
        if 20000 < f < 80000:
            return (dt.datetime(1899, 12, 30) + dt.timedelta(days=f)).replace(tzinfo=dt.timezone.utc).timestamp()
    except ValueError:
        pass
    for fmt in ("%Y.%m.%d %H:%M:%S", "%Y.%m.%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%d.%m.%Y %H:%M:%S"):
        try:
            return dt.datetime.strptime(s, fmt).replace(tzinfo=dt.timezone.utc).timestamp()
        except ValueError:
            pass
    return None


def _norm(h):
    return re.sub(r"\s+", " ", str(h).strip().lower().replace("/", " / ")).replace(" / ", "/")


def _find_table(rows, need):
    """หาหัวตารางที่มีคอลัมน์ครบตาม need คืน (index หัว, {ชื่อ: ตำแหน่ง})"""
    for i, r in enumerate(rows):
        names = [_norm(x) for x in r]
        if all(any(n == k or n.startswith(k) for n in names) for k in need):
            pos = {}
            for j, n in enumerate(names):
                if n and n not in pos:
                    pos[n] = j
                elif n:                      # ชื่อซ้ำ (เช่น Time / Price ตอนปิด) เก็บเป็นชื่อ_2
                    pos[n + "_2"] = j
            return i, pos
    return None, None


def _col(pos, *names):
    for n in names:
        if n in pos:
            return pos[n]
    return None


# ======================= ดึงรายการไม้ (position) =======================
def parse_positions(path):
    """คืน (รายการไม้, ข้อความอธิบายว่าอ่านจากตารางไหน)
    ไม้ = {open, close, dir, volume, entry, exit, sl, tp, profit, reason}"""
    rows = read_rows(path)
    # 1) ตาราง Positions (รายงานประวัติบัญชี) มี SL/TP และราคาปิดครบ
    hi, pos = _find_table(rows, ["time", "position", "type", "volume", "price", "profit"])
    if hi is not None and _col(pos, "time_2") is not None:
        out = []
        for r in rows[hi + 1:]:
            if len(r) < len(pos) - 2:
                break
            typ = str(r[pos["type"]]).lower()
            if typ not in ("buy", "sell"):
                if out:
                    break
                continue
            g = lambda k: r[pos[k]] if pos.get(k) is not None and pos[k] < len(r) else ""
            p = {"open": ts(g("time")), "close": ts(g("time_2")), "dir": 1 if typ == "buy" else -1,
                 "volume": num(g("volume")) or 0.0, "entry": num(g("price")), "exit": num(g("price_2")),
                 "sl": (num(g("s/l")) or 0.0) if "s/l" in pos else None, "tp": (num(g("t/p")) or 0.0) if "t/p" in pos else None,
                 "profit": (num(g("profit")) or 0.0) + (num(g("commission")) or 0.0) + (num(g("swap")) or 0.0),
                 "reason": None}
            if p["open"] and p["close"]:
                out.append(p)
        if out:
            return _mark_reasons(out), f"ตาราง Positions {len(out)} ไม้"
    # 2) ตาราง Deals (Strategy Tester / ประวัติบัญชี) จับคู่ไม้เข้า-ออกแบบ FIFO
    hi, pos = _find_table(rows, ["time", "deal", "type", "direction", "volume", "price"])
    if hi is None:
        raise ValueError("ไม่พบตาราง Deals หรือ Positions ในไฟล์ (ลองตั้งภาษา MT5 เป็น English แล้วเซฟรายงานใหม่)")
    orders = _orders_sl(rows)
    deals = []
    for r in rows[hi + 1:]:
        g = lambda k: r[pos[k]] if pos.get(k) is not None and pos[k] < len(r) else ""
        typ, d = str(g("type")).lower(), str(g("direction")).lower()
        if typ in ("balance", "credit", "") or d not in ("in", "out", "in/out", "inout"):
            if deals and not g("time"):
                break
            continue
        deals.append({"t": ts(g("time")), "type": typ, "dir": d, "vol": num(g("volume")) or 0.0,
                      "price": num(g("price")), "order": str(g("order")).strip(),
                      "comm": (num(g("commission")) or 0.0) + (num(g("fee")) or 0.0), "swap": num(g("swap")) or 0.0,
                      "profit": num(g("profit")) or 0.0, "comment": str(g("comment"))})
    deals.sort(key=lambda x: x["t"] or 0)
    openq = {1: [], -1: []}
    out = []
    for x in deals:
        side = 1 if x["type"] == "buy" else -1
        if x["dir"] == "in":
            o = orders.get(x["order"], {})
            openq[side].append({"open": x["t"], "dir": side, "volume": x["vol"], "left": x["vol"], "entry": x["price"],
                                "sl": o.get("sl"), "tp": o.get("tp"), "profit": x["comm"], "exit_w": 0.0, "close": None,
                                "reason": None})
            continue
        # ดีลออก: ปิดไม้ฝั่งตรงข้าม (ขายปิดไม้ซื้อ) ตามลำดับเข้าก่อนออกก่อน
        q = openq[-side]
        left = x["vol"]
        tot = x["vol"] or 1.0
        reason = "sl" if re.search(r"\bsl\b", x["comment"].lower()) else "tp" if re.search(r"\btp\b", x["comment"].lower()) else None
        while left > 1e-9 and q:
            p = q[0]
            take = min(left, p["left"])
            share = take / tot
            p["profit"] += (x["profit"] + x["swap"] + x["comm"]) * share
            p["exit_w"] += x["price"] * take
            p["left"] -= take
            left -= take
            if reason:
                p["reason"] = reason
            if p["left"] <= 1e-9:
                p["close"] = x["t"]
                p["exit"] = p["exit_w"] / p["volume"] if p["volume"] else x["price"]
                out.append(p)
                q.pop(0)
    for p in out:
        p.pop("left", None)
        p.pop("exit_w", None)
    out.sort(key=lambda p: p["open"] or 0)
    if not out:
        raise ValueError("อ่านตาราง Deals ได้ แต่จับคู่ไม้เข้า-ออกไม่ได้")
    return _mark_reasons(out), f"ตาราง Deals จับคู่ได้ {len(out)} ไม้"


def _orders_sl(rows):
    hi, pos = _find_table(rows, ["open time", "order", "type", "volume", "price", "s/l", "t/p"])
    if hi is None:
        return {}
    out = {}
    for r in rows[hi + 1:]:
        if len(r) <= max(pos["order"], pos["s/l"]):
            break
        o = str(r[pos["order"]]).strip()
        if not o or not o.replace(".", "").isdigit():
            if out:
                break
            continue
        out[o] = {"sl": num(r[pos["s/l"]]) or 0.0, "tp": num(r[pos["t/p"]]) or 0.0}   # ช่องว่าง = ไม่ได้ตั้ง
    return out


def _mark_reasons(ps):
    for p in ps:
        if p.get("reason") or p.get("exit") is None:
            continue
        for k in ("sl", "tp"):
            v = p.get(k)
            if v and abs(p["exit"] - v) <= max(0.05, abs(v) * 0.0002):
                p["reason"] = k
    return ps


# ======================= ตรวจพฤติกรรมเสี่ยง =======================
def risk_check(ps):
    """ps = รายการไม้ (ต้องมี open, close, dir, volume, profit; sl ถ้ามี) คืน dict ผลตรวจ + ธงเตือน"""
    ps = [p for p in ps if p.get("open") and p.get("close")]
    n = len(ps)
    res = {"trades": n, "flags": [], "notes": []}
    if not n:
        return res
    ps = sorted(ps, key=lambda p: p["open"])
    pnl = [p["profit"] for p in ps]
    wins = [x for x in pnl if x > 0]
    loss = [x for x in pnl if x < 0]
    res.update(net=sum(pnl), wins=len(wins), win_rate=len(wins) / n,
               avg_win=sum(wins) / len(wins) if wins else 0.0, avg_loss=sum(loss) / len(loss) if loss else 0.0,
               worst=min(pnl), best=max(pnl), pf=(sum(wins) / -sum(loss)) if loss else None)
    # ขาดทุนสะสมจากจุดสูงสุด (นับตามเวลาปิดไม้)
    eq = peak = dd = 0.0
    for p in sorted(ps, key=lambda p: p["close"]):
        eq += p["profit"]
        peak = max(peak, eq)
        dd = min(dd, eq - peak)
    res["max_dd_closed"] = dd
    # ไม้ที่เปิดพร้อมกัน: ทิศเดียวกัน (วางไม้ซ้อน) / ทิศตรงข้าม (ล็อกไม้)
    ev = []
    for p in ps:
        ev.append((p["open"], 1, p["dir"]))
        ev.append((p["close"], -1, p["dir"]))
    ev.sort(key=lambda e: (e[0], e[1]))
    cur = {1: 0, -1: 0}
    max_same = 0
    lock_n = 0
    lock_on = False
    for t, kind, d in ev:
        cur[d] += kind
        max_same = max(max_same, cur[d])
        both = cur[1] > 0 and cur[-1] > 0
        if both and not lock_on:
            lock_n += 1
        lock_on = both
    res["max_same_dir"] = max_same
    res["lock_events"] = lock_n
    # เบิ้ลไม้หลังแพ้
    vols = [p["volume"] for p in ps if p.get("volume")]
    up_after_loss = 0
    losses_followed = 0
    by_close = sorted(ps, key=lambda p: p["close"])
    for i, p in enumerate(by_close):
        if p["profit"] >= 0:
            continue
        nxt = next((q for q in ps if q["open"] >= p["close"]), None)
        if nxt is None or not p.get("volume"):
            continue
        losses_followed += 1
        if nxt["volume"] > p["volume"] * 1.3:
            up_after_loss += 1
    res["vol_ratio"] = (max(vols) / min(vols)) if vols and min(vols) > 0 else 1.0
    res["up_after_loss"] = up_after_loss
    res["losses_followed"] = losses_followed
    sl_known = [p for p in ps if p.get("sl") is not None]
    res["sl_known"] = len(sl_known)
    res["no_sl"] = sum(1 for p in sl_known if not p["sl"])
    holds = sorted((p["close"] - p["open"]) / 60 for p in ps)
    res["hold_median_min"] = holds[len(holds) // 2]
    res["hold_max_min"] = holds[-1]
    streak = best = 0
    for x in pnl:
        streak = streak + 1 if x < 0 else 0
        best = max(best, streak)
    res["max_consec_losses"] = best
    F = res["flags"]
    if losses_followed >= 3 and up_after_loss / losses_followed >= 0.3:
        F.append(("martingale", f"เบิ้ลไม้: หลังแพ้ ไม้ถัดไปใหญ่ขึ้น {up_after_loss}/{losses_followed} ครั้ง "
                                f"(ไม้ใหญ่สุดเป็น {res['vol_ratio']:.1f} เท่าของไม้เล็กสุด)"))
    elif res["vol_ratio"] >= 4:
        F.append(("lot_growth", f"ขนาดไม้ต่างกันมาก (ใหญ่สุด {res['vol_ratio']:.1f} เท่าของเล็กสุด)"))
    if max_same >= 3:
        F.append(("grid", f"วางไม้ซ้อน: ถือทิศเดียวกันพร้อมกันสูงสุด {max_same} ไม้"))
    if lock_n >= 3:
        F.append(("lock", f"ล็อกไม้: ถือไม้ซื้อและขายพร้อมกัน {lock_n} ครั้ง (แทนการตัดขาดทุน)"))
    if sl_known and res["no_sl"] / len(sl_known) >= 0.5:
        F.append(("no_sl", f"ไม่มี SL: {res['no_sl']}/{len(sl_known)} ไม้ไม่ตั้งจุดตัดขาดทุน"))
    if not sl_known:
        res["notes"].append("ไฟล์นี้ไม่มีข้อมูล SL ของแต่ละไม้ (ตรวจเรื่องไม่มี SL ไม่ได้)")
    if res["avg_win"] > 0 and res["worst"] < 0 and -res["worst"] >= 10 * res["avg_win"]:
        F.append(("tail", f"ขาดทุนไม้เดียว {res['worst']:,.2f} เท่ากับกำไรไม้ชนะเฉลี่ย {(-res['worst'] / res['avg_win']):.0f} ไม้"))
    return res


FLAG_TH = {"martingale": "เบิ้ลไม้", "lot_growth": "ขนาดไม้โต", "grid": "วางไม้ซ้อน", "lock": "ล็อกไม้",
           "no_sl": "ไม่มี SL", "tail": "ขาดทุนหนักไม้เดียว"}
