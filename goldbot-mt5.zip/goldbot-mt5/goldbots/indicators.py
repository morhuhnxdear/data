SERVER_OFFSET = 2    # เวลาเซิร์ฟเวอร์ MT5 เร็วกว่า UTC กี่ชั่วโมง (ตั้งจาก config ผ่าน bots.configure)
NAN = float("nan")


class Series:
    """เก็บราคาปิดและผลรวมสะสม เพื่อคำนวณ SMA / RSI / ความผันผวน ได้เร็ว"""

    def __init__(self):
        self.c = []
        self._cs = [0.0]
        self._g = [0.0]
        self._l = [0.0]
        self._d = [0.0]
        self._d2 = [0.0]
        self._tr = [0.0]      # ผลรวมสะสมของ True Range (สำหรับ ATR)
        self.t = []           # เวลาของแต่ละแท่ง (ใช้ดูช่วงตลาด)
        self._hl = {}
        # กรอบราคาช่วงเอเชีย (22-07 UTC) ล่าสุด ใช้ได้ช่วง 07-16 UTC วันเดียวกัน (สายเบรกกรอบเอเชีย)
        self._ahi = []
        self._alo = []
        self._asia = None     # [สูงสุด, ต่ำสุด] ระหว่างช่วงเอเชียที่กำลังเก็บ
        self._afroz = None    # (สูงสุด, ต่ำสุด, ชั่วโมงที่จบ)

    def __len__(self):
        return len(self.c)

    def push(self, close, high=None, low=None, t=0):
        self.t.append(t)
        high = close if high is None else high
        low = close if low is None else low
        pc = self.c[-1] if self.c else close
        tr = max(high - low, abs(high - pc), abs(low - pc))
        self._tr.append(self._tr[-1] + tr)
        d = close - self.c[-1] if self.c else 0.0
        self.c.append(close)
        self._cs.append(self._cs[-1] + close)
        self._g.append(self._g[-1] + (d if d > 0 else 0.0))
        self._l.append(self._l[-1] + (-d if d < 0 else 0.0))
        self._d.append(self._d[-1] + d)
        self._d2.append(self._d2[-1] + d * d)
        self._hl = {}
        ahi = alo = NAN
        if t:
            hrs = int(t) // 3600 - SERVER_OFFSET
            hu = hrs % 24
            if hu >= 22 or hu < 7:
                if self._asia is None:
                    self._asia = [high, low]
                else:
                    self._asia[0] = max(self._asia[0], high)
                    self._asia[1] = min(self._asia[1], low)
            else:
                if self._asia is not None:
                    self._afroz = (self._asia[0], self._asia[1], hrs)
                    self._asia = None
                if self._afroz is not None and hu < 16 and hrs - self._afroz[2] < 9:
                    ahi, alo = self._afroz[0], self._afroz[1]
        self._ahi.append(ahi)
        self._alo.append(alo)

    def sma(self, n):
        L = len(self.c)
        return (self._cs[L] - self._cs[L - n]) / n

    def rsi(self, n):
        L = len(self.c)
        g = self._g[L] - self._g[L - n]
        l = self._l[L] - self._l[L - n]
        if l <= 1e-12:
            return 100.0
        return 100.0 - 100.0 / (1.0 + g / l)

    def vol(self, n):
        L = len(self.c)
        m = (self._d[L] - self._d[L - n]) / n
        v = (self._d2[L] - self._d2[L - n]) / n - m * m
        return v ** 0.5 if v > 0 else 0.0

    # ---- ค่าเดียวกันแต่ ณ จุดในอดีต (L = จำนวนราคาปิดถึงแท่งนั้น) ใช้ตอนอาจารย์ทดสอบสูตรย้อนหลัง ----
    def sma_at(self, n, L):
        return (self._cs[L] - self._cs[L - n]) / n

    def rsi_at(self, n, L):
        g = self._g[L] - self._g[L - n]
        l = self._l[L] - self._l[L - n]
        if l <= 1e-12:
            return 100.0
        return 100.0 - 100.0 / (1.0 + g / l)

    def vol_at(self, n, L):
        m = (self._d[L] - self._d[L - n]) / n
        v = (self._d2[L] - self._d2[L - n]) / n - m * m
        return v ** 0.5 if v > 0 else 0.0

    def rsi_tf_at(self, n, tf, L):
        """RSI จากการเปลี่ยนแปลงของแท่ง TF (ราคาปิดทุก tf แท่ง) n แท่งล่าสุด ณ จุด L"""
        if tf == 1:
            return self.rsi_at(n, L)
        c = self.c
        g = l = 0.0
        for j in range(n):
            x = L - 1 - j * tf
            if x - tf < 0:
                break
            d = c[x] - c[x - tf]
            if d > 0:
                g += d
            else:
                l -= d
        if l <= 1e-12:
            return 100.0
        return 100.0 - 100.0 / (1.0 + g / l)

    def asia_at(self, L):
        """กรอบช่วงเอเชีย (สูงสุด, ต่ำสุด) ที่ใช้ได้ ณ จุด L หรือ (None, None)"""
        h = self._ahi[L - 1] if L - 1 < len(self._ahi) else NAN
        if h != h:
            return None, None
        return h, self._alo[L - 1]

    def atr_at(self, n, L):
        """Average True Range: ราคาวิ่งเฉลี่ยต่อแท่ง n แท่งล่าสุด"""
        n = min(n, L - 1)
        if n <= 0:
            return 0.0
        return (self._tr[L] - self._tr[L - n]) / n

    def hilo_at(self, n, L):
        w = self.c[L - 1 - n:L - 1]
        return max(w), min(w)

    def hilo(self, n):
        """สูงสุด/ต่ำสุดของ n แท่งก่อนหน้า (ไม่รวมแท่งปัจจุบัน)"""
        r = self._hl.get(n)
        if r is None:
            w = self.c[-1 - n:-1]
            r = (max(w), min(w))
            self._hl[n] = r
        return r
