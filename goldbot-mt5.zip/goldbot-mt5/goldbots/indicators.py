class Series:
    """เก็บราคาปิดและผลรวมสะสม เพื่อคำนวณ SMA / RSI / ความผันผวน ได้เร็ว"""

    def __init__(self):
        self.c = []
        self._cs = [0.0]
        self._g = [0.0]
        self._l = [0.0]
        self._d = [0.0]
        self._d2 = [0.0]
        self._hl = {}

    def __len__(self):
        return len(self.c)

    def push(self, close):
        d = close - self.c[-1] if self.c else 0.0
        self.c.append(close)
        self._cs.append(self._cs[-1] + close)
        self._g.append(self._g[-1] + (d if d > 0 else 0.0))
        self._l.append(self._l[-1] + (-d if d < 0 else 0.0))
        self._d.append(self._d[-1] + d)
        self._d2.append(self._d2[-1] + d * d)
        self._hl = {}

    def sma(self, n):
        L = len(self.c)
        return (self._cs[L] - self._cs[L - n]) / n

    def rsi(self, n):
        L = len(self.c)
        g = self._g[L] - self._g[L - n]
        l = self._l[L] - self._l[L - n]
        if l <= 1e-12:
            return 100.0
        return 100.0 - 100.0 / (1.0 + g / l)

    def vol(self, n):
        L = len(self.c)
        m = (self._d[L] - self._d[L - n]) / n
        v = (self._d2[L] - self._d2[L - n]) / n - m * m
        return v ** 0.5 if v > 0 else 0.0

    def hilo(self, n):
        """สูงสุด/ต่ำสุดของ n แท่งก่อนหน้า (ไม่รวมแท่งปัจจุบัน)"""
        r = self._hl.get(n)
        if r is None:
            w = self.c[-1 - n:-1]
            r = (max(w), min(w))
            self._hl[n] = r
        return r
