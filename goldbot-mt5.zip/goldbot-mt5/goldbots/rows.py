"""หัวหน้าแถว: บอทนั่งเป็นแถว (แถวละ 8 ตัวตามโต๊ะในออฟฟิศ) แต่ละแถวมีหัวแถว 1 ตัว
1) ประชุมหัวแถว: หัวแถวทุกคนนำสูตรที่เซฟไว้ซึ่งชนะถึงเกณฑ์ (ค่าเริ่มต้น 75%) มาทดสอบกับราคาล่าสุดด้วยกัน
   แต่ละคนเลือกสูตรที่ดีที่สุดสำหรับแถวตัวเองเป็น "สูตรประจำแถว" (หัวแถวเองก็ปรับตามถ้าช่วยให้ดีขึ้น)
2) หัวแถวสอนสูตรประจำแถวให้คนในแถวของตัวเอง เฉพาะเมื่อทดสอบแล้วว่าช่วยให้คนนั้นดีขึ้นจริง"""
from collections import deque

from .bots import FAMILIES, GENE, family_of, fix_genome, genome_from
from .fastsig import Window
from .teachers import grade, shadow_test_fast


def fmt(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


class Rows:
    def __init__(self, arena):
        self.a = arena
        c = arena.cfg.get("rows", {})
        self.enabled = bool(c.get("enabled", True))
        self.size = int(c.get("row_size", 10))
        self.every = int(c.get("meet_every", 120))
        # สูตรที่หัวแถวนำไปสอนต้องชนะไม่ต่ำกว่าเกณฑ์ที่บอทสอนกันได้ (ค่าเริ่มต้น 75%)
        self.min_wr = max(float(c.get("min_win_rate", 75)), float(arena.cfg.get("learning", {}).get("teach_min_win_rate", 75)))
        self.min_gain = float(c.get("min_gain", 1.0))
        self.max_lib = int(c.get("library_size", 40))
        self.window = int(c.get("window_bars", 600))
        # แข่งขันระหว่างแถว: หัวแถวของแถวที่อันดับท้าย ขออาจารย์มาช่วยสอนแถวตัวเองถี่ขึ้น
        self.push_every = int(c.get("push_every", 90))
        self.push_rows = int(c.get("push_rows", 3))
        self.n_rows = (len(arena.bots) + self.size - 1) // self.size
        self.leaders = [None] * self.n_rows        # id บอทหัวแถว
        self.lesson = [None] * self.n_rows         # สูตรประจำแถว {"name","genome","wr","pnl","trades"}
        self.taught = [0] * self.n_rows
        self.library = []                          # สูตรที่เซฟไว้และชนะถึงเกณฑ์
        self.top = []                              # สูตรเด่นจากการประชุมครั้งล่าสุด
        self.events = []                           # [ลำดับ, "meet"/"teach", แถว, หัวแถว, ผู้เรียน, ดีขึ้น]
        self.seq = 0
        self.meetings = 0
        self.last_meet = None
        self._warned = False
        self.cups = [0] * self.n_rows              # ถ้วยแถวชนะประจำวัน
        self.day_wins = []                         # [วัน, แถว, ชนะเฉลี่ย %]
        self.prev_rank = {}                        # อันดับตอนเริ่มวัน
        self.pushes = [0] * self.n_rows            # หัวแถวขออาจารย์ช่วยสอนกี่ครั้ง
        # หัวหน้าสาย: หัวแถว 2 คนของสายเดียวกันดูแลสายร่วมกัน
        # คุมความเสี่ยงของสาย: ไม้ล่าสุดของทั้งสาย (ไม้ฝึก + เงินจริง) ขาดทุนเฉลี่ย ให้สายนั้นพักจากทีมเงินจริง
        self.fam_guard = bool(c.get("family_guard", True))
        self.fam_window = int(c.get("family_window", 80))
        self.fam_min = int(c.get("family_min_trades", 40))
        self.fam_pnl = [deque(maxlen=self.fam_window) for _ in FAMILIES]
        self.fam_bench = [False] * len(FAMILIES)
        self.fam_bench_n = [0] * len(FAMILIES)
        self.fam_library = bool(c.get("family_library", True))   # ใช้เฉพาะสูตรในคลังของสายเดียวกัน
        self.push_mode = str(c.get("push_mode", "family"))       # family = แข่งกับแถวคู่ในสาย, overall = แถวท้ายตารางรวม
        self.push_gap = float(c.get("push_gap", 3.0))   # แถวในสายเดียวกันห่างกันกี่ % ถึงขออาจารย์ช่วย

    # ---------- ข้อมูล ----------
    def row_of(self, b):
        return b.id // self.size

    def fam_of_row(self, r):
        return family_of(r * self.size, len(self.a.bots))

    # ---------- หัวหน้าสาย: คุมความเสี่ยงของสาย ----------
    def on_trade(self, b, pnl):
        if 0 <= b.fam < len(self.fam_pnl):
            self.fam_pnl[b.fam].append(pnl)

    def fam_stat(self, f):
        q = self.fam_pnl[f]
        return len(q), (sum(q) / len(q) if q else None)

    def fam_ok(self, f):
        return not (self.fam_guard and 0 <= f < len(self.fam_bench) and self.fam_bench[f])

    def guard_families(self):
        """หัวแถวของแต่ละสายดูผลไม้ล่าสุดของทั้งสาย: ขาดทุนเฉลี่ยต่อไม้ = ตลาดตอนนี้ไม่เข้าทางสายนี้ สั่งพักจากทีมเงินจริง
        (ยังฝึกเทรดและเรียนต่อ) กลับมาได้เมื่อไม้ล่าสุดกลับมากำไรเฉลี่ยเป็นบวก"""
        a = self.a
        if not self.fam_guard or a.qualifying:
            return
        for f, (code, name, _) in enumerate(FAMILIES):
            n, avg = self.fam_stat(f)
            if n < self.fam_min or avg is None:
                continue
            leaders = [self.leaders[r] for r in range(self.n_rows) if self.fam_of_row(r) == f and self.leaders[r] is not None]
            who = " / ".join(a.bots[x].tag for x in leaders) or "หัวแถว"
            if not self.fam_bench[f] and avg < 0:
                self.fam_bench[f] = True
                self.fam_bench_n[f] += 1
                a.log("row", f"หัวหน้า{name} ({who}): ไม้ล่าสุด {n} ไม้ของสาย ขาดทุนเฉลี่ย {fmt(avg)}/ไม้ ตลาดตอนนี้ไม่เข้าทาง "
                             f"สั่งพักสายนี้จากทีมเงินจริง (ยังฝึกเทรดต่อ)")
                for b in a.bots:
                    if b.live and b.fam == f and not b.pos:
                        a.set_live(b, False, f"หัวหน้าสายสั่งพัก{name}")
                a.fill_lineup("แทนสายที่พัก")
            elif self.fam_bench[f] and avg > 0:
                self.fam_bench[f] = False
                a.log("row", f"หัวหน้า{name} ({who}): ไม้ล่าสุดกลับมากำไรเฉลี่ย {fmt(avg)}/ไม้ สายนี้กลับมาส่งตัวแทนลงทีมเงินจริงได้")

    def members(self, r):
        return self.a.bots[r * self.size:(r + 1) * self.size]

    def add_saved(self, doc):
        """เรียกเมื่อมีการเซฟสูตร: เก็บเข้าคลังถ้าชนะถึงเกณฑ์"""
        try:
            wr = float(doc.get("recent_win_rate", 0))
        except (TypeError, ValueError):
            return
        if wr < self.min_wr or not doc.get("genome"):
            return
        g = genome_from(doc["genome"])
        self.library = [x for x in self.library if x["name"] != doc.get("name")]
        self.library.append({"name": doc.get("name", "?"), "bot": doc.get("bot"), "wr": wr,
                             "total": doc.get("total", 0), "genome": g})
        self.library = self.library[-self.max_lib:]

    def load_library(self, items):
        for d in items or []:
            self.add_saved(d)

    def pick_leaders(self):
        a = self.a
        for r in range(self.n_rows):
            cand = [b for b in self.members(r) if b.jailed is None and len(b.recent) >= a.T["min_trades"]]
            best = max(cand, key=lambda b: (b.recent_wr() or 0, b.total)) if cand else None
            cur = self.leaders[r]
            cur_b = a.bots[cur] if cur is not None else None
            new = best.id if best else None
            # หัวแถวคนเดิมอยู่ต่อ เว้นแต่ถูกขัง ไม้ไม่พอ หรือมีคนในแถวชนะมากกว่าตั้งแต่ 10 จุดเปอร์เซ็นต์
            if (cur_b is not None and best is not None and cur_b in cand
                    and (best.recent_wr() or 0) - (cur_b.recent_wr() or 0) < 0.10):
                new = cur
            if new != self.leaders[r]:
                if new is not None and not a.qualifying:
                    b = a.bots[new]
                    a.log("row", f"{b.tag} เป็นหัวแถว {r + 1} (ชนะ {b.recent_wr() * 100:.0f}% ใน {len(b.recent)} ไม้ล่าสุด)")
                self.leaders[r] = new

    def _event(self, kind, r, leader, member=None, gain=None):
        self.seq += 1
        self.events.append([self.seq, kind, r, leader, member, None if gain is None else round(gain, 2)])
        self.events = self.events[-80:]

    # ---------- ประชุมหัวแถว + สอนในแถว ----------
    def meet(self, why="ประชุมตามรอบ"):
        a = self.a
        if not self.enabled or a.qualifying:
            return 0
        self.pick_leaders()
        if not self.library:
            if not self._warned:
                a.log("row", f"ประชุมหัวแถว: ยังไม่มีสูตรที่เซฟไว้ซึ่งชนะ {self.min_wr:.0f}% ขึ้นไป หัวแถวจะรอสูตรแรก")
                self._warned = True
            return 0
        bars = list(a.bars)[-self.window:]
        if len(bars) < self.window // 2:
            return 0
        L0 = len(a.s.c) - len(bars)
        W = Window(a.s, bars, L0)
        goal = a.T["min_win_rate"] / 100
        lot, hold = a.B["lot"], a.SV["max_hold_bars"]

        def test(g):
            return shadow_test_fast(g, W, lot, a.contract, a.comm, hold, a.slip)

        # 1) ทดสอบทุกสูตรในคลังกับราคาล่าสุด
        scored = []
        for doc in self.library:
            r = test(doc["genome"])
            scored.append((grade(r, goal), doc, r))
        scored.sort(key=lambda x: -x[0])
        self.top = [{"name": d["name"], "wr": d["wr"], "pnl": round(r["pnl"], 2), "trades": r["trades"],
                     "test_wr": round(r["wr"] * 100) if r["wr"] is not None else None} for _, d, r in scored[:3]]
        self.meetings += 1
        self.last_meet = a.last_bar.time if a.last_bar else None
        leaders = [x for x in self.leaders if x is not None]
        self._event("meet", -1, leaders)
        a.log("row", f"{why}: หัวแถว {len(leaders)} คนทบทวนสูตรที่ชนะ {self.min_wr:.0f}% ขึ้นไป {len(self.library)} สูตร "
                     f"สูตรเด่นตอนนี้: {self.top[0]['name']} (ทดสอบล่าสุด {fmt(self.top[0]['pnl'])})")
        taught = 0
        for r in range(self.n_rows):
            lid = self.leaders[r]
            if lid is None:
                continue
            ld = a.bots[lid]
            # หัวหน้าสาย: ใช้เฉพาะสูตรในคลังที่มาจากสายเดียวกัน (สูตรต่างสายใช้สัญญาณคนละแบบ สอนไปก็ไม่มีผล)
            f = self.fam_of_row(r)
            fam_scored = [x for x in scored if x[1]["genome"].get("fam") == f] if self.fam_library else scored
            if not fam_scored:
                self.lesson[r] = None
                continue
            # 2) หัวแถวเลือกสูตรประจำแถว: สูตรในคลังที่ช่วยหัวแถวได้มากที่สุด (ไม่มีสูตรไหนช่วย ใช้สูตรเด่นของที่ประชุม)
            base = grade(test(ld.g), goal)
            rate = 0.2 if ld.live else 0.5
            pick, pick_gain, pick_g = None, None, None
            for sc, doc, res in fam_scored[:8]:
                g = self._blend(ld.g, doc["genome"], rate)
                gain = grade(test(g), goal) - base
                if pick_gain is None or gain > pick_gain:
                    pick, pick_gain, pick_g = (sc, doc, res), gain, g
            if pick_gain is not None and pick_gain >= self.min_gain:
                sc, doc, res = pick
                if not ld.explorer:
                    ld.g = pick_g
                ld.taught += 1
            else:
                sc, doc, res = fam_scored[0]
            self.lesson[r] = {"name": doc["name"], "wr": doc["wr"], "genome": doc["genome"],
                              "pnl": round(res["pnl"], 2), "trades": res["trades"]}
            # 3) หัวแถวสอนคนในแถว
            for b in self.members(r):
                if b.id == lid or b.jailed is not None or b.explorer:
                    continue
                b0 = grade(test(b.g), goal)
                g = self._blend(b.g, doc["genome"], 0.15 if b.live else 0.35)
                gain = grade(test(g), goal) - b0
                if gain < self.min_gain:
                    continue
                b.g = g
                b.taught += 1
                self.taught[r] += 1
                taught += 1
                self._event("teach", r, lid, b.id, gain)
                a.log("teach", f"หัวแถว {r + 1} {ld.tag} สอน{doc['name']} ให้ {b.tag} (ทดสอบแล้วดีขึ้น {fmt(gain)})")
        if taught:
            a.log("row", f"หัวแถวสอนคนในแถวไป {taught} ตัว")
        return taught

    @staticmethod
    def _blend(g, target, rate):
        out = dict(g)
        for k in GENE:
            if k != "lr":
                out[k] = g[k] + (target[k] - g[k]) * rate
        return fix_genome(out)

    # ---------- แข่งขันระหว่างแถว ----------
    def standings(self):
        """อันดับแถว: เรียงตามอัตราชนะไม้ล่าสุดเฉลี่ยของคนในแถว (นับเฉพาะตัวที่มีไม้พอ) แล้วจึงกำไรวันนี้"""
        a = self.a
        out = []
        for r in range(self.n_rows):
            mem = self.members(r)
            rec = [b.recent_wr() for b in mem if b.recent_wr() is not None and len(b.recent) >= a.T["min_trades"]]
            allw = [b.wins / b.trades for b in mem if b.trades]
            out.append({"row": r, "leader": self.leaders[r], "n": len(mem), "counted": len(rec),
                        "wr": round(sum(rec) / len(rec) * 100, 1) if rec else None,
                        "wr_all": round(sum(allw) / len(allw) * 100, 1) if allw else None,
                        "elig": sum(1 for b in mem if a.eligible(b)), "live": sum(1 for b in mem if b.live),
                        "teach": sum(1 for b in mem if a.can_teach(b)), "jailed": sum(1 for b in mem if b.jailed),
                        "today": round(sum(b.today for b in mem), 2), "total": round(sum(b.total for b in mem), 2),
                        "cups": self.cups[r], "pushes": self.pushes[r]})
        # แข่งกันภายในสาย: แถวในสายเดียวกันใช้สูตรแบบเดียวกัน จึงวัดฝีมือหัวแถวได้ยุติธรรม
        for x in out:
            x["fam"] = self.fam_of_row(x["row"])
            n, avg = self.fam_stat(x["fam"])
            x["fam_avg"] = None if avg is None else round(avg, 3)
            x["fam_bench"] = not self.fam_ok(x["fam"])
        out.sort(key=lambda x: (x["fam"], x["wr"] is None, -(x["wr"] or 0), -x["today"]))
        seen = {}
        for x in out:
            k = seen.get(x["fam"], 0)
            seen[x["fam"]] = k + 1
            x["rank"] = k + 1
            x["of"] = sum(1 for y in out if y["fam"] == x["fam"])
            old = self.prev_rank.get(x["row"])
            x["move"] = None if old is None else old - (k + 1)
        return out

    def push(self):
        """หัวแถวของแถวอันดับท้าย ขออาจารย์มาช่วยสอนคนในแถว (สอนเฉพาะตัวที่ทดสอบแล้วดีขึ้น)"""
        a = self.a
        if not self.enabled or a.qualifying or not self.push_every:
            return 0
        st = [x for x in self.standings() if x["wr"] is not None]
        if len(st) < 2:
            return 0
        total = 0
        # แถวที่แพ้แถวคู่แข่งในสายเดียวกันเกิน push_gap % ขออาจารย์ช่วย
        losers = []
        if self.push_mode != "family":
            losers = sorted(st, key=lambda x: (x["wr"], x["today"]))[:self.push_rows]
        for f in ({x["fam"] for x in st} if self.push_mode == "family" else ()):
            pair = [x for x in st if x["fam"] == f]
            if len(pair) >= 2 and pair[0]["wr"] - pair[-1]["wr"] >= self.push_gap:
                losers.append(pair[-1])
        for x in losers[:max(1, self.push_rows)]:
            r, lid = x["row"], self.leaders[x["row"]]
            if lid is None:
                continue
            ld = a.bots[lid]
            mem = [b for b in self.members(r) if b.jailed is None]
            n = a.teachers.teach_class(f"หัวแถว {r + 1} ขออาจารย์ช่วยสอนแถว (แพ้แถวคู่แข่งในสาย)",
                                       forced=True, bots=mem)
            self.pushes[r] += 1
            total += n
            self._event("push", r, lid, None, n)
            a.log("row", f"หัวแถว {r + 1} {ld.tag}: แถวเราแพ้แถวคู่แข่งใน{FAMILIES[x['fam']][1]} (ชนะเฉลี่ย {x['wr']:.0f}%) "
                         f"ขออาจารย์มาช่วยสอน ได้สอนเพิ่ม {n} ตัว")
        return total

    def award_day(self):
        """ผู้คุมแถวตัดสินผลแข่งประจำวัน: แถวที่ชนะเฉลี่ยสูงสุดได้ถ้วย"""
        a = self.a
        st = self.standings()
        won = []
        for x in st:      # แถวอันดับ 1 ของแต่ละสาย (แข่งกับแถวคู่ในสายเดียวกัน)
            if x["rank"] == 1 and x["of"] >= 2 and x["wr"] is not None and x["counted"] >= max(2, self.size // 2):
                self.cups[x["row"]] += 1
                won.append(x)
                self.day_wins = (self.day_wins + [[str(a.day), x["row"], x["wr"]]])[-30:]
        if won:
            a.log("row", "ผู้คุมแถว: แถวที่ชนะคู่แข่งในสายวันนี้ " + ", ".join(
                f"แถว {x['row'] + 1} ({FAMILIES[x['fam']][1]} ชนะเฉลี่ย {x['wr']:.0f}%)" for x in won))
        self.prev_rank = {x["row"]: x["rank"] for x in st}
        top = max(won, key=lambda x: x["wr"]) if won else None
        return (top["row"], top["wr"]) if top else None

    def referee_text(self):
        st = self.standings()
        if not st or st[0]["wr"] is None:
            return "รอให้คนในแถวเทรดครบไม้ก่อนจึงจัดอันดับแถวได้"
        x = st[0]
        return f"นำอยู่: แถว {x['row'] + 1} ชนะเฉลี่ย {x['wr']:.0f}% · ถ้วยแถวแจกไปแล้ว {sum(self.cups)} ใบ"

    # ---------- บันทึก/แสดงผล ----------
    def to_state(self):
        return {"leaders": self.leaders, "lesson": self.lesson, "taught": self.taught, "events": self.events[-40:],
                "seq": self.seq, "meetings": self.meetings, "last_meet": self.last_meet, "top": self.top,
                "cups": self.cups, "day_wins": self.day_wins, "pushes": self.pushes,
                "prev_rank": {str(k): v for k, v in self.prev_rank.items()},
                "fam_bench": self.fam_bench, "fam_pnl": [[round(x, 3) for x in q] for q in self.fam_pnl]}

    def load_state(self, st):
        n = self.n_rows
        fb = st.get("fam_bench")
        if isinstance(fb, list):
            self.fam_bench = (fb + [False] * len(FAMILIES))[:len(FAMILIES)]
        for f, q in enumerate(st.get("fam_pnl") or []):
            if f < len(self.fam_pnl):
                self.fam_pnl[f].extend(q)
        for k in ("cups", "pushes"):
            v = st.get(k)
            if isinstance(v, list):
                setattr(self, k, (v + [0] * n)[:n])
        self.day_wins = st.get("day_wins", [])
        self.prev_rank = {int(k): v for k, v in st.get("prev_rank", {}).items() if int(k) < n}
        for k in ("leaders", "lesson", "taught"):
            v = st.get(k)
            if isinstance(v, list):
                v = (v + [None if k != "taught" else 0] * n)[:n]
                setattr(self, k, v)
        nb = len(self.a.bots)
        self.leaders = [x if isinstance(x, int) and 0 <= x < nb and x // self.size == r else None
                        for r, x in enumerate(self.leaders)]
        self.events = st.get("events", [])
        for k in ("seq", "meetings", "last_meet", "top"):
            if k in st:
                setattr(self, k, st[k])

    def dash(self):
        a = self.a
        rows = []
        for r in range(self.n_rows):
            mem = self.members(r)
            wrs = [b.recent_wr() for b in mem if b.recent_wr() is not None]
            ls = self.lesson[r]
            rows.append({"row": r, "leader": self.leaders[r], "members": [b.id for b in mem],
                         "avg_wr": round(sum(wrs) / len(wrs) * 100) if wrs else None, "taught": self.taught[r],
                         "lesson": {k: ls[k] for k in ("name", "wr", "pnl", "trades")} if ls else None})
        return {"enabled": self.enabled, "size": self.size, "rows": rows, "library": len(self.library),
                "min_wr": self.min_wr, "top": self.top, "meetings": self.meetings, "last_meet": self.last_meet,
                "events": self.events[-40:], "every": self.every,
                "standings": self.standings(), "day_wins": self.day_wins[-10:], "push_every": self.push_every,
                "next_in": (self.every - a.bar_i % self.every) if self.every else None,
                "families": [{"fam": f, "name": FAMILIES[f][1], "n": self.fam_stat(f)[0],
                              "avg": None if self.fam_stat(f)[1] is None else round(self.fam_stat(f)[1], 3),
                              "bench": not self.fam_ok(f), "benched": self.fam_bench_n[f]} for f in range(len(FAMILIES))],
                "fam_guard": self.fam_guard, "fam_window": self.fam_window}
