"""หัวหน้าแถว: บอทนั่งเป็นแถว (แถวละ 8 ตัวตามโต๊ะในออฟฟิศ) แต่ละแถวมีหัวแถว 1 ตัว
1) ประชุมหัวแถว: หัวแถวทุกคนนำสูตรที่เซฟไว้ซึ่งชนะถึงเกณฑ์ (ค่าเริ่มต้น 75%) มาทดสอบกับราคาล่าสุดด้วยกัน
   แต่ละคนเลือกสูตรที่ดีที่สุดสำหรับแถวตัวเองเป็น "สูตรประจำแถว" (หัวแถวเองก็ปรับตามถ้าช่วยให้ดีขึ้น)
2) หัวแถวสอนสูตรประจำแถวให้คนในแถวของตัวเอง เฉพาะเมื่อทดสอบแล้วว่าช่วยให้คนนั้นดีขึ้นจริง"""
from .bots import GENE, fix_genome
from .fastsig import Window
from .teachers import grade, shadow_test_fast


def fmt(v):
    return ("+" if v >= 0 else "-") + f"${abs(v):,.2f}"


class Rows:
    def __init__(self, arena):
        self.a = arena
        c = arena.cfg.get("rows", {})
        self.enabled = bool(c.get("enabled", True))
        self.size = int(c.get("row_size", 8))
        self.every = int(c.get("meet_every", 120))
        self.min_wr = float(c.get("min_win_rate", 75))
        self.min_gain = float(c.get("min_gain", 1.0))
        self.max_lib = int(c.get("library_size", 40))
        self.window = int(c.get("window_bars", 600))
        self.n_rows = (len(arena.bots) + self.size - 1) // self.size
        self.leaders = [None] * self.n_rows        # id บอทหัวแถว
        self.lesson = [None] * self.n_rows         # สูตรประจำแถว {"name","genome","wr","pnl","trades"}
        self.taught = [0] * self.n_rows
        self.library = []                          # สูตรที่เซฟไว้และชนะถึงเกณฑ์
        self.top = []                              # สูตรเด่นจากการประชุมครั้งล่าสุด
        self.events = []                           # [ลำดับ, "meet"/"teach", แถว, หัวแถว, ผู้เรียน, ดีขึ้น]
        self.seq = 0
        self.meetings = 0
        self.last_meet = None
        self._warned = False

    # ---------- ข้อมูล ----------
    def row_of(self, b):
        return b.id // self.size

    def members(self, r):
        return self.a.bots[r * self.size:(r + 1) * self.size]

    def add_saved(self, doc):
        """เรียกเมื่อมีการเซฟสูตร: เก็บเข้าคลังถ้าชนะถึงเกณฑ์"""
        try:
            wr = float(doc.get("recent_win_rate", 0))
        except (TypeError, ValueError):
            return
        if wr < self.min_wr or not doc.get("genome"):
            return
        g = fix_genome({k: float(doc["genome"].get(k, (lo + hi) / 2)) for k, (lo, hi) in GENE.items()})
        self.library = [x for x in self.library if x["name"] != doc.get("name")]
        self.library.append({"name": doc.get("name", "?"), "bot": doc.get("bot"), "wr": wr,
                             "total": doc.get("total", 0), "genome": g})
        self.library = self.library[-self.max_lib:]

    def load_library(self, items):
        for d in items or []:
            self.add_saved(d)

    def pick_leaders(self):
        a = self.a
        for r in range(self.n_rows):
            cand = [b for b in self.members(r) if b.jailed is None and len(b.recent) >= a.T["min_trades"]]
            best = max(cand, key=lambda b: (b.recent_wr() or 0, b.total)) if cand else None
            cur = self.leaders[r]
            cur_b = a.bots[cur] if cur is not None else None
            new = best.id if best else None
            # หัวแถวคนเดิมอยู่ต่อ เว้นแต่ถูกขัง ไม้ไม่พอ หรือมีคนในแถวชนะมากกว่าตั้งแต่ 10 จุดเปอร์เซ็นต์
            if (cur_b is not None and best is not None and cur_b in cand
                    and (best.recent_wr() or 0) - (cur_b.recent_wr() or 0) < 0.10):
                new = cur
            if new != self.leaders[r]:
                if new is not None and not a.qualifying:
                    b = a.bots[new]
                    a.log("row", f"{b.tag} เป็นหัวแถว {r + 1} (ชนะ {b.recent_wr() * 100:.0f}% ใน {len(b.recent)} ไม้ล่าสุด)")
                self.leaders[r] = new

    def _event(self, kind, r, leader, member=None, gain=None):
        self.seq += 1
        self.events.append([self.seq, kind, r, leader, member, None if gain is None else round(gain, 2)])
        self.events = self.events[-80:]

    # ---------- ประชุมหัวแถว + สอนในแถว ----------
    def meet(self, why="ประชุมตามรอบ"):
        a = self.a
        if not self.enabled or a.qualifying:
            return 0
        self.pick_leaders()
        if not self.library:
            if not self._warned:
                a.log("row", f"ประชุมหัวแถว: ยังไม่มีสูตรที่เซฟไว้ซึ่งชนะ {self.min_wr:.0f}% ขึ้นไป หัวแถวจะรอสูตรแรก")
                self._warned = True
            return 0
        bars = list(a.bars)[-self.window:]
        if len(bars) < self.window // 2:
            return 0
        L0 = len(a.s.c) - len(bars)
        W = Window(a.s, bars, L0)
        goal = a.T["min_win_rate"] / 100
        lot, hold = a.B["lot"], a.SV["max_hold_bars"]

        def test(g):
            return shadow_test_fast(g, W, lot, a.contract, a.comm, hold)

        # 1) ทดสอบทุกสูตรในคลังกับราคาล่าสุด
        scored = []
        for doc in self.library:
            r = test(doc["genome"])
            scored.append((grade(r, goal), doc, r))
        scored.sort(key=lambda x: -x[0])
        self.top = [{"name": d["name"], "wr": d["wr"], "pnl": round(r["pnl"], 2), "trades": r["trades"],
                     "test_wr": round(r["wr"] * 100) if r["wr"] is not None else None} for _, d, r in scored[:3]]
        self.meetings += 1
        self.last_meet = a.last_bar.time if a.last_bar else None
        leaders = [x for x in self.leaders if x is not None]
        self._event("meet", -1, leaders)
        a.log("row", f"{why}: หัวแถว {len(leaders)} คนทบทวนสูตรที่ชนะ {self.min_wr:.0f}% ขึ้นไป {len(self.library)} สูตร "
                     f"สูตรเด่นตอนนี้: {self.top[0]['name']} (ทดสอบล่าสุด {fmt(self.top[0]['pnl'])})")
        taught = 0
        for r in range(self.n_rows):
            lid = self.leaders[r]
            if lid is None:
                continue
            ld = a.bots[lid]
            # 2) หัวแถวเลือกสูตรประจำแถว: สูตรในคลังที่ช่วยหัวแถวได้มากที่สุด (ไม่มีสูตรไหนช่วย ใช้สูตรเด่นของที่ประชุม)
            base = grade(test(ld.g), goal)
            rate = 0.2 if ld.live else 0.5
            pick, pick_gain, pick_g = None, None, None
            for sc, doc, res in scored[:8]:
                g = self._blend(ld.g, doc["genome"], rate)
                gain = grade(test(g), goal) - base
                if pick_gain is None or gain > pick_gain:
                    pick, pick_gain, pick_g = (sc, doc, res), gain, g
            if pick_gain is not None and pick_gain >= self.min_gain:
                sc, doc, res = pick
                ld.g = pick_g
                ld.taught += 1
            else:
                sc, doc, res = scored[0]
            self.lesson[r] = {"name": doc["name"], "wr": doc["wr"], "genome": doc["genome"],
                              "pnl": round(res["pnl"], 2), "trades": res["trades"]}
            # 3) หัวแถวสอนคนในแถว
            for b in self.members(r):
                if b.id == lid or b.jailed is not None:
                    continue
                b0 = grade(test(b.g), goal)
                g = self._blend(b.g, doc["genome"], 0.15 if b.live else 0.35)
                gain = grade(test(g), goal) - b0
                if gain < self.min_gain:
                    continue
                b.g = g
                b.taught += 1
                self.taught[r] += 1
                taught += 1
                self._event("teach", r, lid, b.id, gain)
                a.log("teach", f"หัวแถว {r + 1} {ld.tag} สอน{doc['name']} ให้ {b.tag} (ทดสอบแล้วดีขึ้น {fmt(gain)})")
        if taught:
            a.log("row", f"หัวแถวสอนคนในแถวไป {taught} ตัว")
        return taught

    @staticmethod
    def _blend(g, target, rate):
        out = dict(g)
        for k in GENE:
            if k != "lr":
                out[k] = g[k] + (target[k] - g[k]) * rate
        return fix_genome(out)

    # ---------- บันทึก/แสดงผล ----------
    def to_state(self):
        return {"leaders": self.leaders, "lesson": self.lesson, "taught": self.taught, "events": self.events[-40:],
                "seq": self.seq, "meetings": self.meetings, "last_meet": self.last_meet, "top": self.top}

    def load_state(self, st):
        n = self.n_rows
        for k in ("leaders", "lesson", "taught"):
            v = st.get(k)
            if isinstance(v, list):
                v = (v + [None if k != "taught" else 0] * n)[:n]
                setattr(self, k, v)
        nb = len(self.a.bots)
        self.leaders = [x if isinstance(x, int) and 0 <= x < nb and x // self.size == r else None
                        for r, x in enumerate(self.leaders)]
        self.events = st.get("events", [])
        for k in ("seq", "meetings", "last_meet", "top"):
            if k in st:
                setattr(self, k, st[k])

    def dash(self):
        a = self.a
        rows = []
        for r in range(self.n_rows):
            mem = self.members(r)
            wrs = [b.recent_wr() for b in mem if b.recent_wr() is not None]
            ls = self.lesson[r]
            rows.append({"row": r, "leader": self.leaders[r], "members": [b.id for b in mem],
                         "avg_wr": round(sum(wrs) / len(wrs) * 100) if wrs else None, "taught": self.taught[r],
                         "lesson": {k: ls[k] for k in ("name", "wr", "pnl", "trades")} if ls else None})
        return {"enabled": self.enabled, "size": self.size, "rows": rows, "library": len(self.library),
                "min_wr": self.min_wr, "top": self.top, "meetings": self.meetings, "last_meet": self.last_meet,
                "events": self.events[-40:], "every": self.every,
                "next_in": (self.every - a.bar_i % self.every) if self.every else None}
