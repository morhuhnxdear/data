@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONIOENCODING=utf-8"
set "PY=python"
py -3.12 -c "import sys" >nul 2>&1 && set "PY=py -3.12"
echo ขั้นที่ 1/2: ดึงราคา XAUUSD แท่ง 1 นาทีย้อนหลัง 6 เดือนจาก MT5 (เปิด MT5 และล็อกอินไว้ก่อน)
%PY% export_history.py --days 183 --out data_6m || goto :err
for %%f in (data_6m\*_M1.csv) do set "CSV=%%f"
echo ขั้นที่ 2/2: ทดสอบย้อนหลัง 6 เดือน (ไม่แตะระบบเทรดสด ใช้เวลาประมาณ 15-40 นาที ระหว่างนี้หน้าจอจะเงียบ รอจนเสร็จ)
%PY% backtest.py --csv "%CSV%" --out out_6m --seed 7 > out_6m_report.txt 2>&1
type out_6m_report.txt
echo.
echo สรุปผลเก็บไว้ที่ out_6m_report.txt และไฟล์รายละเอียดในโฟลเดอร์ out_6m
pause
exit /b 0
:err
echo เกิดข้อผิดพลาด ดูข้อความด้านบน
pause
