@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONIOENCODING=utf-8"
set "PY=python"
py -3.12 -c "import sys" >nul 2>&1 && set "PY=py -3.12"
if "%~1"=="" (
  echo ลากไฟล์รายงาน Strategy Tester ของ EA ^(.xlsx หรือ .html^) มาวางบนไฟล์ analyze_ea.bat นี้
  echo วิธีได้ไฟล์: MT5 ^> Strategy Tester ^> รันจบ ^> คลิกขวาแท็บ Backtest ^> Report ^> Open XML
  pause
  exit /b 1
)
echo ขั้นที่ 1/2: ดึงราคา XAUUSD แท่ง 1 นาทีย้อนหลัง 400 วันจาก MT5 (เปิด MT5 และล็อกอินไว้ก่อน)
%PY% export_history.py --days 400 --out data_ea || goto :err
for %%f in (data_ea\*_M1.csv) do set "CSV=%%f"
echo ขั้นที่ 2/2: วิเคราะห์ EA และหาสูตรที่เข้าไม้ใกล้เคียง
%PY% analyze_ea.py --report "%~1" --prices "%CSV%" --name "%~n1" || goto :err
echo.
echo เสร็จแล้ว สรุปอยู่ในไฟล์ ea_report_*.txt และสูตรอยู่ใน ea_recipes.json (อาจารย์ชาร์ลีจะนำไปทดสอบเอง)
pause
exit /b 0
:err
echo เกิดข้อผิดพลาด ดูข้อความด้านบน
pause
