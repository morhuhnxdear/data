@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "Dashboard" python dashboard.py
python run_live.py
pause
