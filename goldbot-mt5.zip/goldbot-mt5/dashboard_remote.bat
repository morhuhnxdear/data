@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ใช้ได้เฉพาะตัวอักษรภาษาอังกฤษและตัวเลข อย่างน้อย 8 ตัว
set /p PW=ตั้งรหัสสำหรับสั่งการ: 
set /p VPW=ตั้งรหัสสำหรับดูอย่างเดียว (กด Enter ข้ามได้): 
if "%VPW%"=="" (python dashboard.py --remote --password %PW%) else (python dashboard.py --remote --password %PW% --view-password %VPW%)
pause
