@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
py -3.12 -c "import sys" >nul 2>&1 && set "PY=py -3.12"
echo ใช้ได้เฉพาะตัวอักษรภาษาอังกฤษและตัวเลข อย่างน้อย 8 ตัว
set /p PW=ตั้งรหัสสำหรับสั่งการ: 
set /p VPW=ตั้งรหัสสำหรับดูอย่างเดียว (กด Enter ข้ามได้): 
if "%VPW%"=="" (%PY% dashboard.py --remote --password %PW%) else (%PY% dashboard.py --remote --password %PW% --view-password %VPW%)
pause
