"""ตรวจว่า Python ที่ใช้รันมีไลบรารีครบไหม (ใช้แค่ไลบรารีมาตรฐาน ต้อง import ก่อน goldbots)

ถ้าพิมพ์ `python run_live.py` แล้ว Python ตัวนั้นไม่มี numpy / MetaTrader5:
1) หา Python ตัวอื่นในเครื่องที่มีไลบรารีครบอยู่แล้ว (ผ่านคำสั่ง py) แล้วสลับไปรันด้วยตัวนั้นเอง
2) ถ้าไม่มี แต่มี Python 3.12/3.11/3.13/3.10 อยู่ จะติดตั้งไลบรารีให้ตัวนั้นแล้วสลับไปใช้
3) ถ้าไม่มีเลย จะลองติดตั้งให้ Python ตัวที่ใช้อยู่
4) ถ้ายังไม่ได้ บอกวิธีแก้เป็นภาษาไทย
ปิดการตรวจได้ด้วยตัวแปร GOLDBOT_NO_BOOTSTRAP=1
"""
import importlib
import os
import subprocess
import sys

PIP_NAME = {"numpy": "numpy>=1.24", "MetaTrader5": "MetaTrader5>=5.0.45", "tzdata": "tzdata>=2024.1"}
TRY_VERSIONS = ("3.12", "3.11", "3.13", "3.10")


def _missing(mods):
    out = []
    for m in mods:
        try:
            importlib.import_module(m)
        except Exception:
            out.append(m)
    return out


def _ok(cmd):
    try:
        return subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60).returncode == 0
    except Exception:
        return False


def _rerun(cmd, label):
    print(f"[goldbot] สลับไปรันด้วย {label} ...", flush=True)
    env = dict(os.environ, GOLDBOT_REEXEC="1")
    try:
        rc = subprocess.call(cmd + [os.path.abspath(sys.argv[0])] + sys.argv[1:], env=env)
    except KeyboardInterrupt:
        rc = 0
    sys.exit(rc)


def ensure(need_mt5=False):
    if os.environ.get("GOLDBOT_NO_BOOTSTRAP"):
        return
    mods = ["numpy"] + (["MetaTrader5"] if need_mt5 and os.name == "nt" else [])
    miss = _missing(mods)
    if not miss:
        return
    me = "%d.%d" % sys.version_info[:2]
    print(f"[goldbot] Python {me} ที่ใช้อยู่ ({sys.executable}) ยังไม่มี: {', '.join(miss)}", flush=True)
    again = bool(os.environ.get("GOLDBOT_REEXEC"))

    if os.name == "nt" and not again:
        found = [v for v in TRY_VERSIONS if v != me and _ok(["py", f"-{v}", "-c", "pass"])]
        check = "import " + ", ".join(mods)
        # 1) ตัวที่มีไลบรารีครบอยู่แล้ว
        for v in found:
            if _ok(["py", f"-{v}", "-c", check]):
                _rerun(["py", f"-{v}"], f"Python {v}")
        # 2) ติดตั้งให้ตัวที่รองรับ
        for v in found:
            print(f"[goldbot] เจอ Python {v} กำลังติดตั้งไลบรารีให้ (ครั้งแรกครั้งเดียว) ...", flush=True)
            subprocess.call(["py", f"-{v}", "-m", "pip", "install", *PIP_NAME.values()])
            if _ok(["py", f"-{v}", "-c", check]):
                _rerun(["py", f"-{v}"], f"Python {v}")

    # 3) ติดตั้งให้ตัวที่ใช้อยู่
    if not again:
        print(f"[goldbot] กำลังติดตั้ง {', '.join(miss)} ให้ Python {me} ...", flush=True)
        rc = subprocess.call([sys.executable, "-m", "pip", "install", *[PIP_NAME[m] for m in miss + ["tzdata"]]])
        if rc == 0:
            _rerun([sys.executable], f"Python {me} (ติดตั้งเสร็จแล้ว)")

    # 4) บอกวิธีแก้
    print("\n[goldbot] ติดตั้งไลบรารีไม่สำเร็จ", flush=True)
    if "MetaTrader5" in miss:
        print(f"  ไลบรารี MetaTrader5 ยังไม่รองรับ Python {me} ให้ติดตั้ง Python 3.12 (64-bit) โดยพิมพ์:")
        print("      py install 3.12")
        print("  (ถ้าไม่มีคำสั่ง py ให้โหลดจาก https://www.python.org/downloads/ แล้วติ๊ก Add python.exe to PATH)")
        print("  จากนั้นพิมพ์ python run_live.py อีกครั้ง โปรแกรมจะสลับไปใช้ 3.12 และติดตั้งไลบรารีให้เอง")
    else:
        print("  ลองพิมพ์:  python -m pip install -r requirements.txt")
    sys.exit(1)
