<?php
// ===== ตั้งค่าสำนักงานแผนก IT =====
// ค่าเริ่มต้นของ XAMPP: MySQL user "root" ไม่มีรหัสผ่าน
// ฐานข้อมูลและตารางจะถูกสร้างให้อัตโนมัติในครั้งแรกที่เปิดหน้าเว็บ
return [
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'it_office',
    'db_user' => 'root',
    'db_pass' => '',

    // API key ของ Claude (สร้างได้ที่ https://console.anthropic.com/settings/keys)
    // หรือเว้นว่างไว้แล้วตั้ง environment variable ชื่อ ANTHROPIC_API_KEY แทน
    'anthropic_api_key' => '',

    // โมเดลที่ใช้สั่งงานและสรุปการประชุม
    'model'      => 'claude-sonnet-5-5',
    'max_tokens' => 16000,

    // ไฟล์ CA สำหรับ HTTPS (เว้นว่าง = ค้นหาไฟล์ของ XAMPP ให้อัตโนมัติ)
    // ถ้าเจอ error "SSL certificate problem" ให้ใส่ path เช่น 'C:/xampp/apache/bin/curl-ca-bundle.crt'
    'ca_bundle' => '',

    // ปลายทาง API (ไม่ต้องแก้)
    'api_url' => 'https://api.anthropic.com/v1/messages',
];
