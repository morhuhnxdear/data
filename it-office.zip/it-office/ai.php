<?php
// ส่งคำสั่งงานไปที่ Claude API แล้วสตรีมข้อความกลับมาที่หน้าเว็บ
declare(strict_types=1);

$cfg = require __DIR__ . '/config.php';
$key = getenv('ANTHROPIC_API_KEY') ?: (string)($cfg['anthropic_api_key'] ?? '');
$model = (string)($cfg['model'] ?? 'claude-sonnet-5-5');

function jsonOut(array $a, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($a, JSON_UNESCAPED_UNICODE);
    exit;
}

if (isset($_GET['ping'])) {
    jsonOut(['ok' => true, 'configured' => $key !== '', 'model' => $model, 'curl' => function_exists('curl_init')]);
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') jsonOut(['ok' => false, 'error' => 'ต้องใช้ POST'], 405);
if ($key === '') jsonOut(['ok' => false, 'code' => 'no_key', 'error' => 'ยังไม่ได้ใส่ API key ใน config.php'], 400);
if (!function_exists('curl_init')) jsonOut(['ok' => false, 'code' => 'upstream_error', 'error' => 'PHP ยังไม่ได้เปิด extension curl (แก้ใน php.ini: เอา ; หน้า extension=curl ออก)'], 500);

$in = json_decode(file_get_contents('php://input') ?: 'null', true);
$prompt = is_array($in) ? (string)($in['prompt'] ?? '') : '';
if (trim($prompt) === '') jsonOut(['ok' => false, 'code' => 'upstream_error', 'error' => 'ไม่มีข้อความคำสั่ง'], 400);
if (strlen($prompt) > 400000) jsonOut(['ok' => false, 'code' => 'prompt_too_large', 'error' => 'คำสั่งยาวเกินไป'], 413);

// CA bundle สำหรับ HTTPS บน Windows/XAMPP
$caCandidates = array_filter([
    (string)($cfg['ca_bundle'] ?? ''),
    (string)ini_get('curl.cainfo'),
    'C:/xampp/apache/bin/curl-ca-bundle.crt',
    dirname(PHP_BINARY) . '/extras/ssl/cacert.pem',
    '/Applications/XAMPP/xamppfiles/share/curl/curl-ca-bundle.crt',
    '/opt/lampp/share/curl/curl-ca-bundle.crt',
]);
$ca = '';
foreach ($caCandidates as $c) { if (@is_file($c)) { $ca = $c; break; } }

set_time_limit(0);
@ini_set('zlib.output_compression', '0');
if (function_exists('apache_setenv')) { @apache_setenv('no-gzip', '1'); }
while (ob_get_level() > 0) { ob_end_clean(); }

$status = 0; $started = false; $errBody = ''; $buf = ''; $stopReason = ''; $sent = 0;

$startStream = function () use (&$started) {
    if ($started) return;
    $started = true;
    http_response_code(200);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-cache');
    header('X-Accel-Buffering: no');
};

$ch = curl_init((string)($cfg['api_url'] ?? 'https://api.anthropic.com/v1/messages'));
$opts = [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'content-type: application/json',
        'x-api-key: ' . $key,
        'anthropic-version: 2023-06-01',
    ],
    CURLOPT_POSTFIELDS => json_encode([
        'model' => $model,
        'max_tokens' => (int)($cfg['max_tokens'] ?? 16000),
        'stream' => true,
        'messages' => [['role' => 'user', 'content' => $prompt]],
    ], JSON_UNESCAPED_UNICODE),
    CURLOPT_CONNECTTIMEOUT => 20,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_HEADERFUNCTION => function ($ch, $h) use (&$status) {
        if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) $status = (int)$m[1];
        return strlen($h);
    },
    CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$status, &$errBody, &$buf, &$stopReason, &$sent, $startStream) {
        if ($status !== 200) { $errBody .= $chunk; return strlen($chunk); }
        $startStream();
        $buf .= str_replace("\r\n", "\n", $chunk);
        while (($p = strpos($buf, "\n\n")) !== false) {
            $event = substr($buf, 0, $p);
            $buf = substr($buf, $p + 2);
            foreach (explode("\n", $event) as $line) {
                if (strncmp($line, 'data:', 5) !== 0) continue;
                $d = json_decode(trim(substr($line, 5)), true);
                if (!is_array($d)) continue;
                $type = $d['type'] ?? '';
                if ($type === 'content_block_delta' && ($d['delta']['type'] ?? '') === 'text_delta') {
                    echo $d['delta']['text']; $sent++;
                } elseif ($type === 'message_delta' && isset($d['delta']['stop_reason'])) {
                    $stopReason = (string)$d['delta']['stop_reason'];
                } elseif ($type === 'error') {
                    echo "\0[[ERROR]]" . ($d['error']['message'] ?? 'API error');
                }
            }
            flush();
        }
        if (connection_aborted()) return 0; // ผู้ใช้กดหยุด
        return strlen($chunk);
    },
];
if ($ca !== '') $opts[CURLOPT_CAINFO] = $ca;
curl_setopt_array($ch, $opts);
$ok = curl_exec($ch);
$cerr = curl_error($ch);
curl_close($ch);

if (!$started) {
    if ($ok === false && $status === 0) {
        $hint = stripos($cerr, 'SSL') !== false ? ' — ใส่ path ไฟล์ CA ใน config.php (ca_bundle)' : '';
        jsonOut(['ok' => false, 'code' => 'upstream_error', 'error' => 'เชื่อมต่อ Claude API ไม่ได้: ' . $cerr . $hint], 502);
    }
    $j = json_decode($errBody, true);
    $msg = is_array($j) ? (string)($j['error']['message'] ?? $errBody) : ($errBody ?: 'HTTP ' . $status);
    $code = in_array($status, [401, 403], true) ? 'auth'
        : (in_array($status, [429, 529], true) ? 'rate_limited'
        : ($status === 413 || stripos($msg, 'too long') !== false ? 'prompt_too_large' : 'upstream_error'));
    jsonOut(['ok' => false, 'code' => $code, 'error' => $msg], $status >= 400 ? $status : 502);
}
if ($ok === false && $cerr !== '' && !connection_aborted()) echo "\0[[ERROR]]" . $cerr;
if ($stopReason === 'max_tokens') echo "\0[[TRUNCATED]]";
flush();
