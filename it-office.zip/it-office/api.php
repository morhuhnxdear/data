<?php
// เก็บข้อมูลสำนักงาน (โครงสร้างฝ่าย งาน นัดหมาย) ลง MySQL
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$cfg = require __DIR__ . '/config.php';

function out(array $a, int $code = 200): void {
    http_response_code($code);
    echo json_encode($a, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host={$cfg['db_host']};port={$cfg['db_port']};charset=utf8mb4",
        $cfg['db_user'], $cfg['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    $dbName = preg_replace('/[^A-Za-z0-9_]/', '', (string)$cfg['db_name']);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$dbName`");
    $pdo->exec("CREATE TABLE IF NOT EXISTS office_config (
        id TINYINT PRIMARY KEY,
        data LONGTEXT NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    foreach (['tasks', 'meetings'] as $t) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `$t` (
            id VARCHAR(40) PRIMARY KEY,
            data LONGTEXT NOT NULL,
            created_at BIGINT NOT NULL DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
} catch (PDOException $e) {
    out(['ok' => false, 'error' => 'เชื่อมต่อ MySQL ไม่ได้ (เปิด MySQL ใน XAMPP Control Panel แล้วหรือยัง?): ' . $e->getMessage()], 500);
}

$action = $_GET['action'] ?? '';
$isPost = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
$body = [];
if ($isPost) {
    $raw = file_get_contents('php://input');
    $body = json_decode($raw ?: 'null', true);
    if (!is_array($body)) out(['ok' => false, 'error' => 'ข้อมูลที่ส่งมาไม่ใช่ JSON'], 400);
}

function validId($id): string {
    if (!is_string($id) || !preg_match('/^[A-Za-z0-9_-]{1,40}$/', $id)) out(['ok' => false, 'error' => 'id ไม่ถูกต้อง'], 400);
    return $id;
}
function saveRow(PDO $pdo, string $table, array $row): void {
    $id = validId($row['id'] ?? null);
    $st = $pdo->prepare("INSERT INTO `$table` (id, data, created_at) VALUES (?, ?, ?)
                         ON DUPLICATE KEY UPDATE data = VALUES(data)");
    $st->execute([$id, json_encode($row, JSON_UNESCAPED_UNICODE), (int)($row['createdAt'] ?? 0)]);
}

try {
    switch ($action) {
        case 'ping':
            out(['ok' => true]);

        case 'load':
            $c = $pdo->query("SELECT data FROM office_config WHERE id = 1")->fetchColumn();
            $tasks = array_map(fn($r) => json_decode($r['data'], true), $pdo->query("SELECT data FROM tasks ORDER BY created_at DESC")->fetchAll());
            $meets = array_map(fn($r) => json_decode($r['data'], true), $pdo->query("SELECT data FROM meetings ORDER BY created_at ASC")->fetchAll());
            out(['ok' => true, 'cfg' => $c ? json_decode($c, true) : null, 'tasks' => $tasks, 'meetings' => $meets]);

        case 'saveCfg':
            if (!$isPost || !is_array($body['cfg'] ?? null)) out(['ok' => false, 'error' => 'ไม่มีข้อมูลโครงสร้าง'], 400);
            $st = $pdo->prepare("INSERT INTO office_config (id, data) VALUES (1, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)");
            $st->execute([json_encode($body['cfg'], JSON_UNESCAPED_UNICODE)]);
            out(['ok' => true]);

        case 'saveTask':
            if (!$isPost) out(['ok' => false, 'error' => 'ต้องใช้ POST'], 405);
            saveRow($pdo, 'tasks', $body);
            out(['ok' => true]);

        case 'saveMeeting':
            if (!$isPost) out(['ok' => false, 'error' => 'ต้องใช้ POST'], 405);
            saveRow($pdo, 'meetings', $body);
            out(['ok' => true]);

        case 'delTask':
        case 'delMeeting':
            if (!$isPost) out(['ok' => false, 'error' => 'ต้องใช้ POST'], 405);
            $table = $action === 'delTask' ? 'tasks' : 'meetings';
            $pdo->prepare("DELETE FROM `$table` WHERE id = ?")->execute([validId($body['id'] ?? null)]);
            out(['ok' => true]);

        default:
            out(['ok' => false, 'error' => 'ไม่รู้จักคำสั่ง: ' . $action], 400);
    }
} catch (PDOException $e) {
    out(['ok' => false, 'error' => 'ฐานข้อมูลผิดพลาด: ' . $e->getMessage()], 500);
}
