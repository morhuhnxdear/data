# สำนักงานแผนก IT — ติดตั้งบน XAMPP

## ไฟล์ในโฟลเดอร์

| ไฟล์ | หน้าที่ |
|---|---|
| `index.html` | หน้าสำนักงาน (บอท ห้องประชุม ห้องพัก สั่งงาน จัดการฝ่าย) |
| `api.php` | บันทึก/โหลดข้อมูลจาก MySQL (สร้างฐานข้อมูล `it_office` ให้เองอัตโนมัติ) |
| `ai.php` | ส่งคำสั่งงานไปที่ Claude API แล้วสตรีมผลลัพธ์กลับ |
| `config.php` | ตั้งค่า MySQL และ API key |
| `.htaccess` | กันไม่ให้เปิด `config.php` ผ่านเว็บ |
| `install.sql` | สคริปต์สร้างตาราง (สำรอง ไม่จำเป็นต้องใช้) |

## ขั้นตอนติดตั้ง

1. แตกไฟล์ zip ไปที่ `C:\xampp\htdocs\it-office`
   (macOS: `/Applications/XAMPP/htdocs/it-office`, Linux: `/opt/lampp/htdocs/it-office`)
2. เปิด **XAMPP Control Panel** แล้วกด **Start** ที่ **Apache** และ **MySQL**
3. เปิด `config.php` ใส่ API key ที่ `'anthropic_api_key' => 'sk-ant-...'`
   (สร้าง key ได้ที่ https://console.anthropic.com/settings/keys)
4. เปิดเบราว์เซอร์ไปที่ **http://localhost/it-office/**
   มุมขวาบนจะขึ้นว่า "บันทึกข้อมูลในฐานข้อมูล MySQL (XAMPP)" แปลว่าพร้อมใช้งาน

> ต้องเปิดผ่าน `http://localhost/...` เท่านั้น ถ้าดับเบิลคลิกเปิด `index.html` ตรง ๆ PHP จะไม่ทำงาน

## ปัญหาที่พบบ่อย

| อาการ | วิธีแก้ |
|---|---|
| ขึ้นว่า "เชื่อมต่อฐานข้อมูลไม่ได้ บันทึกไว้ในเบราว์เซอร์นี้แทน" | ยังไม่ได้ Start MySQL หรือรหัสผ่าน root ไม่ตรงกับ `config.php` |
| "PHP ยังไม่ได้เปิด extension curl" | เปิด `C:\xampp\php\php.ini` เอา `;` หน้า `extension=curl` ออก แล้ว Restart Apache |
| "SSL certificate problem" | ใส่ `'ca_bundle' => 'C:/xampp/apache/bin/curl-ca-bundle.crt'` ใน `config.php` |
| "API key ไม่ถูกต้อง" | ตรวจ key ใน `config.php` และเครดิตในบัญชี Anthropic Console |
| ผลงานไม่ขึ้นทีละส่วน (มาทีเดียวตอนจบ) | ใน `php.ini` ตั้ง `output_buffering = Off` แล้ว Restart Apache |
| อยากเปลี่ยนโมเดล | แก้ `'model'` ใน `config.php` เช่น `claude-opus-5-5` (เก่งกว่าแต่แพงกว่า) หรือ `claude-haiku-5-5` (เร็วและถูก) |

## ข้อควรระวัง

- ระบบนี้ไม่มีการล็อกอิน ใช้ในเครื่องตัวเองหรือในวงแลนที่ไว้ใจได้เท่านั้น อย่าเปิดให้เข้าจากอินเทอร์เน็ต เพราะใครเข้าถึงได้ก็สั่งงานโดยใช้ API key ของคุณได้
- ค่าใช้จ่ายการสั่งงานและสรุปการประชุมคิดตามการใช้งาน API key
- สำรองข้อมูลได้จาก phpMyAdmin → ฐานข้อมูล `it_office` → Export
