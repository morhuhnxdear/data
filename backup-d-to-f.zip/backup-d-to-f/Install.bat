@echo off
rem Right-click this file and choose "Run as administrator"
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-BackupTask.ps1"
pause
