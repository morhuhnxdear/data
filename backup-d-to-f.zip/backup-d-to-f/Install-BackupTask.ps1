﻿<#
  Install-BackupTask.ps1  —  ตั้ง Task Scheduler ให้รัน Backup-DtoF.ps1 ทุก 3 วัน
  รันใน PowerShell แบบ "Run as administrator" บนเครื่องที่ต้องการ backup:
    powershell -ExecutionPolicy Bypass -File Install-BackupTask.ps1
    powershell -ExecutionPolicy Bypass -File Install-BackupTask.ps1 -Time 01:30
    powershell -ExecutionPolicy Bypass -File Install-BackupTask.ps1 -Uninstall
#>
param(
    [string]$Time = '02:00',
    [string]$InstallDir = 'C:\Scripts\Backup',
    [switch]$Uninstall
)
$ErrorActionPreference = 'Stop'
$TaskName = 'Backup D to F (every 3 days)'

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin){ Write-Host 'กรุณาเปิด PowerShell แบบ Run as administrator แล้วรันใหม่' -ForegroundColor Red; exit 1 }

if ($Uninstall){
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "ลบ task '$TaskName' แล้ว (ไฟล์ใน $InstallDir และข้อมูล backup ยังอยู่)"
    exit 0
}

foreach ($d in 'D:\', 'F:\'){ if (-not (Test-Path $d)){ Write-Host "ไม่พบไดรฟ์ $d" -ForegroundColor Red; exit 1 } }

New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'Backup-DtoF.ps1') $InstallDir -Force
$script = Join-Path $InstallDir 'Backup-DtoF.ps1'

# ให้เฉพาะ Administrators และ SYSTEM แก้ไฟล์สคริปต์ได้ (กันคนอื่นแก้สคริปต์ที่รันด้วยสิทธิ์ SYSTEM)
& icacls.exe $InstallDir /inheritance:r /grant:r 'Administrators:(OI)(CI)F' 'SYSTEM:(OI)(CI)F' | Out-Null

$action    = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$script`""
$trigger   = New-ScheduledTaskTrigger -Daily -DaysInterval 3 -At $Time
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
              -ExecutionTimeLimit (New-TimeSpan -Hours 23) -MultipleInstances IgnoreNew

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
    -Description 'ฝ่ายสำรองข้อมูล: สำรอง D: ไป F:\Backup_D\<วันเวลา> ทุก 3 วัน และแจ้งเตือนเมื่อพื้นที่ไม่พอ' -Force | Out-Null

$next = (Get-ScheduledTask -TaskName $TaskName | Get-ScheduledTaskInfo).NextRunTime
Write-Host "ติดตั้งแล้ว: '$TaskName'" -ForegroundColor Green
Write-Host "สคริปต์: $script"
Write-Host "รอบถัดไป: $next (จากนั้นทุก 3 วัน เวลา $Time)"
Write-Host ''
Write-Host 'ขั้นต่อไปที่แนะนำ:'
Write-Host "  1) ทดสอบแจ้งเตือน:  powershell -ExecutionPolicy Bypass -File `"$script`" -TestAlert"
Write-Host "  2) ทดสอบแบบไม่คัดลอกจริง: powershell -ExecutionPolicy Bypass -File `"$script`" -DryRun"
Write-Host "  3) รันจริงทันที:   Start-ScheduledTask -TaskName '$TaskName'"
