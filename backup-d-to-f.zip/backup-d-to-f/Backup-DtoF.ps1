﻿<#
  Backup-DtoF.ps1  —  ฝ่ายสำรองข้อมูล (แผนก IT)
  สำรองข้อมูลทั้งไดรฟ์ D: ไปที่ F:\Backup_D\<วันเวลา> แล้วแจ้งเตือนผู้ดูแลระบบเมื่อพื้นที่ไม่พอหรือ backup ล้มเหลว

  ใช้งาน:
    powershell -ExecutionPolicy Bypass -File Backup-DtoF.ps1              # รัน backup
    powershell -ExecutionPolicy Bypass -File Backup-DtoF.ps1 -TestAlert   # ทดสอบการแจ้งเตือนอย่างเดียว
    powershell -ExecutionPolicy Bypass -File Backup-DtoF.ps1 -DryRun      # ตรวจพื้นที่และแสดงสิ่งที่จะทำ โดยไม่คัดลอก
#>
[CmdletBinding()]
param([switch]$TestAlert, [switch]$DryRun)

# ======================= ตั้งค่า =======================
$Config = @{
    Source          = 'D:\'
    DestRoot        = 'F:\Backup_D'
    FolderFormat    = 'yyyy-MM-dd_HH-mm'      # ชื่อโฟลเดอร์ เช่น 2026-10-08_02-00
    LogDir          = 'F:\Backup_D\_logs'
    ExcludeDirs     = @('System Volume Information', '$RECYCLE.BIN', 'Recovery')
    SafetyMarginPct = 10     # ต้องเหลือพื้นที่บน F: อย่างน้อย % นี้หลัง backup
    WarnFreePct     = 15     # หลัง backup ถ้า F: เหลือน้อยกว่า % นี้ ให้เตือนล่วงหน้า
    KeepLast        = 0      # 0 = เก็บทุกชุด | ตัวเลข = เก็บไว้กี่ชุดล่าสุด (ลบชุดเก่ากว่าอัตโนมัติ)
    Threads         = 16

    # ----- ช่องทางแจ้งเตือนผู้ดูแลระบบ (เปิดได้หลายช่องทาง) -----
    PopupToLoggedOnUsers = $true            # แจ้งเตือนเป็นหน้าต่างบนเครื่องนี้ (msg.exe)
    EventLog             = $true            # บันทึกใน Windows Event Viewer > Application (Source: BackupDtoF)

    EmailEnabled = $false
    SmtpServer   = 'smtp.example.com'
    SmtpPort     = 587
    SmtpUseSsl   = $true
    SmtpUser     = ''                       # เว้นว่างถ้า SMTP relay ภายในไม่ต้องล็อกอิน
    SmtpPassword = ''
    MailFrom     = 'backup@example.com'
    MailTo       = @('admin@example.com')

    TelegramEnabled = $false
    TelegramToken   = ''                    # token จาก @BotFather
    TelegramChatId  = ''
}
# ======================================================

$ErrorActionPreference = 'Stop'
$Host_ = $env:COMPUTERNAME
$Stamp = Get-Date -Format $Config.FolderFormat
New-Item -ItemType Directory -Path $Config.LogDir -Force | Out-Null
$RunLog = Join-Path $Config.LogDir "run_$Stamp.log"

function Write-Log([string]$msg){
    $line = "{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg
    Write-Host $line
    Add-Content -Path $RunLog -Value $line -Encoding UTF8
}
function Format-Size([double]$b){
    if ($b -ge 1TB){ '{0:N2} TB' -f ($b/1TB) } elseif ($b -ge 1GB){ '{0:N2} GB' -f ($b/1GB) } else { '{0:N0} MB' -f ($b/1MB) }
}
function Get-Disk([string]$letter){
    $d = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='{0}'" -f $letter.Substring(0,2))
    if (-not $d){ throw "ไม่พบไดรฟ์ $letter" }
    [pscustomobject]@{ Size = [double]$d.Size; Free = [double]$d.FreeSpace; Used = [double]$d.Size - [double]$d.FreeSpace }
}

function Send-AdminAlert([string]$subject, [string]$body, [ValidateSet('Error','Warning','Information')][string]$level = 'Error'){
    $full = "[$Host_] $subject`r`n$body"
    Write-Log "แจ้งเตือน ($level): $subject"
    if ($Config.EventLog){
        try{
            if (-not [System.Diagnostics.EventLog]::SourceExists('BackupDtoF')){ New-EventLog -LogName Application -Source 'BackupDtoF' }
            $id = @{ Error = 9001; Warning = 9002; Information = 9000 }[$level]
            Write-EventLog -LogName Application -Source 'BackupDtoF' -EntryType $level -EventId $id -Message $full
        } catch { Write-Log "เขียน Event Log ไม่สำเร็จ: $($_.Exception.Message)" }
    }
    if ($Config.PopupToLoggedOnUsers){
        try{ & msg.exe * /TIME:0 "BACKUP: $subject" 2>$null } catch {}
    }
    if ($Config.EmailEnabled){
        try{
            $mail = New-Object System.Net.Mail.MailMessage
            $mail.From = $Config.MailFrom
            $Config.MailTo | ForEach-Object { $mail.To.Add($_) }
            $mail.Subject = "[Backup $Host_] $subject"
            $mail.Body = $full
            $mail.BodyEncoding = [System.Text.Encoding]::UTF8
            $mail.SubjectEncoding = [System.Text.Encoding]::UTF8
            $smtp = New-Object System.Net.Mail.SmtpClient($Config.SmtpServer, $Config.SmtpPort)
            $smtp.EnableSsl = $Config.SmtpUseSsl
            if ($Config.SmtpUser){ $smtp.Credentials = New-Object System.Net.NetworkCredential($Config.SmtpUser, $Config.SmtpPassword) }
            $smtp.Send($mail)
        } catch { Write-Log "ส่งอีเมลไม่สำเร็จ: $($_.Exception.Message)" }
    }
    if ($Config.TelegramEnabled){
        try{
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $uri = "https://api.telegram.org/bot$($Config.TelegramToken)/sendMessage"
            $payload = @{ chat_id = $Config.TelegramChatId; text = $full } | ConvertTo-Json -Compress
            Invoke-RestMethod -Uri $uri -Method Post -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($payload)) | Out-Null
        } catch { Write-Log "ส่ง Telegram ไม่สำเร็จ: $($_.Exception.Message)" }
    }
}

if ($TestAlert){
    Send-AdminAlert 'ทดสอบการแจ้งเตือน' 'ถ้าได้รับข้อความนี้ แปลว่าช่องทางแจ้งเตือนของระบบ backup ใช้งานได้' 'Information'
    exit 0
}

try{
    Write-Log "===== เริ่ม backup $($Config.Source) -> $($Config.DestRoot)\$Stamp ====="

    # 1) ตรวจพื้นที่ก่อนเริ่ม
    $src = Get-Disk $Config.Source
    $dst = Get-Disk $Config.DestRoot
    $need = $src.Used * (1 + $Config.SafetyMarginPct / 100)
    Write-Log ("ข้อมูลบน D: {0} | F: ว่าง {1} จาก {2} | ต้องใช้ประมาณ {3}" -f (Format-Size $src.Used), (Format-Size $dst.Free), (Format-Size $dst.Size), (Format-Size $need))

    if ($Config.KeepLast -gt 0){
        $sets = Get-ChildItem $Config.DestRoot -Directory | Where-Object { $_.Name -ne '_logs' } | Sort-Object Name
        $remove = $sets | Select-Object -First ([Math]::Max(0, $sets.Count - ($Config.KeepLast - 1)))
        foreach ($old in $remove){
            if ($DryRun){ Write-Log "DryRun: จะลบชุดเก่า $($old.FullName)" }
            else { Write-Log "ลบชุดเก่าตามนโยบาย KeepLast=$($Config.KeepLast): $($old.FullName)"; Remove-Item $old.FullName -Recurse -Force }
        }
        if (-not $DryRun -and $remove){ $dst = Get-Disk $Config.DestRoot }
    }

    if ($dst.Free -lt $need){
        Send-AdminAlert 'พื้นที่ F: ไม่พอสำหรับ backup — ยกเลิกรอบนี้' ("ต้องใช้ประมาณ {0} แต่ F: ว่างเพียง {1} (จาก {2})`r`nกรุณาเพิ่มพื้นที่ ย้ายชุด backup เก่าออกจาก {3} หรือตั้งค่า KeepLast" -f (Format-Size $need), (Format-Size $dst.Free), (Format-Size $dst.Size), $Config.DestRoot) 'Error'
        exit 2
    }

    $dest = Join-Path $Config.DestRoot $Stamp
    $roboLog = Join-Path $Config.LogDir "robocopy_$Stamp.log"
    $args_ = @($Config.Source, $dest, '/E', '/COPY:DAT', '/DCOPY:DAT', '/R:1', '/W:2', "/MT:$($Config.Threads)", '/XJ', '/NP', '/NFL', '/NDL', "/UNILOG:$roboLog", '/TEE')
    $args_ += '/XD'; $args_ += $Config.ExcludeDirs | ForEach-Object { Join-Path $Config.Source $_ }
    if ($DryRun){ $args_ += '/L'; Write-Log "DryRun: แสดงรายการโดยไม่คัดลอก" }

    # 2) คัดลอก
    Write-Log ("robocopy " + ($args_ -join ' '))
    & robocopy.exe @args_ | Out-Null
    $rc = $LASTEXITCODE
    Write-Log "robocopy exit code = $rc (0-7 = สำเร็จ, 8 ขึ้นไป = มีไฟล์คัดลอกไม่สำเร็จ)"

    if ($rc -ge 8){
        $tail = (Get-Content $roboLog -Tail 15 -ErrorAction SilentlyContinue) -join "`r`n"
        $after = Get-Disk $Config.DestRoot
        $full = $after.Free -lt 1GB
        $title = if ($full) { 'พื้นที่ F: เต็มระหว่าง backup' } else { 'backup มีไฟล์คัดลอกไม่สำเร็จ' }
        $msgBody = "ปลายทาง: $dest`r`nrobocopy exit code: $rc`r`nF: ว่างเหลือ " + (Format-Size $after.Free) + "`r`nดู log: $roboLog`r`n----`r`n" + $tail
        Send-AdminAlert $title $msgBody 'Error'
        exit 3
    }

    # 3) ตรวจพื้นที่หลัง backup แล้วเตือนล่วงหน้า (รอบถัดไปอาจไม่พอ)
    $after = Get-Disk $Config.DestRoot
    $freePct = [Math]::Round($after.Free / $after.Size * 100, 1)
    Write-Log ("เสร็จแล้ว: $dest | F: ว่างเหลือ {0} ({1}%)" -f (Format-Size $after.Free), $freePct)
    if (-not $DryRun -and ($freePct -lt $Config.WarnFreePct -or $after.Free -lt $need)){
        Send-AdminAlert 'พื้นที่ F: ใกล้เต็ม' ("backup รอบนี้สำเร็จ แต่ F: เหลือ {0} ({1}%) ซึ่งไม่พอสำหรับรอบถัดไป (ต้องใช้ประมาณ {2})" -f (Format-Size $after.Free), $freePct, (Format-Size $need)) 'Warning'
    }
    if (-not $DryRun -and $Config.EventLog){
        try{
            if (-not [System.Diagnostics.EventLog]::SourceExists('BackupDtoF')){ New-EventLog -LogName Application -Source 'BackupDtoF' }
            Write-EventLog -LogName Application -Source 'BackupDtoF' -EntryType Information -EventId 9000 -Message "Backup สำเร็จ: $dest"
        } catch {}
    }
    exit 0
}
catch{
    Send-AdminAlert 'backup ล้มเหลว' ("ข้อผิดพลาด: {0}`r`nดู log: {1}" -f $_.Exception.Message, $RunLog) 'Error'
    exit 1
}
